#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class NSURL, TruoraSharedAgeRange, TruoraSharedAgeRangeCompanion, TruoraSharedApiError, TruoraSharedApiErrorCompanion, TruoraSharedApiKeyException, TruoraSharedApiKeyGeneratorClient, TruoraSharedApiKeyGeneratorClientCompanion, TruoraSharedApiKeyResponse, TruoraSharedApiKeyResponseCompanion, TruoraSharedApiKeyTypes, TruoraSharedBackgroundCheck, TruoraSharedBackgroundCheckCompanion, TruoraSharedCaptureStatus, TruoraSharedCapturedPhotoState, TruoraSharedCountries, TruoraSharedDocumentAutoCaptureEventBackPhotoCaptured, TruoraSharedDocumentAutoCaptureEventFrontPhotoCaptured, TruoraSharedDocumentAutoCaptureEventHelpDismissed, TruoraSharedDocumentAutoCaptureEventHelpRequested, TruoraSharedDocumentAutoCaptureEventManualCaptureRequested, TruoraSharedDocumentAutoCaptureEventRotationAnimationCompleted, TruoraSharedDocumentAutoCaptureFeedbackEventDismissed, TruoraSharedDocumentAutoCaptureFeedbackEventRetryClicked, TruoraSharedDocumentAutoCaptureFeedbackEventTipsClicked, TruoraSharedDocumentAutoCaptureIntroEventCancelClicked, TruoraSharedDocumentAutoCaptureIntroEventStartClicked, TruoraSharedDocumentCaptureSide, TruoraSharedDocumentDetails, TruoraSharedDocumentDetailsCompanion, TruoraSharedDocumentFeedbackType, TruoraSharedDocumentSubValidations, TruoraSharedDocumentSubValidationsCompanion, TruoraSharedDocumentTypes, TruoraSharedEnrollmentRequest, TruoraSharedEnrollmentRequestCompanion, TruoraSharedEnrollmentResponse, TruoraSharedEnrollmentResponseCompanion, TruoraSharedEnrollmentStatusResponse, TruoraSharedEnrollmentStatusResponseCompanion, TruoraSharedEnrollmentsApi, TruoraSharedEnrollmentsApiCompanion, TruoraSharedEventLevel, TruoraSharedEventLevelCompanion, TruoraSharedEventType, TruoraSharedEventTypeCompanion, TruoraSharedFaceRecognitionDetails, TruoraSharedFaceRecognitionDetailsCompanion, TruoraSharedFaceSearch, TruoraSharedFaceSearchCompanion, TruoraSharedFaceValidation, TruoraSharedFaceValidationBuilder, TruoraSharedFailureStatus, TruoraSharedFailureStatusCompanion, TruoraSharedFeedbackScenario, TruoraSharedFeedbackType, TruoraSharedFileUploadResponse, TruoraSharedFileUploadResponseCompanion, TruoraSharedJwtDecoder, TruoraSharedKotlinAbstractCoroutineContextElement, TruoraSharedKotlinAbstractCoroutineContextKey<B, E>, TruoraSharedKotlinArray<T>, TruoraSharedKotlinByteArray, TruoraSharedKotlinByteIterator, TruoraSharedKotlinCancellationException, TruoraSharedKotlinEnum<E>, TruoraSharedKotlinEnumCompanion, TruoraSharedKotlinException, TruoraSharedKotlinFloatArray, TruoraSharedKotlinFloatIterator, TruoraSharedKotlinIllegalStateException, TruoraSharedKotlinIntArray, TruoraSharedKotlinIntIterator, TruoraSharedKotlinIntProgression, TruoraSharedKotlinIntProgressionCompanion, TruoraSharedKotlinIntRange, TruoraSharedKotlinIntRangeCompanion, TruoraSharedKotlinKTypeProjection, TruoraSharedKotlinKTypeProjectionCompanion, TruoraSharedKotlinKVariance, TruoraSharedKotlinMatchGroup, TruoraSharedKotlinMatchResultDestructured, TruoraSharedKotlinNothing, TruoraSharedKotlinPair<__covariant A, __covariant B>, TruoraSharedKotlinRegex, TruoraSharedKotlinRegexCompanion, TruoraSharedKotlinRegexOption, TruoraSharedKotlinRuntimeException, TruoraSharedKotlinShortArray, TruoraSharedKotlinShortIterator, TruoraSharedKotlinThrowable, TruoraSharedKotlinUnit, TruoraSharedKotlinx_coroutines_coreCoroutineDispatcher, TruoraSharedKotlinx_coroutines_coreCoroutineDispatcherKey, TruoraSharedKotlinx_io_coreBuffer, TruoraSharedKotlinx_serialization_coreSerialKind, TruoraSharedKotlinx_serialization_coreSerializersModule, TruoraSharedKotlinx_serialization_jsonJsonElement, TruoraSharedKotlinx_serialization_jsonJsonElementCompanion, TruoraSharedKtor_client_coreHttpClient, TruoraSharedKtor_client_coreHttpClientCall, TruoraSharedKtor_client_coreHttpClientCallCompanion, TruoraSharedKtor_client_coreHttpClientConfig<T>, TruoraSharedKtor_client_coreHttpClientEngineConfig, TruoraSharedKtor_client_coreHttpReceivePipeline, TruoraSharedKtor_client_coreHttpReceivePipelinePhases, TruoraSharedKtor_client_coreHttpRequestBuilder, TruoraSharedKtor_client_coreHttpRequestBuilderCompanion, TruoraSharedKtor_client_coreHttpRequestData, TruoraSharedKtor_client_coreHttpRequestPipeline, TruoraSharedKtor_client_coreHttpRequestPipelinePhases, TruoraSharedKtor_client_coreHttpResponse, TruoraSharedKtor_client_coreHttpResponseContainer, TruoraSharedKtor_client_coreHttpResponseData, TruoraSharedKtor_client_coreHttpResponsePipeline, TruoraSharedKtor_client_coreHttpResponsePipelinePhases, TruoraSharedKtor_client_coreHttpSendPipeline, TruoraSharedKtor_client_coreHttpSendPipelinePhases, TruoraSharedKtor_client_coreProxyConfig, TruoraSharedKtor_eventsEventDefinition<T>, TruoraSharedKtor_eventsEvents, TruoraSharedKtor_httpContentType, TruoraSharedKtor_httpContentTypeCompanion, TruoraSharedKtor_httpHeaderValueParam, TruoraSharedKtor_httpHeaderValueWithParameters, TruoraSharedKtor_httpHeaderValueWithParametersCompanion, TruoraSharedKtor_httpHeadersBuilder, TruoraSharedKtor_httpHttpMethod, TruoraSharedKtor_httpHttpMethodCompanion, TruoraSharedKtor_httpHttpProtocolVersion, TruoraSharedKtor_httpHttpProtocolVersionCompanion, TruoraSharedKtor_httpHttpStatusCode, TruoraSharedKtor_httpHttpStatusCodeCompanion, TruoraSharedKtor_httpOutgoingContent, TruoraSharedKtor_httpURLBuilder, TruoraSharedKtor_httpURLBuilderCompanion, TruoraSharedKtor_httpURLProtocol, TruoraSharedKtor_httpURLProtocolCompanion, TruoraSharedKtor_httpUrl, TruoraSharedKtor_httpUrlCompanion, TruoraSharedKtor_utilsAttributeKey<T>, TruoraSharedKtor_utilsGMTDate, TruoraSharedKtor_utilsGMTDateCompanion, TruoraSharedKtor_utilsMonth, TruoraSharedKtor_utilsMonthCompanion, TruoraSharedKtor_utilsPipeline<TSubject, TContext>, TruoraSharedKtor_utilsPipelinePhase, TruoraSharedKtor_utilsStringValuesBuilderImpl, TruoraSharedKtor_utilsTypeInfo, TruoraSharedKtor_utilsWeekDay, TruoraSharedKtor_utilsWeekDayCompanion, TruoraSharedLibraryDrawableResource, TruoraSharedLibraryResource, TruoraSharedLibraryResourceItem, TruoraSharedLibraryStringResource, TruoraSharedLivenessModes, TruoraSharedLoadingType, TruoraSharedLocalAppLocale, TruoraSharedManualCaptureType, TruoraSharedMetadataBuilder, TruoraSharedPassiveCaptureEventCountdownFinished, TruoraSharedPassiveCaptureEventCountdownStarted, TruoraSharedPassiveCaptureEventFeedbackChanged, TruoraSharedPassiveCaptureEventHelpDismissed, TruoraSharedPassiveCaptureEventHelpRequested, TruoraSharedPassiveCaptureEventManualRecordingRequested, TruoraSharedPassiveCaptureEventRecordVideoRequested, TruoraSharedPassiveCaptureEventRecordingCompleted, TruoraSharedPassiveCaptureEventRecordingStarted, TruoraSharedPassiveCaptureState, TruoraSharedPlatformFileHandle, TruoraSharedResponseParser, TruoraSharedRuntimeCompositionLocal<T>, TruoraSharedRuntimeProvidableCompositionLocal<T>, TruoraSharedRuntimeProvidedValue<T>, TruoraSharedSDKEvent, TruoraSharedSDKEventCompanion, TruoraSharedSDKLog, TruoraSharedSDKLogCompanion, TruoraSharedSDKLogResponse, TruoraSharedSDKLogResponseCompanion, TruoraSharedSdkLogClientCompanion, TruoraSharedSdkLogErrorType, TruoraSharedSdkLogErrorTypeCompanion, TruoraSharedSdkLogException, TruoraSharedSdkLogExceptionCompanion, TruoraSharedSdkLogManager, TruoraSharedSdkLogValidationCode, TruoraSharedSdkLogValidationExceptionCompanion, TruoraSharedSkikoBackendRenderTarget, TruoraSharedSkikoBackendRenderTargetCompanion, TruoraSharedSkikoBackendTexture, TruoraSharedSkikoBackendTextureCompanion, TruoraSharedSkikoBitmap, TruoraSharedSkikoBitmapCompanion, TruoraSharedSkikoBlendMode, TruoraSharedSkikoCanvas, TruoraSharedSkikoCanvasCompanion, TruoraSharedSkikoCanvasSaveLayerFlags, TruoraSharedSkikoCanvasSaveLayerFlagsSet, TruoraSharedSkikoCanvasSaveLayerRec, TruoraSharedSkikoClipMode, TruoraSharedSkikoColor4f, TruoraSharedSkikoColor4fCompanion, TruoraSharedSkikoColorAlphaType, TruoraSharedSkikoColorChannel, TruoraSharedSkikoColorFilter, TruoraSharedSkikoColorFilterCompanion, TruoraSharedSkikoColorInfo, TruoraSharedSkikoColorInfoCompanion, TruoraSharedSkikoColorMatrix, TruoraSharedSkikoColorSpace, TruoraSharedSkikoColorSpaceCompanion, TruoraSharedSkikoColorType, TruoraSharedSkikoColorTypeCompanion, TruoraSharedSkikoContentChangeMode, TruoraSharedSkikoData, TruoraSharedSkikoDataCompanion, TruoraSharedSkikoDirectContext, TruoraSharedSkikoDirectContextCompanion, TruoraSharedSkikoDrawable, TruoraSharedSkikoDrawableCompanion, TruoraSharedSkikoEncodedImageFormat, TruoraSharedSkikoFilterBlurMode, TruoraSharedSkikoFilterMode, TruoraSharedSkikoFilterTileMode, TruoraSharedSkikoFont, TruoraSharedSkikoFontCompanion, TruoraSharedSkikoFontEdging, TruoraSharedSkikoFontFamilyName, TruoraSharedSkikoFontFeature, TruoraSharedSkikoFontFeatureCompanion, TruoraSharedSkikoFontHinting, TruoraSharedSkikoFontMetrics, TruoraSharedSkikoFontMetricsCompanion, TruoraSharedSkikoFontMgr, TruoraSharedSkikoFontMgrCompanion, TruoraSharedSkikoFontSlant, TruoraSharedSkikoFontStyle, TruoraSharedSkikoFontStyleCompanion, TruoraSharedSkikoFontStyleSet, TruoraSharedSkikoFontStyleSetCompanion, TruoraSharedSkikoFontVariation, TruoraSharedSkikoFontVariationAxis, TruoraSharedSkikoFontVariationCompanion, TruoraSharedSkikoGLBackendState, TruoraSharedSkikoGradientStyle, TruoraSharedSkikoGradientStyleCompanion, TruoraSharedSkikoIPoint, TruoraSharedSkikoIPointCompanion, TruoraSharedSkikoIRect, TruoraSharedSkikoIRectCompanion, TruoraSharedSkikoISize, TruoraSharedSkikoISizeCompanion, TruoraSharedSkikoImage, TruoraSharedSkikoImageCompanion, TruoraSharedSkikoImageFilter, TruoraSharedSkikoImageFilterCompanion, TruoraSharedSkikoImageInfo, TruoraSharedSkikoImageInfoCompanion, TruoraSharedSkikoInversionMode, TruoraSharedSkikoManaged, TruoraSharedSkikoMaskFilter, TruoraSharedSkikoMaskFilterCompanion, TruoraSharedSkikoMatcher, TruoraSharedSkikoMatrix22, TruoraSharedSkikoMatrix22Companion, TruoraSharedSkikoMatrix33, TruoraSharedSkikoMatrix33Companion, TruoraSharedSkikoMatrix44, TruoraSharedSkikoMatrix44Companion, TruoraSharedSkikoNative, TruoraSharedSkikoNativeCompanion, TruoraSharedSkikoPaint, TruoraSharedSkikoPaintCompanion, TruoraSharedSkikoPaintMode, TruoraSharedSkikoPaintStrokeCap, TruoraSharedSkikoPaintStrokeJoin, TruoraSharedSkikoPath, TruoraSharedSkikoPathCompanion, TruoraSharedSkikoPathDirection, TruoraSharedSkikoPathEffect, TruoraSharedSkikoPathEffectCompanion, TruoraSharedSkikoPathEffectStyle, TruoraSharedSkikoPathEllipseArc, TruoraSharedSkikoPathFillMode, TruoraSharedSkikoPathOp, TruoraSharedSkikoPathSegment, TruoraSharedSkikoPathSegmentIterator, TruoraSharedSkikoPathSegmentIteratorCompanion, TruoraSharedSkikoPathVerb, TruoraSharedSkikoPattern, TruoraSharedSkikoPicture, TruoraSharedSkikoPictureCompanion, TruoraSharedSkikoPixelGeometry, TruoraSharedSkikoPixelRef, TruoraSharedSkikoPixelRefCompanion, TruoraSharedSkikoPixmap, TruoraSharedSkikoPixmapCompanion, TruoraSharedSkikoPoint, TruoraSharedSkikoPointCompanion, TruoraSharedSkikoRRect, TruoraSharedSkikoRRectCompanion, TruoraSharedSkikoRSXform, TruoraSharedSkikoRSXformCompanion, TruoraSharedSkikoRect, TruoraSharedSkikoRectCompanion, TruoraSharedSkikoRefCnt, TruoraSharedSkikoRegion, TruoraSharedSkikoRegionCompanion, TruoraSharedSkikoRegionOp, TruoraSharedSkikoRegionOpCompanion, TruoraSharedSkikoRuntimeEffect, TruoraSharedSkikoRuntimeEffectCompanion, TruoraSharedSkikoRuntimeShaderBuilder, TruoraSharedSkikoRuntimeShaderBuilderCompanion, TruoraSharedSkikoShader, TruoraSharedSkikoShaderCompanion, TruoraSharedSkikoShapingOptions, TruoraSharedSkikoShapingOptionsCompanion, TruoraSharedSkikoSurface, TruoraSharedSkikoSurfaceColorFormat, TruoraSharedSkikoSurfaceCompanion, TruoraSharedSkikoSurfaceOrigin, TruoraSharedSkikoSurfaceProps, TruoraSharedSkikoTextBlob, TruoraSharedSkikoTextBlobCompanion, TruoraSharedSkikoTextLine, TruoraSharedSkikoTextLineCompanion, TruoraSharedSkikoTypeface, TruoraSharedSkikoTypefaceCompanion, TruoraSharedSkikoVertexMode, TruoraSharedSubValidationResult, TruoraSharedSubValidationResultCompanion, TruoraSharedSubValidationTypes, TruoraSharedTruoraCustomColors, TruoraSharedTruoraCustomLogo, TruoraSharedTruoraExtendedColors, TruoraSharedTruoraHttpClient, TruoraSharedTruoraHttpClientCompanion, TruoraSharedTruoraSDKCredentials, TruoraSharedTruoraTheme, TruoraSharedTruoraUIConfig, TruoraSharedTruoraUIConfigCompanion, TruoraSharedTruoraValidations, TruoraSharedTruoraValidationsFactory, TruoraSharedUi_graphicsBrush, TruoraSharedUi_graphicsBrushCompanion, TruoraSharedUi_graphicsColorFilter, TruoraSharedUi_graphicsColorFilterCompanion, TruoraSharedUi_graphicsColorSpace, TruoraSharedUploadState, TruoraSharedUserResponse, TruoraSharedUserResponseCompanion, TruoraSharedValidationCreateResponse, TruoraSharedValidationCreateResponseCompanion, TruoraSharedValidationDetailResponse, TruoraSharedValidationDetailResponseCompanion, TruoraSharedValidationDetails, TruoraSharedValidationDetailsCompanion, TruoraSharedValidationInputs, TruoraSharedValidationInputsCompanion, TruoraSharedValidationInstructions, TruoraSharedValidationInstructionsCompanion, TruoraSharedValidationRequest, TruoraSharedValidationRequestCompanion, TruoraSharedValidationResultEventFinishClicked, TruoraSharedValidationResultType, TruoraSharedValidationStatus, TruoraSharedValidationTypes, TruoraSharedValidationsApi, TruoraSharedValidationsErrorType, TruoraSharedValidationsSDKConfig, TruoraSharedValidationsSDKConfigBuilder, TruoraSharedValidationsSDKConfigCompanion, TruoraSharedValidationsSDKHandler, UIImage, UIViewController;

@protocol TruoraSharedDocumentAutoCaptureEvent, TruoraSharedDocumentAutoCaptureFeedbackEvent, TruoraSharedDocumentAutoCaptureIntroEvent, TruoraSharedKotlinAnnotation, TruoraSharedKotlinAutoCloseable, TruoraSharedKotlinClosedRange, TruoraSharedKotlinCollection, TruoraSharedKotlinComparable, TruoraSharedKotlinContinuation, TruoraSharedKotlinContinuationInterceptor, TruoraSharedKotlinCoroutineContext, TruoraSharedKotlinCoroutineContextElement, TruoraSharedKotlinCoroutineContextKey, TruoraSharedKotlinFunction, TruoraSharedKotlinIterable, TruoraSharedKotlinIterator, TruoraSharedKotlinKAnnotatedElement, TruoraSharedKotlinKClass, TruoraSharedKotlinKClassifier, TruoraSharedKotlinKDeclarationContainer, TruoraSharedKotlinKType, TruoraSharedKotlinMapEntry, TruoraSharedKotlinMatchGroupCollection, TruoraSharedKotlinMatchResult, TruoraSharedKotlinMutableIterator, TruoraSharedKotlinOpenEndRange, TruoraSharedKotlinSequence, TruoraSharedKotlinSuspendFunction2, TruoraSharedKotlinx_coroutines_coreChildHandle, TruoraSharedKotlinx_coroutines_coreChildJob, TruoraSharedKotlinx_coroutines_coreCoroutineScope, TruoraSharedKotlinx_coroutines_coreDisposableHandle, TruoraSharedKotlinx_coroutines_coreJob, TruoraSharedKotlinx_coroutines_coreParentJob, TruoraSharedKotlinx_coroutines_coreRunnable, TruoraSharedKotlinx_coroutines_coreSelectClause, TruoraSharedKotlinx_coroutines_coreSelectClause0, TruoraSharedKotlinx_coroutines_coreSelectInstance, TruoraSharedKotlinx_io_coreRawSink, TruoraSharedKotlinx_io_coreRawSource, TruoraSharedKotlinx_io_coreSink, TruoraSharedKotlinx_io_coreSource, TruoraSharedKotlinx_serialization_coreCompositeDecoder, TruoraSharedKotlinx_serialization_coreCompositeEncoder, TruoraSharedKotlinx_serialization_coreDecoder, TruoraSharedKotlinx_serialization_coreDeserializationStrategy, TruoraSharedKotlinx_serialization_coreEncoder, TruoraSharedKotlinx_serialization_coreKSerializer, TruoraSharedKotlinx_serialization_coreSerialDescriptor, TruoraSharedKotlinx_serialization_coreSerializationStrategy, TruoraSharedKotlinx_serialization_coreSerializersModuleCollector, TruoraSharedKtor_client_coreHttpClientEngine, TruoraSharedKtor_client_coreHttpClientEngineCapability, TruoraSharedKtor_client_coreHttpClientPlugin, TruoraSharedKtor_client_coreHttpRequest, TruoraSharedKtor_httpHeaders, TruoraSharedKtor_httpHttpMessage, TruoraSharedKtor_httpHttpMessageBuilder, TruoraSharedKtor_httpParameters, TruoraSharedKtor_httpParametersBuilder, TruoraSharedKtor_ioByteReadChannel, TruoraSharedKtor_ioCloseable, TruoraSharedKtor_ioJvmSerializable, TruoraSharedKtor_utilsAttributes, TruoraSharedKtor_utilsStringValues, TruoraSharedKtor_utilsStringValuesBuilder, TruoraSharedLibraryQualifier, TruoraSharedPassiveCaptureEvent, TruoraSharedPlatform, TruoraSharedRuntimeCompositionLocalAccessorScope, TruoraSharedSkikoIHasImageInfo, TruoraSharedSkikoSamplingMode, TruoraSharedUiModifier, TruoraSharedUiModifierElement, TruoraSharedUi_graphicsImageBitmap, TruoraSharedUi_graphicsPaint, TruoraSharedUi_graphicsPathEffect, TruoraSharedValidationResultEvent;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface TruoraSharedBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface TruoraSharedBase (TruoraSharedBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface TruoraSharedMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface TruoraSharedMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorTruoraSharedKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface TruoraSharedNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface TruoraSharedByte : TruoraSharedNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface TruoraSharedUByte : TruoraSharedNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface TruoraSharedShort : TruoraSharedNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface TruoraSharedUShort : TruoraSharedNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface TruoraSharedInt : TruoraSharedNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface TruoraSharedUInt : TruoraSharedNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface TruoraSharedLong : TruoraSharedNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface TruoraSharedULong : TruoraSharedNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface TruoraSharedFloat : TruoraSharedNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface TruoraSharedDouble : TruoraSharedNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface TruoraSharedBoolean : TruoraSharedNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end


/**
 * Immutable credentials for Truora SDK authentication.
 *
 * @param apiKey The API key (JWT) that can be either SDK or generator type
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraSDKCredentials")))
@interface TruoraSharedTruoraSDKCredentials : TruoraSharedBase
- (instancetype)initWithApiKey:(NSString *)apiKey __attribute__((swift_name("init(apiKey:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedTruoraSDKCredentials *)doCopyApiKey:(NSString *)apiKey __attribute__((swift_name("doCopy(apiKey:)")));

/**
 * Immutable credentials for Truora SDK authentication.
 *
 * @param apiKey The API key (JWT) that can be either SDK or generator type
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Immutable credentials for Truora SDK authentication.
 *
 * @param apiKey The API key (JWT) that can be either SDK or generator type
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Immutable credentials for Truora SDK authentication.
 *
 * @param apiKey The API key (JWT) that can be either SDK or generator type
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *apiKey __attribute__((swift_name("apiKey")));
@end


/**
 * Class for handling the sdk config for validators API handling
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationsSDKConfig")))
@interface TruoraSharedValidationsSDKConfig : TruoraSharedBase
- (instancetype)initWithAccentColor:(int32_t)accentColor backgroundColor:(int32_t)backgroundColor userId:(NSString *)userId logo:(NSString *)logo __attribute__((swift_name("init(accentColor:backgroundColor:userId:logo:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedValidationsSDKConfigCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedValidationsSDKConfig *)doCopyAccentColor:(int32_t)accentColor backgroundColor:(int32_t)backgroundColor userId:(NSString *)userId logo:(NSString *)logo __attribute__((swift_name("doCopy(accentColor:backgroundColor:userId:logo:)")));

/**
 * Class for handling the sdk config for validators API handling
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Class for handling the sdk config for validators API handling
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Class for handling the sdk config for validators API handling
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t accentColor __attribute__((swift_name("accentColor")));
@property (readonly) int32_t backgroundColor __attribute__((swift_name("backgroundColor")));
@property (readonly) NSString *logo __attribute__((swift_name("logo")));
@property (readonly) NSString *userId __attribute__((swift_name("userId")));
@end


/**
 * Builder class for creating ValidationsSDKConfig instances with a fluent API.
 * @param userId The user ID (mandatory parameter)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationsSDKConfig.Builder")))
@interface TruoraSharedValidationsSDKConfigBuilder : TruoraSharedBase
- (instancetype)initWithUserId:(NSString *)userId __attribute__((swift_name("init(userId:)"))) __attribute__((objc_designated_initializer));

/**
 * Sets the accent color for the UI.
 * @param color The accent color to use
 * @return This builder instance for chaining
 */
- (TruoraSharedValidationsSDKConfigBuilder *)accentColorColor:(int32_t)color __attribute__((swift_name("accentColor(color:)")));

/**
 * Sets the background color for the UI.
 * @param color The background color to use
 * @return This builder instance for chaining
 */
- (TruoraSharedValidationsSDKConfigBuilder *)backgroundColorColor:(int32_t)color __attribute__((swift_name("backgroundColor(color:)")));

/**
 * Builds and returns the ValidationsSDKConfig instance.
 * @return A new ValidationsSDKConfig instance with the configured values
 */
- (TruoraSharedValidationsSDKConfig *)build __attribute__((swift_name("build()")));

/**
 * Sets the logo to display in the UI.
 * @param logo The logo URL or path
 * @return This builder instance for chaining
 */
- (TruoraSharedValidationsSDKConfigBuilder *)logoLogo:(NSString *)logo __attribute__((swift_name("logo(logo:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationsSDKConfig.Companion")))
@interface TruoraSharedValidationsSDKConfigCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedValidationsSDKConfigCompanion *shared __attribute__((swift_name("shared")));

/**
 * Default color values used when no custom colors are specified.
 * Using hardcoded ARGB values (0xAARRGGBB format) for platform-agnostic
 * color definitions in commonMain that work consistently across Android and iOS.
 */
@property (readonly) int32_t DEFAULT_ACCENT_COLOR __attribute__((swift_name("DEFAULT_ACCENT_COLOR")));
@property (readonly) int32_t DEFAULT_BACKGROUND_COLOR __attribute__((swift_name("DEFAULT_BACKGROUND_COLOR")));
@property (readonly) int32_t TruoraAccentColor __attribute__((swift_name("TruoraAccentColor"))) __attribute__((deprecated("Use DEFAULT_ACCENT_COLOR instead")));
@property (readonly) int32_t TruoraBackgroundColor __attribute__((swift_name("TruoraBackgroundColor"))) __attribute__((deprecated("Use DEFAULT_BACKGROUND_COLOR instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationsSDKHandler")))
@interface TruoraSharedValidationsSDKHandler : TruoraSharedBase
- (instancetype)initWithCredentials:(TruoraSharedTruoraSDKCredentials *)credentials config:(TruoraSharedValidationsSDKConfig *)config resolvedApiKey:(NSString *)resolvedApiKey __attribute__((swift_name("init(credentials:config:resolvedApiKey:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedValidationsSDKHandler *)doCopyCredentials:(TruoraSharedTruoraSDKCredentials *)credentials config:(TruoraSharedValidationsSDKConfig *)config resolvedApiKey:(NSString *)resolvedApiKey __attribute__((swift_name("doCopy(credentials:config:resolvedApiKey:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Get the API key to use for SDK operations.
 */
- (NSString *)getEffectiveApiKey __attribute__((swift_name("getEffectiveApiKey()")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedValidationsSDKConfig *config __attribute__((swift_name("config")));
@property (readonly) TruoraSharedTruoraSDKCredentials *credentials __attribute__((swift_name("credentials")));
@property (readonly) NSString *resolvedApiKey __attribute__((swift_name("resolvedApiKey")));
@end


/**
 * Builder class for creating ValidationsSDKHandler instances. All parameters are required and
 * must be provided in the constructor.
 *
 * @param credentials The SDK credentials for authentication
 * @param config The SDK configuration including UI settings
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationsSDKHandler.Builder")))
@interface TruoraSharedValidationsSDKHandlerBuilder : TruoraSharedBase
- (instancetype)initWithCredentials:(TruoraSharedTruoraSDKCredentials *)credentials config:(TruoraSharedValidationsSDKConfig *)config __attribute__((swift_name("init(credentials:config:)"))) __attribute__((objc_designated_initializer));

/**
 * Builds and returns the ValidationsSDKHandler instance without API key resolution.
 * Use initialize() instead if you need to resolve generator keys.
 * Uses the original API key as the resolved key.
 *
 * @return A new ValidationsSDKHandler instance with the configured values
 */
- (TruoraSharedValidationsSDKHandler *)build __attribute__((swift_name("build()")));

/**
 * Initializes the SDK handler by resolving the API key.
 * If the API key is a generator type, this will call the API to generate an SDK key.
 *
 * @return A new ValidationsSDKHandler instance with resolved API key
 * @throws com.truora.validations.apikey.ApiKeyException if key validation or generation fails
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)initializeWithCompletionHandler:(void (^)(TruoraSharedValidationsSDKHandler * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("initialize(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FaceValidation")))
@interface TruoraSharedFaceValidation : TruoraSharedBase
- (instancetype)initWithSimilarityThreshold:(float)similarityThreshold enableAutoCapture:(BOOL)enableAutoCapture waitValidationResult:(BOOL)waitValidationResult timeout:(int32_t)timeout __attribute__((swift_name("init(similarityThreshold:enableAutoCapture:waitValidationResult:timeout:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedFaceValidation *)doCopySimilarityThreshold:(float)similarityThreshold enableAutoCapture:(BOOL)enableAutoCapture waitValidationResult:(BOOL)waitValidationResult timeout:(int32_t)timeout __attribute__((swift_name("doCopy(similarityThreshold:enableAutoCapture:waitValidationResult:timeout:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL enableAutoCapture __attribute__((swift_name("enableAutoCapture")));
@property (readonly) float similarityThreshold __attribute__((swift_name("similarityThreshold")));
@property (readonly) int32_t timeout __attribute__((swift_name("timeout")));
@property (readonly) BOOL waitValidationResult __attribute__((swift_name("waitValidationResult")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FaceValidation.Builder")))
@interface TruoraSharedFaceValidationBuilder : TruoraSharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * Builds and returns the FaceValidation instance.
 * @return A new FaceValidation instance with the configured values
 */
- (TruoraSharedFaceValidation *)build __attribute__((swift_name("build()")));

/**
 * Sets the similarity threshold for face matching (0.0 to 1.0).
 * @param threshold The similarity threshold value
 * @return This builder instance for chaining
 */
- (TruoraSharedFaceValidationBuilder *)similarityThresholdThreshold:(float)threshold __attribute__((swift_name("similarityThreshold(threshold:)")));

/**
 * Sets the timeout for validation in milliseconds.
 * @param timeout The timeout value in milliseconds
 * @return This builder instance for chaining
 */
- (TruoraSharedFaceValidationBuilder *)timeoutTimeout:(int32_t)timeout __attribute__((swift_name("timeout(timeout:)")));

/**
 * Sets whether autocapture should be enabled.
 * @param enabled True to enable autocapture, false otherwise
 * @return This builder instance for chaining
 */
- (TruoraSharedFaceValidationBuilder *)useAutoCaptureEnabled:(BOOL)enabled __attribute__((swift_name("useAutoCapture(enabled:)")));

/**
 * Sets whether to wait for validation result.
 * @param wait True to wait for validation result, false otherwise
 * @return This builder instance for chaining
 */
- (TruoraSharedFaceValidationBuilder *)useWaitForResultsWait:(BOOL)wait __attribute__((swift_name("useWaitForResults(wait:)")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol TruoraSharedKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface TruoraSharedKotlinEnum<E> : TruoraSharedBase <TruoraSharedKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CaptureStatus")))
@interface TruoraSharedCaptureStatus : TruoraSharedKotlinEnum<TruoraSharedCaptureStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedCaptureStatus *loading __attribute__((swift_name("loading")));
@property (class, readonly) TruoraSharedCaptureStatus *success __attribute__((swift_name("success")));
+ (TruoraSharedKotlinArray<TruoraSharedCaptureStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedCaptureStatus *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CapturedPhotoState")))
@interface TruoraSharedCapturedPhotoState : TruoraSharedBase
- (instancetype)initWithImageBitmap:(id<TruoraSharedUi_graphicsImageBitmap> _Nullable)imageBitmap status:(TruoraSharedCaptureStatus * _Nullable)status __attribute__((swift_name("init(imageBitmap:status:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedCapturedPhotoState *)doCopyImageBitmap:(id<TruoraSharedUi_graphicsImageBitmap> _Nullable)imageBitmap status:(TruoraSharedCaptureStatus * _Nullable)status __attribute__((swift_name("doCopy(imageBitmap:status:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<TruoraSharedUi_graphicsImageBitmap> _Nullable imageBitmap __attribute__((swift_name("imageBitmap")));
@property (readonly) TruoraSharedCaptureStatus * _Nullable status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("DocumentAutoCaptureEvent")))
@protocol TruoraSharedDocumentAutoCaptureEvent
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureEventBackPhotoCaptured")))
@interface TruoraSharedDocumentAutoCaptureEventBackPhotoCaptured : TruoraSharedBase <TruoraSharedDocumentAutoCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)backPhotoCaptured __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureEventBackPhotoCaptured *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureEventFrontPhotoCaptured")))
@interface TruoraSharedDocumentAutoCaptureEventFrontPhotoCaptured : TruoraSharedBase <TruoraSharedDocumentAutoCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)frontPhotoCaptured __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureEventFrontPhotoCaptured *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureEventHelpDismissed")))
@interface TruoraSharedDocumentAutoCaptureEventHelpDismissed : TruoraSharedBase <TruoraSharedDocumentAutoCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)helpDismissed __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureEventHelpDismissed *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureEventHelpRequested")))
@interface TruoraSharedDocumentAutoCaptureEventHelpRequested : TruoraSharedBase <TruoraSharedDocumentAutoCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)helpRequested __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureEventHelpRequested *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureEventManualCaptureRequested")))
@interface TruoraSharedDocumentAutoCaptureEventManualCaptureRequested : TruoraSharedBase <TruoraSharedDocumentAutoCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)manualCaptureRequested __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureEventManualCaptureRequested *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureEventRotationAnimationCompleted")))
@interface TruoraSharedDocumentAutoCaptureEventRotationAnimationCompleted : TruoraSharedBase <TruoraSharedDocumentAutoCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)rotationAnimationCompleted __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureEventRotationAnimationCompleted *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("DocumentAutoCaptureFeedbackEvent")))
@protocol TruoraSharedDocumentAutoCaptureFeedbackEvent
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureFeedbackEventDismissed")))
@interface TruoraSharedDocumentAutoCaptureFeedbackEventDismissed : TruoraSharedBase <TruoraSharedDocumentAutoCaptureFeedbackEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)dismissed __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureFeedbackEventDismissed *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureFeedbackEventRetryClicked")))
@interface TruoraSharedDocumentAutoCaptureFeedbackEventRetryClicked : TruoraSharedBase <TruoraSharedDocumentAutoCaptureFeedbackEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)retryClicked __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureFeedbackEventRetryClicked *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureFeedbackEventTipsClicked")))
@interface TruoraSharedDocumentAutoCaptureFeedbackEventTipsClicked : TruoraSharedBase <TruoraSharedDocumentAutoCaptureFeedbackEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)tipsClicked __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureFeedbackEventTipsClicked *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("DocumentAutoCaptureIntroEvent")))
@protocol TruoraSharedDocumentAutoCaptureIntroEvent
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureIntroEventCancelClicked")))
@interface TruoraSharedDocumentAutoCaptureIntroEventCancelClicked : TruoraSharedBase <TruoraSharedDocumentAutoCaptureIntroEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)cancelClicked __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureIntroEventCancelClicked *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentAutoCaptureIntroEventStartClicked")))
@interface TruoraSharedDocumentAutoCaptureIntroEventStartClicked : TruoraSharedBase <TruoraSharedDocumentAutoCaptureIntroEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)startClicked __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentAutoCaptureIntroEventStartClicked *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentCaptureSide")))
@interface TruoraSharedDocumentCaptureSide : TruoraSharedKotlinEnum<TruoraSharedDocumentCaptureSide *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedDocumentCaptureSide *front __attribute__((swift_name("front")));
@property (class, readonly) TruoraSharedDocumentCaptureSide *back __attribute__((swift_name("back")));
+ (TruoraSharedKotlinArray<TruoraSharedDocumentCaptureSide *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedDocumentCaptureSide *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentFeedbackType")))
@interface TruoraSharedDocumentFeedbackType : TruoraSharedKotlinEnum<TruoraSharedDocumentFeedbackType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedDocumentFeedbackType *none __attribute__((swift_name("none")));
@property (class, readonly) TruoraSharedDocumentFeedbackType *locate __attribute__((swift_name("locate")));
@property (class, readonly) TruoraSharedDocumentFeedbackType *closer __attribute__((swift_name("closer")));
@property (class, readonly) TruoraSharedDocumentFeedbackType *further __attribute__((swift_name("further")));
@property (class, readonly) TruoraSharedDocumentFeedbackType *rotate __attribute__((swift_name("rotate")));
@property (class, readonly) TruoraSharedDocumentFeedbackType *center __attribute__((swift_name("center")));
@property (class, readonly) TruoraSharedDocumentFeedbackType *scanning __attribute__((swift_name("scanning")));
@property (class, readonly) TruoraSharedDocumentFeedbackType *scanningManual __attribute__((swift_name("scanningManual")));
+ (TruoraSharedKotlinArray<TruoraSharedDocumentFeedbackType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedDocumentFeedbackType *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Enum representing different feedback scenarios for capture failures.
 * Used in DocumentAutoCaptureFeedback to display appropriate error messages.
 * Titles, descriptions, and error icons are loaded from resources for multi-language support.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FeedbackScenario")))
@interface TruoraSharedFeedbackScenario : TruoraSharedKotlinEnum<TruoraSharedFeedbackScenario *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Enum representing different feedback scenarios for capture failures.
 * Used in DocumentAutoCaptureFeedback to display appropriate error messages.
 * Titles, descriptions, and error icons are loaded from resources for multi-language support.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedFeedbackScenario *documentNotFound __attribute__((swift_name("documentNotFound")));
@property (class, readonly) TruoraSharedFeedbackScenario *faceNotFound __attribute__((swift_name("faceNotFound")));
@property (class, readonly) TruoraSharedFeedbackScenario *blurryImage __attribute__((swift_name("blurryImage")));
@property (class, readonly) TruoraSharedFeedbackScenario *lowLight __attribute__((swift_name("lowLight")));
@property (class, readonly) TruoraSharedFeedbackScenario *backOfDocumentNotFound __attribute__((swift_name("backOfDocumentNotFound")));
@property (class, readonly) TruoraSharedFeedbackScenario *frontOfDocumentNotFound __attribute__((swift_name("frontOfDocumentNotFound")));
@property (class, readonly) TruoraSharedFeedbackScenario *imageWithReflection __attribute__((swift_name("imageWithReflection")));
+ (TruoraSharedKotlinArray<TruoraSharedFeedbackScenario *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedFeedbackScenario *> *entries __attribute__((swift_name("entries")));
@property (readonly) TruoraSharedLibraryStringResource *descriptionResource __attribute__((swift_name("descriptionResource")));
@property (readonly) TruoraSharedLibraryDrawableResource *errorIconRes __attribute__((swift_name("errorIconRes")));
@property (readonly) TruoraSharedLibraryStringResource *titleResource __attribute__((swift_name("titleResource")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FeedbackType")))
@interface TruoraSharedFeedbackType : TruoraSharedKotlinEnum<TruoraSharedFeedbackType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedFeedbackType *none __attribute__((swift_name("none")));
@property (class, readonly) TruoraSharedFeedbackType *showFace __attribute__((swift_name("showFace")));
@property (class, readonly) TruoraSharedFeedbackType *removeGlasses __attribute__((swift_name("removeGlasses")));
@property (class, readonly) TruoraSharedFeedbackType *multiplePeople __attribute__((swift_name("multiplePeople")));
@property (class, readonly) TruoraSharedFeedbackType *hiddenFace __attribute__((swift_name("hiddenFace")));
@property (class, readonly) TruoraSharedFeedbackType *recording __attribute__((swift_name("recording")));
+ (TruoraSharedKotlinArray<TruoraSharedFeedbackType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedFeedbackType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("Platform")))
@protocol TruoraSharedPlatform
@required
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IOSPlatform")))
@interface TruoraSharedIOSPlatform : TruoraSharedBase <TruoraSharedPlatform>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end


/**
 * Enum representing the type of loading animation to display.
 * Each type encapsulates its own GIF resource and rendering logic.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoadingType")))
@interface TruoraSharedLoadingType : TruoraSharedKotlinEnum<TruoraSharedLoadingType *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Enum representing the type of loading animation to display.
 * Each type encapsulates its own GIF resource and rendering logic.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedLoadingType *document __attribute__((swift_name("document")));
@property (class, readonly) TruoraSharedLoadingType *face __attribute__((swift_name("face")));
+ (TruoraSharedKotlinArray<TruoraSharedLoadingType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedLoadingType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocalAppLocale")))
@interface TruoraSharedLocalAppLocale : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)localAppLocale __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedLocalAppLocale *shared __attribute__((swift_name("shared")));
@end


/**
 * Type of manual capture action
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ManualCaptureType")))
@interface TruoraSharedManualCaptureType : TruoraSharedKotlinEnum<TruoraSharedManualCaptureType *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Type of manual capture action
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedManualCaptureType *picture __attribute__((swift_name("picture")));
@property (class, readonly) TruoraSharedManualCaptureType *recording __attribute__((swift_name("recording")));
+ (TruoraSharedKotlinArray<TruoraSharedManualCaptureType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedManualCaptureType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("PassiveCaptureEvent")))
@protocol TruoraSharedPassiveCaptureEvent
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureEventCountdownFinished")))
@interface TruoraSharedPassiveCaptureEventCountdownFinished : TruoraSharedBase <TruoraSharedPassiveCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)countdownFinished __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedPassiveCaptureEventCountdownFinished *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureEventCountdownStarted")))
@interface TruoraSharedPassiveCaptureEventCountdownStarted : TruoraSharedBase <TruoraSharedPassiveCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)countdownStarted __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedPassiveCaptureEventCountdownStarted *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureEventFeedbackChanged")))
@interface TruoraSharedPassiveCaptureEventFeedbackChanged : TruoraSharedBase <TruoraSharedPassiveCaptureEvent>
- (instancetype)initWithFeedback:(TruoraSharedFeedbackType *)feedback __attribute__((swift_name("init(feedback:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedPassiveCaptureEventFeedbackChanged *)doCopyFeedback:(TruoraSharedFeedbackType *)feedback __attribute__((swift_name("doCopy(feedback:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedFeedbackType *feedback __attribute__((swift_name("feedback")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureEventHelpDismissed")))
@interface TruoraSharedPassiveCaptureEventHelpDismissed : TruoraSharedBase <TruoraSharedPassiveCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)helpDismissed __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedPassiveCaptureEventHelpDismissed *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureEventHelpRequested")))
@interface TruoraSharedPassiveCaptureEventHelpRequested : TruoraSharedBase <TruoraSharedPassiveCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)helpRequested __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedPassiveCaptureEventHelpRequested *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureEventManualRecordingRequested")))
@interface TruoraSharedPassiveCaptureEventManualRecordingRequested : TruoraSharedBase <TruoraSharedPassiveCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)manualRecordingRequested __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedPassiveCaptureEventManualRecordingRequested *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureEventRecordVideoRequested")))
@interface TruoraSharedPassiveCaptureEventRecordVideoRequested : TruoraSharedBase <TruoraSharedPassiveCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recordVideoRequested __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedPassiveCaptureEventRecordVideoRequested *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureEventRecordingCompleted")))
@interface TruoraSharedPassiveCaptureEventRecordingCompleted : TruoraSharedBase <TruoraSharedPassiveCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recordingCompleted __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedPassiveCaptureEventRecordingCompleted *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureEventRecordingStarted")))
@interface TruoraSharedPassiveCaptureEventRecordingStarted : TruoraSharedBase <TruoraSharedPassiveCaptureEvent>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recordingStarted __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedPassiveCaptureEventRecordingStarted *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureState")))
@interface TruoraSharedPassiveCaptureState : TruoraSharedKotlinEnum<TruoraSharedPassiveCaptureState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedPassiveCaptureState *countdown __attribute__((swift_name("countdown")));
@property (class, readonly) TruoraSharedPassiveCaptureState *recording __attribute__((swift_name("recording")));
@property (class, readonly) TruoraSharedPassiveCaptureState *manual __attribute__((swift_name("manual")));
+ (TruoraSharedKotlinArray<TruoraSharedPassiveCaptureState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedPassiveCaptureState *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Configuration for customizing Truora SDK colors.
 * All properties are nullable - null values will use Truora default colors.
 *
 * @property surface Surface/background color (Material3 standard)
 * @property onSurface Main text color (Material3 standard)
 * @property primary Primary brand color (Material3 standard)
 * @property onPrimary Color for content on primary (Material3 standard)
 * @property secondary Secondary color (Material3 standard - used for text and emphasis)
 * @property error Error color (Material3 standard - error border color)
 * @property primary600 Primary brand color (used for accents and highlights)
 * @property purpleDark Primary button color
 * @property tint00 Light tint color
 * @property tint20 Medium tint color
 * @property warning Warning/alert color
 * @property success Success/confirmation color
 * @property overlay Overlay background color
 * @property secondaryBg Secondary background color
 * @property infoBlue Info/help blue color
 * @property gray50 Lightest gray
 * @property gray200 Light gray
 * @property gray500 Medium gray
 * @property gray700 Dark gray
 * @property gray800 Darker gray
 * @property gray900 Darkest gray
 * @property red700 Error/danger color
 *
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraCustomColors")))
@interface TruoraSharedTruoraCustomColors : TruoraSharedBase
- (instancetype)initWithSurface:(id _Nullable)surface onSurface:(id _Nullable)onSurface primary:(id _Nullable)primary onPrimary:(id _Nullable)onPrimary secondary:(id _Nullable)secondary error:(id _Nullable)error tint00:(id _Nullable)tint00 tint20:(id _Nullable)tint20 warning:(id _Nullable)warning success:(id _Nullable)success overlay:(id _Nullable)overlay secondaryBg:(id _Nullable)secondaryBg infoBlue:(id _Nullable)infoBlue gray50:(id _Nullable)gray50 gray200:(id _Nullable)gray200 gray500:(id _Nullable)gray500 gray700:(id _Nullable)gray700 gray800:(id _Nullable)gray800 gray900:(id _Nullable)gray900 red700:(id _Nullable)red700 __attribute__((swift_name("init(surface:onSurface:primary:onPrimary:secondary:error:tint00:tint20:warning:success:overlay:secondaryBg:infoBlue:gray50:gray200:gray500:gray700:gray800:gray900:red700:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedTruoraCustomColors *)doCopySurface:(id _Nullable)surface onSurface:(id _Nullable)onSurface primary:(id _Nullable)primary onPrimary:(id _Nullable)onPrimary secondary:(id _Nullable)secondary error:(id _Nullable)error tint00:(id _Nullable)tint00 tint20:(id _Nullable)tint20 warning:(id _Nullable)warning success:(id _Nullable)success overlay:(id _Nullable)overlay secondaryBg:(id _Nullable)secondaryBg infoBlue:(id _Nullable)infoBlue gray50:(id _Nullable)gray50 gray200:(id _Nullable)gray200 gray500:(id _Nullable)gray500 gray700:(id _Nullable)gray700 gray800:(id _Nullable)gray800 gray900:(id _Nullable)gray900 red700:(id _Nullable)red700 __attribute__((swift_name("doCopy(surface:onSurface:primary:onPrimary:secondary:error:tint00:tint20:warning:success:overlay:secondaryBg:infoBlue:gray50:gray200:gray500:gray700:gray800:gray900:red700:)")));

/**
 * Configuration for customizing Truora SDK colors.
 * All properties are nullable - null values will use Truora default colors.
 *
 * @property surface Surface/background color (Material3 standard)
 * @property onSurface Main text color (Material3 standard)
 * @property primary Primary brand color (Material3 standard)
 * @property onPrimary Color for content on primary (Material3 standard)
 * @property secondary Secondary color (Material3 standard - used for text and emphasis)
 * @property error Error color (Material3 standard - error border color)
 * @property primary600 Primary brand color (used for accents and highlights)
 * @property purpleDark Primary button color
 * @property tint00 Light tint color
 * @property tint20 Medium tint color
 * @property warning Warning/alert color
 * @property success Success/confirmation color
 * @property overlay Overlay background color
 * @property secondaryBg Secondary background color
 * @property infoBlue Info/help blue color
 * @property gray50 Lightest gray
 * @property gray200 Light gray
 * @property gray500 Medium gray
 * @property gray700 Dark gray
 * @property gray800 Darker gray
 * @property gray900 Darkest gray
 * @property red700 Error/danger color
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Configuration for customizing Truora SDK colors.
 * All properties are nullable - null values will use Truora default colors.
 *
 * @property surface Surface/background color (Material3 standard)
 * @property onSurface Main text color (Material3 standard)
 * @property primary Primary brand color (Material3 standard)
 * @property onPrimary Color for content on primary (Material3 standard)
 * @property secondary Secondary color (Material3 standard - used for text and emphasis)
 * @property error Error color (Material3 standard - error border color)
 * @property primary600 Primary brand color (used for accents and highlights)
 * @property purpleDark Primary button color
 * @property tint00 Light tint color
 * @property tint20 Medium tint color
 * @property warning Warning/alert color
 * @property success Success/confirmation color
 * @property overlay Overlay background color
 * @property secondaryBg Secondary background color
 * @property infoBlue Info/help blue color
 * @property gray50 Lightest gray
 * @property gray200 Light gray
 * @property gray500 Medium gray
 * @property gray700 Dark gray
 * @property gray800 Darker gray
 * @property gray900 Darkest gray
 * @property red700 Error/danger color
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Configuration for customizing Truora SDK colors.
 * All properties are nullable - null values will use Truora default colors.
 *
 * @property surface Surface/background color (Material3 standard)
 * @property onSurface Main text color (Material3 standard)
 * @property primary Primary brand color (Material3 standard)
 * @property onPrimary Color for content on primary (Material3 standard)
 * @property secondary Secondary color (Material3 standard - used for text and emphasis)
 * @property error Error color (Material3 standard - error border color)
 * @property primary600 Primary brand color (used for accents and highlights)
 * @property purpleDark Primary button color
 * @property tint00 Light tint color
 * @property tint20 Medium tint color
 * @property warning Warning/alert color
 * @property success Success/confirmation color
 * @property overlay Overlay background color
 * @property secondaryBg Secondary background color
 * @property infoBlue Info/help blue color
 * @property gray50 Lightest gray
 * @property gray200 Light gray
 * @property gray500 Medium gray
 * @property gray700 Dark gray
 * @property gray800 Darker gray
 * @property gray900 Darkest gray
 * @property red700 Error/danger color
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id _Nullable error __attribute__((swift_name("error")));
@property (readonly) id _Nullable gray200 __attribute__((swift_name("gray200")));
@property (readonly) id _Nullable gray50 __attribute__((swift_name("gray50")));
@property (readonly) id _Nullable gray500 __attribute__((swift_name("gray500")));
@property (readonly) id _Nullable gray700 __attribute__((swift_name("gray700")));
@property (readonly) id _Nullable gray800 __attribute__((swift_name("gray800")));
@property (readonly) id _Nullable gray900 __attribute__((swift_name("gray900")));
@property (readonly) id _Nullable infoBlue __attribute__((swift_name("infoBlue")));
@property (readonly) id _Nullable onPrimary __attribute__((swift_name("onPrimary")));
@property (readonly) id _Nullable onSurface __attribute__((swift_name("onSurface")));
@property (readonly) id _Nullable overlay __attribute__((swift_name("overlay")));
@property (readonly) id _Nullable primary __attribute__((swift_name("primary")));
@property (readonly) id _Nullable red700 __attribute__((swift_name("red700")));
@property (readonly) id _Nullable secondary __attribute__((swift_name("secondary")));
@property (readonly) id _Nullable secondaryBg __attribute__((swift_name("secondaryBg")));
@property (readonly) id _Nullable success __attribute__((swift_name("success")));
@property (readonly) id _Nullable surface __attribute__((swift_name("surface")));
@property (readonly) id _Nullable tint00 __attribute__((swift_name("tint00")));
@property (readonly) id _Nullable tint20 __attribute__((swift_name("tint20")));
@property (readonly) id _Nullable warning __attribute__((swift_name("warning")));
@end


/**
 * Configuration for customizing the Truora logo displayed in the header.
 *
 * @property logoData Image data as ByteArray (PNG or JPEG format recommended)
 * @property width Optional width in dp for the logo (null = use default 103dp)
 * @property height Optional height in dp for the logo (null = use default 28dp)
 *
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraCustomLogo")))
@interface TruoraSharedTruoraCustomLogo : TruoraSharedBase
- (instancetype)initWithLogoData:(TruoraSharedKotlinByteArray *)logoData width:(TruoraSharedFloat * _Nullable)width height:(TruoraSharedFloat * _Nullable)height __attribute__((swift_name("init(logoData:width:height:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedTruoraCustomLogo *)doCopyLogoData:(TruoraSharedKotlinByteArray *)logoData width:(TruoraSharedFloat * _Nullable)width height:(TruoraSharedFloat * _Nullable)height __attribute__((swift_name("doCopy(logoData:width:height:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Configuration for customizing the Truora logo displayed in the header.
 *
 * @property logoData Image data as ByteArray (PNG or JPEG format recommended)
 * @property width Optional width in dp for the logo (null = use default 103dp)
 * @property height Optional height in dp for the logo (null = use default 28dp)
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedFloat * _Nullable height __attribute__((swift_name("height")));
@property (readonly) TruoraSharedKotlinByteArray *logoData __attribute__((swift_name("logoData")));
@property (readonly) TruoraSharedFloat * _Nullable width __attribute__((swift_name("width")));
@end


/**
 * Main configuration class for customizing Truora SDK UI.
 * All customization is optional - null values will use Truora defaults.
 *
 * Example usage from Android:
 * ```kotlin
 * val config = TruoraUIConfig(
 *     colors = TruoraCustomColors(
 *         surface = Color(0xFFFFFFFF),
 *         onSurface = Color(0xFF282828),
 *         primary = Color(0xFF3800C7),
 *         onPrimary = Color(0xFFFFFFFF),
 *         secondary = Color(0xFF082054),
 *         error = Color(0xFFFF5454)
 *     ),
 *     logo = TruoraCustomLogo(
 *         logoData = byteArrayFromBitmap(myLogoBitmap)
 *     )
 * )
 * ```
 *
 * Example usage from iOS (Swift):
 * ```swift
 * let config = TruoraUIConfig(
 *     colors: TruoraCustomColors(
 *         surface: Color(red: 1, green: 1, blue: 1, opacity: 1),
 *         onSurface: Color(red: 0.16, green: 0.16, blue: 0.16, opacity: 1),
 *         primary: Color(red: 0.22, green: 0, blue: 0.78, opacity: 1),
 *         onPrimary: Color(red: 1, green: 1, blue: 1, opacity: 1),
 *         secondary: Color(red: 0.03, green: 0.13, blue: 0.33, opacity: 1),
 *         error: Color(red: 1, green: 0.33, blue: 0.33, opacity: 1)
 *     ),
 *     logo: TruoraCustomLogo(
 *         logoData: UIImagePNGRepresentation(myLogo)!
 *     )
 * )
 * ```
 *
 * @property colors Custom color configuration
 * @property logo Custom logo configuration
 *
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraUIConfig")))
@interface TruoraSharedTruoraUIConfig : TruoraSharedBase
- (instancetype)initWithColors:(TruoraSharedTruoraCustomColors * _Nullable)colors logo:(TruoraSharedTruoraCustomLogo * _Nullable)logo __attribute__((swift_name("init(colors:logo:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedTruoraUIConfigCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedTruoraUIConfig *)doCopyColors:(TruoraSharedTruoraCustomColors * _Nullable)colors logo:(TruoraSharedTruoraCustomLogo * _Nullable)logo __attribute__((swift_name("doCopy(colors:logo:)")));

/**
 * Main configuration class for customizing Truora SDK UI.
 * All customization is optional - null values will use Truora defaults.
 *
 * Example usage from Android:
 * ```kotlin
 * val config = TruoraUIConfig(
 *     colors = TruoraCustomColors(
 *         surface = Color(0xFFFFFFFF),
 *         onSurface = Color(0xFF282828),
 *         primary = Color(0xFF3800C7),
 *         onPrimary = Color(0xFFFFFFFF),
 *         secondary = Color(0xFF082054),
 *         error = Color(0xFFFF5454)
 *     ),
 *     logo = TruoraCustomLogo(
 *         logoData = byteArrayFromBitmap(myLogoBitmap)
 *     )
 * )
 * ```
 *
 * Example usage from iOS (Swift):
 * ```swift
 * let config = TruoraUIConfig(
 *     colors: TruoraCustomColors(
 *         surface: Color(red: 1, green: 1, blue: 1, opacity: 1),
 *         onSurface: Color(red: 0.16, green: 0.16, blue: 0.16, opacity: 1),
 *         primary: Color(red: 0.22, green: 0, blue: 0.78, opacity: 1),
 *         onPrimary: Color(red: 1, green: 1, blue: 1, opacity: 1),
 *         secondary: Color(red: 0.03, green: 0.13, blue: 0.33, opacity: 1),
 *         error: Color(red: 1, green: 0.33, blue: 0.33, opacity: 1)
 *     ),
 *     logo: TruoraCustomLogo(
 *         logoData: UIImagePNGRepresentation(myLogo)!
 *     )
 * )
 * ```
 *
 * @property colors Custom color configuration
 * @property logo Custom logo configuration
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Main configuration class for customizing Truora SDK UI.
 * All customization is optional - null values will use Truora defaults.
 *
 * Example usage from Android:
 * ```kotlin
 * val config = TruoraUIConfig(
 *     colors = TruoraCustomColors(
 *         surface = Color(0xFFFFFFFF),
 *         onSurface = Color(0xFF282828),
 *         primary = Color(0xFF3800C7),
 *         onPrimary = Color(0xFFFFFFFF),
 *         secondary = Color(0xFF082054),
 *         error = Color(0xFFFF5454)
 *     ),
 *     logo = TruoraCustomLogo(
 *         logoData = byteArrayFromBitmap(myLogoBitmap)
 *     )
 * )
 * ```
 *
 * Example usage from iOS (Swift):
 * ```swift
 * let config = TruoraUIConfig(
 *     colors: TruoraCustomColors(
 *         surface: Color(red: 1, green: 1, blue: 1, opacity: 1),
 *         onSurface: Color(red: 0.16, green: 0.16, blue: 0.16, opacity: 1),
 *         primary: Color(red: 0.22, green: 0, blue: 0.78, opacity: 1),
 *         onPrimary: Color(red: 1, green: 1, blue: 1, opacity: 1),
 *         secondary: Color(red: 0.03, green: 0.13, blue: 0.33, opacity: 1),
 *         error: Color(red: 1, green: 0.33, blue: 0.33, opacity: 1)
 *     ),
 *     logo: TruoraCustomLogo(
 *         logoData: UIImagePNGRepresentation(myLogo)!
 *     )
 * )
 * ```
 *
 * @property colors Custom color configuration
 * @property logo Custom logo configuration
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Main configuration class for customizing Truora SDK UI.
 * All customization is optional - null values will use Truora defaults.
 *
 * Example usage from Android:
 * ```kotlin
 * val config = TruoraUIConfig(
 *     colors = TruoraCustomColors(
 *         surface = Color(0xFFFFFFFF),
 *         onSurface = Color(0xFF282828),
 *         primary = Color(0xFF3800C7),
 *         onPrimary = Color(0xFFFFFFFF),
 *         secondary = Color(0xFF082054),
 *         error = Color(0xFFFF5454)
 *     ),
 *     logo = TruoraCustomLogo(
 *         logoData = byteArrayFromBitmap(myLogoBitmap)
 *     )
 * )
 * ```
 *
 * Example usage from iOS (Swift):
 * ```swift
 * let config = TruoraUIConfig(
 *     colors: TruoraCustomColors(
 *         surface: Color(red: 1, green: 1, blue: 1, opacity: 1),
 *         onSurface: Color(red: 0.16, green: 0.16, blue: 0.16, opacity: 1),
 *         primary: Color(red: 0.22, green: 0, blue: 0.78, opacity: 1),
 *         onPrimary: Color(red: 1, green: 1, blue: 1, opacity: 1),
 *         secondary: Color(red: 0.03, green: 0.13, blue: 0.33, opacity: 1),
 *         error: Color(red: 1, green: 0.33, blue: 0.33, opacity: 1)
 *     ),
 *     logo: TruoraCustomLogo(
 *         logoData: UIImagePNGRepresentation(myLogo)!
 *     )
 * )
 * ```
 *
 * @property colors Custom color configuration
 * @property logo Custom logo configuration
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedTruoraCustomColors * _Nullable colors __attribute__((swift_name("colors")));
@property (readonly) TruoraSharedTruoraCustomLogo * _Nullable logo __attribute__((swift_name("logo")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraUIConfig.Companion")))
@interface TruoraSharedTruoraUIConfigCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedTruoraUIConfigCompanion *shared __attribute__((swift_name("shared")));

/**
 * Default configuration using Truora's brand colors and logo.
 */
@property (readonly) TruoraSharedTruoraUIConfig *Default __attribute__((swift_name("Default")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UploadState")))
@interface TruoraSharedUploadState : TruoraSharedKotlinEnum<TruoraSharedUploadState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedUploadState *none __attribute__((swift_name("none")));
@property (class, readonly) TruoraSharedUploadState *uploading __attribute__((swift_name("uploading")));
@property (class, readonly) TruoraSharedUploadState *success __attribute__((swift_name("success")));
+ (TruoraSharedKotlinArray<TruoraSharedUploadState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedUploadState *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Sealed interface representing events that can occur in the validation result screen.
 */
__attribute__((swift_name("ValidationResultEvent")))
@protocol TruoraSharedValidationResultEvent
@required
@end


/** Event triggered when the user clicks the finish/continue button */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationResultEventFinishClicked")))
@interface TruoraSharedValidationResultEventFinishClicked : TruoraSharedBase <TruoraSharedValidationResultEvent>
+ (instancetype)alloc __attribute__((unavailable));

/** Event triggered when the user clicks the finish/continue button */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)finishClicked __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedValidationResultEventFinishClicked *shared __attribute__((swift_name("shared")));

/** Event triggered when the user clicks the finish/continue button */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/** Event triggered when the user clicks the finish/continue button */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/** Event triggered when the user clicks the finish/continue button */
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * Represents the type of validation result to display.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationResultType")))
@interface TruoraSharedValidationResultType : TruoraSharedKotlinEnum<TruoraSharedValidationResultType *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Represents the type of validation result to display.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedValidationResultType *success __attribute__((swift_name("success")));
@property (class, readonly) TruoraSharedValidationResultType *completed __attribute__((swift_name("completed")));
@property (class, readonly) TruoraSharedValidationResultType *failure __attribute__((swift_name("failure")));
+ (TruoraSharedKotlinArray<TruoraSharedValidationResultType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedValidationResultType *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraExtendedColors")))
@interface TruoraSharedTruoraExtendedColors : TruoraSharedBase
- (instancetype)initWithSurface:(uint64_t)surface onSurface:(uint64_t)onSurface primary:(uint64_t)primary onPrimary:(uint64_t)onPrimary secondary:(uint64_t)secondary error:(uint64_t)error layoutTint00:(uint64_t)layoutTint00 layoutTint20:(uint64_t)layoutTint20 layoutWarning:(uint64_t)layoutWarning layoutSuccess:(uint64_t)layoutSuccess layoutOverlay:(uint64_t)layoutOverlay layoutInfoBlue:(uint64_t)layoutInfoBlue layoutGray50:(uint64_t)layoutGray50 layoutGray200:(uint64_t)layoutGray200 layoutGray500:(uint64_t)layoutGray500 layoutGray700:(uint64_t)layoutGray700 layoutGray800:(uint64_t)layoutGray800 layoutGray900:(uint64_t)layoutGray900 layoutRed700:(uint64_t)layoutRed700 documentAutocaptureBg:(uint64_t)documentAutocaptureBg __attribute__((swift_name("init(surface:onSurface:primary:onPrimary:secondary:error:layoutTint00:layoutTint20:layoutWarning:layoutSuccess:layoutOverlay:layoutInfoBlue:layoutGray50:layoutGray200:layoutGray500:layoutGray700:layoutGray800:layoutGray900:layoutRed700:documentAutocaptureBg:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedTruoraExtendedColors *)doCopySurface:(uint64_t)surface onSurface:(uint64_t)onSurface primary:(uint64_t)primary onPrimary:(uint64_t)onPrimary secondary:(uint64_t)secondary error:(uint64_t)error layoutTint00:(uint64_t)layoutTint00 layoutTint20:(uint64_t)layoutTint20 layoutWarning:(uint64_t)layoutWarning layoutSuccess:(uint64_t)layoutSuccess layoutOverlay:(uint64_t)layoutOverlay layoutInfoBlue:(uint64_t)layoutInfoBlue layoutGray50:(uint64_t)layoutGray50 layoutGray200:(uint64_t)layoutGray200 layoutGray500:(uint64_t)layoutGray500 layoutGray700:(uint64_t)layoutGray700 layoutGray800:(uint64_t)layoutGray800 layoutGray900:(uint64_t)layoutGray900 layoutRed700:(uint64_t)layoutRed700 documentAutocaptureBg:(uint64_t)documentAutocaptureBg __attribute__((swift_name("doCopy(surface:onSurface:primary:onPrimary:secondary:error:layoutTint00:layoutTint20:layoutWarning:layoutSuccess:layoutOverlay:layoutInfoBlue:layoutGray50:layoutGray200:layoutGray500:layoutGray700:layoutGray800:layoutGray900:layoutRed700:documentAutocaptureBg:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) uint64_t documentAutocaptureBg __attribute__((swift_name("documentAutocaptureBg")));
@property (readonly) uint64_t error __attribute__((swift_name("error")));
@property (readonly) uint64_t layoutGray200 __attribute__((swift_name("layoutGray200")));
@property (readonly) uint64_t layoutGray50 __attribute__((swift_name("layoutGray50")));
@property (readonly) uint64_t layoutGray500 __attribute__((swift_name("layoutGray500")));
@property (readonly) uint64_t layoutGray700 __attribute__((swift_name("layoutGray700")));
@property (readonly) uint64_t layoutGray800 __attribute__((swift_name("layoutGray800")));
@property (readonly) uint64_t layoutGray900 __attribute__((swift_name("layoutGray900")));
@property (readonly) uint64_t layoutInfoBlue __attribute__((swift_name("layoutInfoBlue")));
@property (readonly) uint64_t layoutOverlay __attribute__((swift_name("layoutOverlay")));
@property (readonly) uint64_t layoutRed700 __attribute__((swift_name("layoutRed700")));
@property (readonly) uint64_t layoutSuccess __attribute__((swift_name("layoutSuccess")));
@property (readonly) uint64_t layoutTint00 __attribute__((swift_name("layoutTint00")));
@property (readonly) uint64_t layoutTint20 __attribute__((swift_name("layoutTint20")));
@property (readonly) uint64_t layoutWarning __attribute__((swift_name("layoutWarning")));
@property (readonly) uint64_t onPrimary __attribute__((swift_name("onPrimary")));
@property (readonly) uint64_t onSurface __attribute__((swift_name("onSurface")));
@property (readonly) uint64_t primary __attribute__((swift_name("primary")));
@property (readonly) uint64_t secondary __attribute__((swift_name("secondary")));
@property (readonly) uint64_t surface __attribute__((swift_name("surface")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraTheme")))
@interface TruoraSharedTruoraTheme : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)truoraTheme __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedTruoraTheme *shared __attribute__((swift_name("shared")));
@end


/**
 * Main class for the Truora Validations
 * Provides access to both Enrollments and Validations APIs
 *
 * @param apiKey The resolved API key to use for API calls
 * @param baseUrl The base URL for the Validations API
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraValidations")))
@interface TruoraSharedTruoraValidations : TruoraSharedBase
- (instancetype)initWithApiKey:(NSString *)apiKey baseUrl:(NSString *)baseUrl __attribute__((swift_name("init(apiKey:baseUrl:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
@property (readonly) TruoraSharedValidationsApi *api __attribute__((swift_name("api"))) __attribute__((deprecated("Use 'validations' property instead. This property will be removed in a future version.")));
@property (readonly) TruoraSharedEnrollmentsApi *enrollments __attribute__((swift_name("enrollments")));
@property (readonly) TruoraSharedValidationsApi *validations __attribute__((swift_name("validations")));
@end


/**
 * Factory to create instances of the Truora Validations
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraValidationsFactory")))
@interface TruoraSharedTruoraValidationsFactory : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Factory to create instances of the Truora Validations
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)truoraValidationsFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedTruoraValidationsFactory *shared __attribute__((swift_name("shared")));

/**
 * Create a new instance of the Truora Validations with the API key
 * @param apiKey The resolved API key string (use ValidationsSDKHandler.getEffectiveApiKey())
 * @param baseUrl Optional custom base URL
 * @return Instance of TruoraValidations
 */
- (TruoraSharedTruoraValidations *)createApiKey:(NSString *)apiKey baseUrl:(NSString * _Nullable)baseUrl __attribute__((swift_name("create(apiKey:baseUrl:)")));
@end


/**
 * Client to Truora Enrollments API
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnrollmentsApi")))
@interface TruoraSharedEnrollmentsApi : TruoraSharedBase
- (instancetype)initWithHttpClient:(TruoraSharedTruoraHttpClient *)httpClient __attribute__((swift_name("init(httpClient:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedEnrollmentsApiCompanion *companion __attribute__((swift_name("companion")));

/**
 * Create a new enrollment
 * @param formData - Enrollment parameters as form data
 * @return HttpResponse with EnrollmentResponse
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createEnrollmentFormData:(NSDictionary<NSString *, NSString *> *)formData completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createEnrollment(formData:completionHandler:)")));

/**
 * Get enrollment status
 * @param enrollmentId - The enrollment ID to check
 * @return HttpResponse with EnrollmentStatusResponse
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getEnrollmentEnrollmentId:(NSString *)enrollmentId completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getEnrollment(enrollmentId:completionHandler:)")));

/**
 * Upload enrollment file to presigned URL
 * @param uploadUrl - Presigned URL from enrollment creation response
 * @param fileData - ByteArray of the reference image
 * @param contentType - MIME type (default: "image/jpeg")
 * @return HttpResponse
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)uploadFileUploadUrl:(NSString *)uploadUrl fileData:(TruoraSharedKotlinByteArray *)fileData contentType:(NSString *)contentType completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("uploadFile(uploadUrl:fileData:contentType:completionHandler:)")));

/**
 * Upload reference face image to presigned URL using platform-specific file handle.
 * Supports both local files (file://) and remote URLs (http://, https://).
 * For remote URLs, the file will be downloaded first, then uploaded.
 *
 * File size is validated before reading to prevent OutOfMemoryError.
 * Maximum allowed size is 10 MB.
 *
 * @param uploadUrl - Presigned URL from enrollment creation response
 * @param file - PlatformFileHandle pointing to the reference face image (local or remote)
 * @param contentType - Optional MIME type. If not provided, uses content type from file handle or defaults to "image/jpeg"
 * @return HttpResponse
 * @throws ValidationsException with FILE_TOO_LARGE if file exceeds maximum size
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)uploadReferenceFaceUploadUrl:(NSString *)uploadUrl file:(TruoraSharedPlatformFileHandle *)file contentType:(NSString * _Nullable)contentType completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("uploadReferenceFace(uploadUrl:file:contentType:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnrollmentsApi.Companion")))
@interface TruoraSharedEnrollmentsApiCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedEnrollmentsApiCompanion *shared __attribute__((swift_name("shared")));

/**
 * Maximum allowed file size for reference face images (10 MB).
 * Prevents OutOfMemoryError when loading large files into memory.
 */
@property (readonly) int64_t MAX_FILE_SIZE_BYTES __attribute__((swift_name("MAX_FILE_SIZE_BYTES")));
@end


/**
 * Helper object for parsing HTTP responses
 * This is exposed to Swift/Obj-C as a static class
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResponseParser")))
@interface TruoraSharedResponseParser : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Helper object for parsing HTTP responses
 * This is exposed to Swift/Obj-C as a static class
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)responseParser __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedResponseParser *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyAsTextResponse:(TruoraSharedKtor_client_coreHttpResponse *)response completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("bodyAsText(response:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)parseEnrollmentResponseResponse:(TruoraSharedKtor_client_coreHttpResponse *)response completionHandler:(void (^)(TruoraSharedEnrollmentResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("parseEnrollmentResponse(response:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)parseEnrollmentStatusResponseResponse:(TruoraSharedKtor_client_coreHttpResponse *)response completionHandler:(void (^)(TruoraSharedEnrollmentStatusResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("parseEnrollmentStatusResponse(response:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)parseValidationCreateResponseResponse:(TruoraSharedKtor_client_coreHttpResponse *)response completionHandler:(void (^)(TruoraSharedValidationCreateResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("parseValidationCreateResponse(response:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)parseValidationDetailResponseResponse:(TruoraSharedKtor_client_coreHttpResponse *)response completionHandler:(void (^)(TruoraSharedValidationDetailResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("parseValidationDetailResponse(response:completionHandler:)")));
@end


/**
 *  Client to Truora Validations API
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationsApi")))
@interface TruoraSharedValidationsApi : TruoraSharedBase
- (instancetype)initWithHttpClient:(TruoraSharedTruoraHttpClient *)httpClient __attribute__((swift_name("init(httpClient:)"))) __attribute__((objc_designated_initializer));

/**
 * Create a new validation
 * @param formData
 * @return a new HttpResponse
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)createValidationFormData:(NSDictionary<NSString *, NSString *> *)formData completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("createValidation(formData:completionHandler:)")));

/**
 * Get validation details
 * @param validationId
 * @return a new HttpResponse
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getValidationValidationId:(NSString *)validationId completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getValidation(validationId:completionHandler:)")));

/**
 * Upload validation file to presigned URL
 * @param uploadUrl - Presigned URL from validation creation response
 * @param fileData - ByteArray of the file to be validated
 * @param contentType - MIME type (default: "video/mp4")
 * @return HttpResponse with FileUploadResponse
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)uploadFileUploadUrl:(NSString *)uploadUrl fileData:(TruoraSharedKotlinByteArray *)fileData contentType:(NSString *)contentType completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("uploadFile(uploadUrl:fileData:contentType:completionHandler:)")));
@end


/**
 * Generic callback interface for Java interop with suspend functions
 *
 * Type parameters:
 * - T: The type of the success response (e.g., ValidationDetailResponse, String)
 * - E: The type of the failure response body (e.g., String, ErrorResponse)
 *
 * Callback methods:
 * - onSuccess: Called when HTTP status code is 2XX with the parsed response
 * - onFailure: Called when HTTP status code is not 2XX with the failure response
 * - onError: Called when there's an exception (network error, parsing error, etc.)
 *
 * Usage examples:
 * ```kotlin
 * val typedCallback = object : ValidationsCallback<ValidationDetailResponse, String> {
 *     override fun onSuccess(response: ValidationDetailResponse) {
 *     }
 *     override fun onFailure(statusCode: Int, response: String) { }
 *     override fun onError(error: Throwable) { }
 * }
 * ```
 */
__attribute__((swift_name("ValidationsCallback")))
@protocol TruoraSharedValidationsCallback
@required

/**
 * Called when an exception occurs (network error, parsing error, etc.)
 * @param error The throwable that caused the error
 */
- (void)onErrorError:(TruoraSharedKotlinThrowable *)error __attribute__((swift_name("onError(error:)")));

/**
 * Called when the API request fails (non-2XX HTTP status code)
 * @param statusCode The HTTP status code (e.g., 400, 404, 500)
 * @param response The parsed or raw response body of type E (may contain error details)
 */
- (void)onFailureStatusCode:(int32_t)statusCode response:(id _Nullable)response __attribute__((swift_name("onFailure(statusCode:response:)")));

/**
 * Called when the API request succeeds (HTTP 2XX)
 * @param response The parsed response of type T
 */
- (void)onSuccessResponse:(id _Nullable)response __attribute__((swift_name("onSuccess(response:)")));
@end


/**
 * Enum defining validation error types
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationsErrorType")))
@interface TruoraSharedValidationsErrorType : TruoraSharedKotlinEnum<TruoraSharedValidationsErrorType *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Enum defining validation error types
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedValidationsErrorType *formDataEmpty __attribute__((swift_name("formDataEmpty")));
@property (class, readonly) TruoraSharedValidationsErrorType *emptyValidationId __attribute__((swift_name("emptyValidationId")));
@property (class, readonly) TruoraSharedValidationsErrorType *emptyEnrollmentId __attribute__((swift_name("emptyEnrollmentId")));
@property (class, readonly) TruoraSharedValidationsErrorType *requestFailed __attribute__((swift_name("requestFailed")));
@property (class, readonly) TruoraSharedValidationsErrorType *emptyUploadUrl __attribute__((swift_name("emptyUploadUrl")));
@property (class, readonly) TruoraSharedValidationsErrorType *emptyFileData __attribute__((swift_name("emptyFileData")));
@property (class, readonly) TruoraSharedValidationsErrorType *uploadFailed __attribute__((swift_name("uploadFailed")));
@property (class, readonly) TruoraSharedValidationsErrorType *fileTooLarge __attribute__((swift_name("fileTooLarge")));
+ (TruoraSharedKotlinArray<TruoraSharedValidationsErrorType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedValidationsErrorType *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface TruoraSharedKotlinThrowable : TruoraSharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (TruoraSharedKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface TruoraSharedKotlinException : TruoraSharedKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * Exception class for validation errors
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationsException")))
@interface TruoraSharedValidationsException : TruoraSharedKotlinException
- (instancetype)initWithErrorType:(TruoraSharedValidationsErrorType *)errorType cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(errorType:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) TruoraSharedValidationsErrorType *errorType __attribute__((swift_name("errorType")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((swift_name("ApiKeyException")))
@interface TruoraSharedApiKeyException : TruoraSharedKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiKeyException.GenerationFailed")))
@interface TruoraSharedApiKeyExceptionGenerationFailed : TruoraSharedApiKeyException
- (instancetype)initWithCause:(TruoraSharedKotlinThrowable *)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiKeyException.InvalidJwtFormat")))
@interface TruoraSharedApiKeyExceptionInvalidJwtFormat : TruoraSharedApiKeyException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiKeyException.InvalidKeyType")))
@interface TruoraSharedApiKeyExceptionInvalidKeyType : TruoraSharedApiKeyException
- (instancetype)initWithKeyType:(NSString *)keyType __attribute__((swift_name("init(keyType:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiKeyException.MissingKeyType")))
@interface TruoraSharedApiKeyExceptionMissingKeyType : TruoraSharedApiKeyException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end


/**
 * HTTP client for generating SDK API keys from generator keys.
 * Calls the Truora Account API to create temporary SDK keys.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiKeyGeneratorClient")))
@interface TruoraSharedApiKeyGeneratorClient : TruoraSharedBase
- (instancetype)initWithBaseUrl:(NSString *)baseUrl httpClient:(TruoraSharedKtor_client_coreHttpClient *)httpClient __attribute__((swift_name("init(baseUrl:httpClient:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedApiKeyGeneratorClientCompanion *companion __attribute__((swift_name("companion")));

/**
 * Close the HTTP client
 */
- (void)close __attribute__((swift_name("close()")));

/**
 * Generate an SDK API key using a generator API key
 * @param generatorKey The generator API key (JWT with key_type=generator)
 * @return ApiKeyResponse containing the newly generated SDK key
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)generateSdkKeyGeneratorKey:(NSString *)generatorKey completionHandler:(void (^)(TruoraSharedApiKeyResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("generateSdkKey(generatorKey:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiKeyGeneratorClient.Companion")))
@interface TruoraSharedApiKeyGeneratorClientCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedApiKeyGeneratorClientCompanion *shared __attribute__((swift_name("shared")));
@end


/**
 * Manager for API key validation and resolution.
 * Handles both SDK keys (direct use) and generator keys (requires API call to generate SDK key).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiKeyManager")))
@interface TruoraSharedApiKeyManager : TruoraSharedBase
- (instancetype)initWithJwtDecoder:(TruoraSharedJwtDecoder *)jwtDecoder apiKeyClient:(TruoraSharedApiKeyGeneratorClient *)apiKeyClient __attribute__((swift_name("init(jwtDecoder:apiKeyClient:)"))) __attribute__((objc_designated_initializer));

/**
 * Close resources
 */
- (void)close __attribute__((swift_name("close()")));

/**
 * Resolve the provided API key to a usable SDK key.
 *
 * - If key_type is "sdk": returns the key as-is
 * - If key_type is "generator": generates a new SDK key via API call
 *
 * @param providedApiKey The API key provided by the user (JWT)
 * @return The resolved SDK API key ready to use
 * @throws ApiKeyException if validation or generation fails
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)resolveApiKeyProvidedApiKey:(NSString *)providedApiKey completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("resolveApiKey(providedApiKey:completionHandler:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiKeyResponse")))
@interface TruoraSharedApiKeyResponse : TruoraSharedBase
- (instancetype)initWithApi_key:(NSString *)api_key message:(NSString *)message __attribute__((swift_name("init(api_key:message:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedApiKeyResponseCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedApiKeyResponse *)doCopyApi_key:(NSString *)api_key message:(NSString *)message __attribute__((swift_name("doCopy(api_key:message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *api_key __attribute__((swift_name("api_key")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiKeyResponse.Companion")))
@interface TruoraSharedApiKeyResponseCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedApiKeyResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Constants for API key types used in JWT payloads.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiKeyTypes")))
@interface TruoraSharedApiKeyTypes : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Constants for API key types used in JWT payloads.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)apiKeyTypes __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedApiKeyTypes *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *GENERATOR __attribute__((swift_name("GENERATOR")));
@property (readonly) NSString *SDK __attribute__((swift_name("SDK")));
@end


/**
 * Simple JWT decoder that extracts claims from the payload without signature verification.
 * This is sufficient for extracting key_type from trusted API keys.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JwtDecoder")))
@interface TruoraSharedJwtDecoder : TruoraSharedBase

/**
 * Simple JWT decoder that extracts claims from the payload without signature verification.
 * This is sufficient for extracting key_type from trusted API keys.
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Simple JWT decoder that extracts claims from the payload without signature verification.
 * This is sufficient for extracting key_type from trusted API keys.
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * Extract key_type from JWT payload
 */
- (NSString *)extractKeyTypeJwt:(NSString *)jwt __attribute__((swift_name("extractKeyType(jwt:)")));
@end


/**
 * Age range model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AgeRange")))
@interface TruoraSharedAgeRange : TruoraSharedBase
- (instancetype)initWithHigh:(int32_t)high low:(int32_t)low __attribute__((swift_name("init(high:low:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedAgeRangeCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedAgeRange *)doCopyHigh:(int32_t)high low:(int32_t)low __attribute__((swift_name("doCopy(high:low:)")));

/**
 * Age range model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Age range model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Age range model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t high __attribute__((swift_name("high")));
@property (readonly) int32_t low __attribute__((swift_name("low")));
@end


/**
 * Age range model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AgeRange.Companion")))
@interface TruoraSharedAgeRangeCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Age range model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedAgeRangeCompanion *shared __attribute__((swift_name("shared")));

/**
 * Age range model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * API error response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiError")))
@interface TruoraSharedApiError : TruoraSharedBase
- (instancetype)initWithCode:(NSString *)code http_code:(int32_t)http_code message:(NSString *)message __attribute__((swift_name("init(code:http_code:message:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedApiErrorCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedApiError *)doCopyCode:(NSString *)code http_code:(int32_t)http_code message:(NSString *)message __attribute__((swift_name("doCopy(code:http_code:message:)")));

/**
 * API error response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * API error response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * API error response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *code __attribute__((swift_name("code")));
@property (readonly) int32_t http_code __attribute__((swift_name("http_code")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end


/**
 * API error response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiError.Companion")))
@interface TruoraSharedApiErrorCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * API error response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedApiErrorCompanion *shared __attribute__((swift_name("shared")));

/**
 * API error response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Background check response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BackgroundCheck")))
@interface TruoraSharedBackgroundCheck : TruoraSharedBase
- (instancetype)initWithCheck_id:(NSString *)check_id check_url:(NSString *)check_url __attribute__((swift_name("init(check_id:check_url:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedBackgroundCheckCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedBackgroundCheck *)doCopyCheck_id:(NSString *)check_id check_url:(NSString *)check_url __attribute__((swift_name("doCopy(check_id:check_url:)")));

/**
 * Background check response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Background check response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Background check response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *check_id __attribute__((swift_name("check_id")));
@property (readonly) NSString *check_url __attribute__((swift_name("check_url")));
@end


/**
 * Background check response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BackgroundCheck.Companion")))
@interface TruoraSharedBackgroundCheckCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Background check response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedBackgroundCheckCompanion *shared __attribute__((swift_name("shared")));

/**
 * Background check response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Supported countries
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Countries")))
@interface TruoraSharedCountries : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Supported countries
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)countries __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedCountries *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *AR __attribute__((swift_name("AR")));
@property (readonly) NSString *CL __attribute__((swift_name("CL")));
@property (readonly) NSString *CO __attribute__((swift_name("CO")));
@property (readonly) NSString *MX __attribute__((swift_name("MX")));
@property (readonly) NSString *PE __attribute__((swift_name("PE")));
@end


/**
 * Document details response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentDetails")))
@interface TruoraSharedDocumentDetails : TruoraSharedBase
- (instancetype)initWithBirth_place:(NSString * _Nullable)birth_place client_id:(NSString * _Nullable)client_id country:(NSString * _Nullable)country creation_date:(NSString * _Nullable)creation_date date_of_birth:(NSString * _Nullable)date_of_birth doc_id:(NSString * _Nullable)doc_id document_number:(NSString * _Nullable)document_number document_type:(NSString * _Nullable)document_type expedition_place:(NSString * _Nullable)expedition_place expiration_date:(NSString * _Nullable)expiration_date gender:(NSString * _Nullable)gender height:(NSString * _Nullable)height issue_date:(NSString * _Nullable)issue_date last_name:(NSString * _Nullable)last_name mime_type:(NSString * _Nullable)mime_type name:(NSString * _Nullable)name rh:(NSString * _Nullable)rh __attribute__((swift_name("init(birth_place:client_id:country:creation_date:date_of_birth:doc_id:document_number:document_type:expedition_place:expiration_date:gender:height:issue_date:last_name:mime_type:name:rh:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedDocumentDetailsCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedDocumentDetails *)doCopyBirth_place:(NSString * _Nullable)birth_place client_id:(NSString * _Nullable)client_id country:(NSString * _Nullable)country creation_date:(NSString * _Nullable)creation_date date_of_birth:(NSString * _Nullable)date_of_birth doc_id:(NSString * _Nullable)doc_id document_number:(NSString * _Nullable)document_number document_type:(NSString * _Nullable)document_type expedition_place:(NSString * _Nullable)expedition_place expiration_date:(NSString * _Nullable)expiration_date gender:(NSString * _Nullable)gender height:(NSString * _Nullable)height issue_date:(NSString * _Nullable)issue_date last_name:(NSString * _Nullable)last_name mime_type:(NSString * _Nullable)mime_type name:(NSString * _Nullable)name rh:(NSString * _Nullable)rh __attribute__((swift_name("doCopy(birth_place:client_id:country:creation_date:date_of_birth:doc_id:document_number:document_type:expedition_place:expiration_date:gender:height:issue_date:last_name:mime_type:name:rh:)")));

/**
 * Document details response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Document details response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Document details response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable birth_place __attribute__((swift_name("birth_place")));
@property (readonly) NSString * _Nullable client_id __attribute__((swift_name("client_id")));
@property (readonly) NSString * _Nullable country __attribute__((swift_name("country")));
@property (readonly) NSString * _Nullable creation_date __attribute__((swift_name("creation_date")));
@property (readonly) NSString * _Nullable date_of_birth __attribute__((swift_name("date_of_birth")));
@property (readonly) NSString * _Nullable doc_id __attribute__((swift_name("doc_id")));
@property (readonly) NSString * _Nullable document_number __attribute__((swift_name("document_number")));
@property (readonly) NSString * _Nullable document_type __attribute__((swift_name("document_type")));
@property (readonly) NSString * _Nullable expedition_place __attribute__((swift_name("expedition_place")));
@property (readonly) NSString * _Nullable expiration_date __attribute__((swift_name("expiration_date")));
@property (readonly) NSString * _Nullable gender __attribute__((swift_name("gender")));
@property (readonly) NSString * _Nullable height __attribute__((swift_name("height")));
@property (readonly) NSString * _Nullable issue_date __attribute__((swift_name("issue_date")));
@property (readonly) NSString * _Nullable last_name __attribute__((swift_name("last_name")));
@property (readonly) NSString * _Nullable mime_type __attribute__((swift_name("mime_type")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) NSString * _Nullable rh __attribute__((swift_name("rh")));
@end


/**
 * Document details response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentDetails.Companion")))
@interface TruoraSharedDocumentDetailsCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Document details response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentDetailsCompanion *shared __attribute__((swift_name("shared")));

/**
 * Document details response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Document sub validations response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentSubValidations")))
@interface TruoraSharedDocumentSubValidations : TruoraSharedBase
- (instancetype)initWithData_consistency:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)data_consistency government_database:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)government_database image_analysis:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)image_analysis photocopy_analysis:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)photocopy_analysis manual_analysis:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)manual_analysis photo_of_photo:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)photo_of_photo __attribute__((swift_name("init(data_consistency:government_database:image_analysis:photocopy_analysis:manual_analysis:photo_of_photo:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedDocumentSubValidationsCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedDocumentSubValidations *)doCopyData_consistency:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)data_consistency government_database:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)government_database image_analysis:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)image_analysis photocopy_analysis:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)photocopy_analysis manual_analysis:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)manual_analysis photo_of_photo:(NSArray<TruoraSharedSubValidationResult *> * _Nullable)photo_of_photo __attribute__((swift_name("doCopy(data_consistency:government_database:image_analysis:photocopy_analysis:manual_analysis:photo_of_photo:)")));

/**
 * Document sub validations response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Document sub validations response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Document sub validations response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<TruoraSharedSubValidationResult *> * _Nullable data_consistency __attribute__((swift_name("data_consistency")));
@property (readonly) NSArray<TruoraSharedSubValidationResult *> * _Nullable government_database __attribute__((swift_name("government_database")));
@property (readonly) NSArray<TruoraSharedSubValidationResult *> * _Nullable image_analysis __attribute__((swift_name("image_analysis")));
@property (readonly) NSArray<TruoraSharedSubValidationResult *> * _Nullable manual_analysis __attribute__((swift_name("manual_analysis")));
@property (readonly) NSArray<TruoraSharedSubValidationResult *> * _Nullable photo_of_photo __attribute__((swift_name("photo_of_photo")));
@property (readonly) NSArray<TruoraSharedSubValidationResult *> * _Nullable photocopy_analysis __attribute__((swift_name("photocopy_analysis")));
@end


/**
 * Document sub validations response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentSubValidations.Companion")))
@interface TruoraSharedDocumentSubValidationsCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Document sub validations response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentSubValidationsCompanion *shared __attribute__((swift_name("shared")));

/**
 * Document sub validations response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Supported document types
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DocumentTypes")))
@interface TruoraSharedDocumentTypes : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Supported document types
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)documentTypes __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedDocumentTypes *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *DRIVER_LICENSE __attribute__((swift_name("DRIVER_LICENSE")));
@property (readonly) NSString *FOREIGN_ID __attribute__((swift_name("FOREIGN_ID")));
@property (readonly) NSString *NATIONAL_ID __attribute__((swift_name("NATIONAL_ID")));
@property (readonly) NSString *PASSPORT __attribute__((swift_name("PASSPORT")));
@end


/**
 * Enrollment request model for face recognition
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnrollmentRequest")))
@interface TruoraSharedEnrollmentRequest : TruoraSharedBase
- (instancetype)initWithType:(NSString *)type user_authorized:(BOOL)user_authorized account_id:(NSString * _Nullable)account_id confirmation:(NSString * _Nullable)confirmation __attribute__((swift_name("init(type:user_authorized:account_id:confirmation:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedEnrollmentRequestCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedEnrollmentRequest *)doCopyType:(NSString *)type user_authorized:(BOOL)user_authorized account_id:(NSString * _Nullable)account_id confirmation:(NSString * _Nullable)confirmation __attribute__((swift_name("doCopy(type:user_authorized:account_id:confirmation:)")));

/**
 * Enrollment request model for face recognition
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Enrollment request model for face recognition
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSDictionary<NSString *, NSString *> *)toFormData __attribute__((swift_name("toFormData()")));

/**
 * Enrollment request model for face recognition
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable account_id __attribute__((swift_name("account_id")));
@property (readonly) NSString * _Nullable confirmation __attribute__((swift_name("confirmation")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@property (readonly) BOOL user_authorized __attribute__((swift_name("user_authorized")));
@end


/**
 * Enrollment request model for face recognition
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnrollmentRequest.Companion")))
@interface TruoraSharedEnrollmentRequestCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Enrollment request model for face recognition
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedEnrollmentRequestCompanion *shared __attribute__((swift_name("shared")));

/**
 * Enrollment request model for face recognition
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Enrollment creation response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnrollmentResponse")))
@interface TruoraSharedEnrollmentResponse : TruoraSharedBase
- (instancetype)initWithEnrollment_id:(NSString *)enrollment_id account_id:(NSString *)account_id file_upload_link:(NSString * _Nullable)file_upload_link status:(NSString *)status reason:(NSString * _Nullable)reason creation_date:(NSString *)creation_date user_authorized:(BOOL)user_authorized __attribute__((swift_name("init(enrollment_id:account_id:file_upload_link:status:reason:creation_date:user_authorized:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedEnrollmentResponseCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedEnrollmentResponse *)doCopyEnrollment_id:(NSString *)enrollment_id account_id:(NSString *)account_id file_upload_link:(NSString * _Nullable)file_upload_link status:(NSString *)status reason:(NSString * _Nullable)reason creation_date:(NSString *)creation_date user_authorized:(BOOL)user_authorized __attribute__((swift_name("doCopy(enrollment_id:account_id:file_upload_link:status:reason:creation_date:user_authorized:)")));

/**
 * Enrollment creation response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Enrollment creation response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Enrollment creation response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *account_id __attribute__((swift_name("account_id")));
@property (readonly) NSString *creation_date __attribute__((swift_name("creation_date")));
@property (readonly) NSString *enrollment_id __attribute__((swift_name("enrollment_id")));
@property (readonly) NSString * _Nullable file_upload_link __attribute__((swift_name("file_upload_link")));
@property (readonly) NSString * _Nullable reason __attribute__((swift_name("reason")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) BOOL user_authorized __attribute__((swift_name("user_authorized")));
@end


/**
 * Enrollment creation response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnrollmentResponse.Companion")))
@interface TruoraSharedEnrollmentResponseCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Enrollment creation response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedEnrollmentResponseCompanion *shared __attribute__((swift_name("shared")));

/**
 * Enrollment creation response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Enrollment status response model (when checking enrollment)
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnrollmentStatusResponse")))
@interface TruoraSharedEnrollmentStatusResponse : TruoraSharedBase
- (instancetype)initWithEnrollment_id:(NSString *)enrollment_id account_id:(NSString *)account_id status:(NSString *)status reason:(NSString * _Nullable)reason creation_date:(NSString *)creation_date file_upload_link:(NSString * _Nullable)file_upload_link __attribute__((swift_name("init(enrollment_id:account_id:status:reason:creation_date:file_upload_link:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedEnrollmentStatusResponseCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedEnrollmentStatusResponse *)doCopyEnrollment_id:(NSString *)enrollment_id account_id:(NSString *)account_id status:(NSString *)status reason:(NSString * _Nullable)reason creation_date:(NSString *)creation_date file_upload_link:(NSString * _Nullable)file_upload_link __attribute__((swift_name("doCopy(enrollment_id:account_id:status:reason:creation_date:file_upload_link:)")));

/**
 * Enrollment status response model (when checking enrollment)
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Enrollment status response model (when checking enrollment)
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Enrollment status response model (when checking enrollment)
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *account_id __attribute__((swift_name("account_id")));
@property (readonly) NSString *creation_date __attribute__((swift_name("creation_date")));
@property (readonly) NSString *enrollment_id __attribute__((swift_name("enrollment_id")));
@property (readonly) NSString * _Nullable file_upload_link __attribute__((swift_name("file_upload_link")));
@property (readonly) NSString * _Nullable reason __attribute__((swift_name("reason")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@end


/**
 * Enrollment status response model (when checking enrollment)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnrollmentStatusResponse.Companion")))
@interface TruoraSharedEnrollmentStatusResponseCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Enrollment status response model (when checking enrollment)
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedEnrollmentStatusResponseCompanion *shared __attribute__((swift_name("shared")));

/**
 * Enrollment status response model (when checking enrollment)
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Event levels for logging
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventLevel")))
@interface TruoraSharedEventLevel : TruoraSharedKotlinEnum<TruoraSharedEventLevel *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Event levels for logging
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedEventLevelCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) TruoraSharedEventLevel *info __attribute__((swift_name("info")));
@property (class, readonly) TruoraSharedEventLevel *warning __attribute__((swift_name("warning")));
@property (class, readonly) TruoraSharedEventLevel *error __attribute__((swift_name("error")));
@property (class, readonly) TruoraSharedEventLevel *fatal __attribute__((swift_name("fatal")));
+ (TruoraSharedKotlinArray<TruoraSharedEventLevel *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedEventLevel *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Event levels for logging
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventLevel.Companion")))
@interface TruoraSharedEventLevelCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Event levels for logging
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedEventLevelCompanion *shared __attribute__((swift_name("shared")));

/**
 * Event levels for logging
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));

/**
 * Event levels for logging
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(TruoraSharedKotlinArray<id<TruoraSharedKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * Event types supported by the SDK log API
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventType")))
@interface TruoraSharedEventType : TruoraSharedKotlinEnum<TruoraSharedEventType *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Event types supported by the SDK log API
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedEventTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) TruoraSharedEventType *camera __attribute__((swift_name("camera")));
@property (class, readonly) TruoraSharedEventType *mlModel __attribute__((swift_name("mlModel")));
@property (class, readonly) TruoraSharedEventType *view __attribute__((swift_name("view")));
@property (class, readonly) TruoraSharedEventType *device __attribute__((swift_name("device")));
+ (TruoraSharedKotlinArray<TruoraSharedEventType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedEventType *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Event types supported by the SDK log API
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventType.Companion")))
@interface TruoraSharedEventTypeCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Event types supported by the SDK log API
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedEventTypeCompanion *shared __attribute__((swift_name("shared")));

/**
 * Event types supported by the SDK log API
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));

/**
 * Event types supported by the SDK log API
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(TruoraSharedKotlinArray<id<TruoraSharedKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * Face recognition details response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FaceRecognitionDetails")))
@interface TruoraSharedFaceRecognitionDetails : TruoraSharedBase
- (instancetype)initWithEnrollment_id:(NSString * _Nullable)enrollment_id similarity_status:(NSString * _Nullable)similarity_status age_range:(TruoraSharedAgeRange * _Nullable)age_range passive_liveness_status:(NSString * _Nullable)passive_liveness_status face_search:(TruoraSharedFaceSearch * _Nullable)face_search confidence_score:(TruoraSharedDouble * _Nullable)confidence_score __attribute__((swift_name("init(enrollment_id:similarity_status:age_range:passive_liveness_status:face_search:confidence_score:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedFaceRecognitionDetailsCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedFaceRecognitionDetails *)doCopyEnrollment_id:(NSString * _Nullable)enrollment_id similarity_status:(NSString * _Nullable)similarity_status age_range:(TruoraSharedAgeRange * _Nullable)age_range passive_liveness_status:(NSString * _Nullable)passive_liveness_status face_search:(TruoraSharedFaceSearch * _Nullable)face_search confidence_score:(TruoraSharedDouble * _Nullable)confidence_score __attribute__((swift_name("doCopy(enrollment_id:similarity_status:age_range:passive_liveness_status:face_search:confidence_score:)")));

/**
 * Face recognition details response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Face recognition details response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Face recognition details response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedAgeRange * _Nullable age_range __attribute__((swift_name("age_range")));
@property (readonly) TruoraSharedDouble * _Nullable confidence_score __attribute__((swift_name("confidence_score")));
@property (readonly) NSString * _Nullable enrollment_id __attribute__((swift_name("enrollment_id")));
@property (readonly) TruoraSharedFaceSearch * _Nullable face_search __attribute__((swift_name("face_search")));
@property (readonly) NSString * _Nullable passive_liveness_status __attribute__((swift_name("passive_liveness_status")));
@property (readonly) NSString * _Nullable similarity_status __attribute__((swift_name("similarity_status")));
@end


/**
 * Face recognition details response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FaceRecognitionDetails.Companion")))
@interface TruoraSharedFaceRecognitionDetailsCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Face recognition details response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedFaceRecognitionDetailsCompanion *shared __attribute__((swift_name("shared")));

/**
 * Face recognition details response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Face search results model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FaceSearch")))
@interface TruoraSharedFaceSearch : TruoraSharedBase
- (instancetype)initWithStatus:(NSString *)status confidence_score:(double)confidence_score __attribute__((swift_name("init(status:confidence_score:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedFaceSearchCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedFaceSearch *)doCopyStatus:(NSString *)status confidence_score:(double)confidence_score __attribute__((swift_name("doCopy(status:confidence_score:)")));

/**
 * Face search results model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Face search results model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Face search results model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) double confidence_score __attribute__((swift_name("confidence_score")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@end


/**
 * Face search results model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FaceSearch.Companion")))
@interface TruoraSharedFaceSearchCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Face search results model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedFaceSearchCompanion *shared __attribute__((swift_name("shared")));

/**
 * Face search results model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Failure status enum
 * Represents the possible failure status values returned by the API
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FailureStatus")))
@interface TruoraSharedFailureStatus : TruoraSharedKotlinEnum<TruoraSharedFailureStatus *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Failure status enum
 * Represents the possible failure status values returned by the API
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedFailureStatusCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) TruoraSharedFailureStatus *declined __attribute__((swift_name("declined")));
@property (class, readonly) TruoraSharedFailureStatus *expired __attribute__((swift_name("expired")));
@property (class, readonly) TruoraSharedFailureStatus *systemError __attribute__((swift_name("systemError")));
+ (TruoraSharedKotlinArray<TruoraSharedFailureStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedFailureStatus *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Failure status enum
 * Represents the possible failure status values returned by the API
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FailureStatus.Companion")))
@interface TruoraSharedFailureStatusCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Failure status enum
 * Represents the possible failure status values returned by the API
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedFailureStatusCompanion *shared __attribute__((swift_name("shared")));

/**
 * Failure status enum
 * Represents the possible failure status values returned by the API
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));

/**
 * Failure status enum
 * Represents the possible failure status values returned by the API
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(TruoraSharedKotlinArray<id<TruoraSharedKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * File upload response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FileUploadResponse")))
@interface TruoraSharedFileUploadResponse : TruoraSharedBase
- (instancetype)initWithCode:(int32_t)code http_code:(int32_t)http_code message:(NSString *)message __attribute__((swift_name("init(code:http_code:message:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedFileUploadResponseCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedFileUploadResponse *)doCopyCode:(int32_t)code http_code:(int32_t)http_code message:(NSString *)message __attribute__((swift_name("doCopy(code:http_code:message:)")));

/**
 * File upload response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * File upload response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * File upload response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t code __attribute__((swift_name("code")));
@property (readonly) int32_t http_code __attribute__((swift_name("http_code")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end


/**
 * File upload response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FileUploadResponse.Companion")))
@interface TruoraSharedFileUploadResponseCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * File upload response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedFileUploadResponseCompanion *shared __attribute__((swift_name("shared")));

/**
 * File upload response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Supported liveness modes
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LivenessModes")))
@interface TruoraSharedLivenessModes : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Supported liveness modes
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)livenessModes __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedLivenessModes *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *DISABLED __attribute__((swift_name("DISABLED")));
@property (readonly) NSString *PASSIVE __attribute__((swift_name("PASSIVE")));
@end


/**
 * Metadata builder utility
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataBuilder")))
@interface TruoraSharedMetadataBuilder : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Metadata builder utility
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)metadataBuilder __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedMetadataBuilder *shared __attribute__((swift_name("shared")));
- (NSDictionary<NSString *, TruoraSharedKotlinx_serialization_jsonJsonElement *> *)buildPairs:(TruoraSharedKotlinArray<TruoraSharedKotlinPair<NSString *, id> *> *)pairs __attribute__((swift_name("build(pairs:)")));
@end


/**
 * SDK Event model representing a single event
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SDKEvent")))
@interface TruoraSharedSDKEvent : TruoraSharedBase
- (instancetype)initWithEvent_type:(TruoraSharedEventType *)event_type event_name:(NSString *)event_name level:(TruoraSharedEventLevel * _Nullable)level success:(BOOL)success error_message:(NSString * _Nullable)error_message duration_ms:(TruoraSharedLong * _Nullable)duration_ms metadata:(NSDictionary<NSString *, TruoraSharedKotlinx_serialization_jsonJsonElement *> * _Nullable)metadata stack_trace:(NSString * _Nullable)stack_trace __attribute__((swift_name("init(event_type:event_name:level:success:error_message:duration_ms:metadata:stack_trace:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSDKEventCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSDKEvent *)doCopyEvent_type:(TruoraSharedEventType *)event_type event_name:(NSString *)event_name level:(TruoraSharedEventLevel * _Nullable)level success:(BOOL)success error_message:(NSString * _Nullable)error_message duration_ms:(TruoraSharedLong * _Nullable)duration_ms metadata:(NSDictionary<NSString *, TruoraSharedKotlinx_serialization_jsonJsonElement *> * _Nullable)metadata stack_trace:(NSString * _Nullable)stack_trace __attribute__((swift_name("doCopy(event_type:event_name:level:success:error_message:duration_ms:metadata:stack_trace:)")));
- (TruoraSharedEventLevel *)effectiveLevel __attribute__((swift_name("effectiveLevel()")));

/**
 * SDK Event model representing a single event
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * SDK Event model representing a single event
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * SDK Event model representing a single event
 */
- (NSString *)description __attribute__((swift_name("description()")));
- (void)validate __attribute__((swift_name("validate()")));
@property (readonly) TruoraSharedLong * _Nullable duration_ms __attribute__((swift_name("duration_ms")));
@property (readonly) NSString * _Nullable error_message __attribute__((swift_name("error_message")));
@property (readonly) NSString *event_name __attribute__((swift_name("event_name")));
@property (readonly) TruoraSharedEventType *event_type __attribute__((swift_name("event_type")));
@property (readonly) TruoraSharedEventLevel * _Nullable level __attribute__((swift_name("level")));
@property (readonly) NSDictionary<NSString *, TruoraSharedKotlinx_serialization_jsonJsonElement *> * _Nullable metadata __attribute__((swift_name("metadata")));
@property (readonly) NSString * _Nullable stack_trace __attribute__((swift_name("stack_trace")));
@property (readonly) BOOL success __attribute__((swift_name("success")));
@end


/**
 * SDK Event model representing a single event
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SDKEvent.Companion")))
@interface TruoraSharedSDKEventCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * SDK Event model representing a single event
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSDKEventCompanion *shared __attribute__((swift_name("shared")));

/**
 * SDK Event model representing a single event
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * SDK Log request model for batch event logging
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SDKLog")))
@interface TruoraSharedSDKLog : TruoraSharedBase
- (instancetype)initWithSdk_version:(NSString *)sdk_version platform:(NSString *)platform timestamp:(int64_t)timestamp device_model:(NSString * _Nullable)device_model os_version:(NSString * _Nullable)os_version process_id:(NSString * _Nullable)process_id flow_id:(NSString * _Nullable)flow_id validation_id:(NSString * _Nullable)validation_id account_id:(NSString * _Nullable)account_id client_id:(NSString * _Nullable)client_id events:(NSArray<TruoraSharedSDKEvent *> *)events __attribute__((swift_name("init(sdk_version:platform:timestamp:device_model:os_version:process_id:flow_id:validation_id:account_id:client_id:events:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSDKLogCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSDKLog *)doCopySdk_version:(NSString *)sdk_version platform:(NSString *)platform timestamp:(int64_t)timestamp device_model:(NSString * _Nullable)device_model os_version:(NSString * _Nullable)os_version process_id:(NSString * _Nullable)process_id flow_id:(NSString * _Nullable)flow_id validation_id:(NSString * _Nullable)validation_id account_id:(NSString * _Nullable)account_id client_id:(NSString * _Nullable)client_id events:(NSArray<TruoraSharedSDKEvent *> *)events __attribute__((swift_name("doCopy(sdk_version:platform:timestamp:device_model:os_version:process_id:flow_id:validation_id:account_id:client_id:events:)")));

/**
 * SDK Log request model for batch event logging
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * SDK Log request model for batch event logging
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (TruoraSharedSDKLog *)normalized __attribute__((swift_name("normalized()")));

/**
 * SDK Log request model for batch event logging
 */
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * Validate SDK log request
 * @throws SdkLogValidationException with specific error code
 */
- (void)validate __attribute__((swift_name("validate()")));
@property (readonly) NSString * _Nullable account_id __attribute__((swift_name("account_id")));
@property (readonly) NSString * _Nullable client_id __attribute__((swift_name("client_id")));
@property (readonly) NSString * _Nullable device_model __attribute__((swift_name("device_model")));
@property (readonly) NSArray<TruoraSharedSDKEvent *> *events __attribute__((swift_name("events")));
@property (readonly) NSString * _Nullable flow_id __attribute__((swift_name("flow_id")));
@property (readonly) NSString * _Nullable os_version __attribute__((swift_name("os_version")));
@property (readonly) NSString *platform __attribute__((swift_name("platform")));
@property (readonly) NSString * _Nullable process_id __attribute__((swift_name("process_id")));
@property (readonly) NSString *sdk_version __attribute__((swift_name("sdk_version")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) NSString * _Nullable validation_id __attribute__((swift_name("validation_id")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SDKLog.Companion")))
@interface TruoraSharedSDKLogCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSDKLogCompanion *shared __attribute__((swift_name("shared")));
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@property (readonly) int32_t MAX_EVENTS_PER_REQUEST __attribute__((swift_name("MAX_EVENTS_PER_REQUEST")));
@property (readonly) NSSet<NSString *> *VALID_PLATFORMS __attribute__((swift_name("VALID_PLATFORMS")));
@end


/**
 * SDK Log response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SDKLogResponse")))
@interface TruoraSharedSDKLogResponse : TruoraSharedBase
- (instancetype)initWithMessage:(NSString *)message events_logged:(int32_t)events_logged sdk_version:(NSString *)sdk_version platform:(NSString *)platform __attribute__((swift_name("init(message:events_logged:sdk_version:platform:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSDKLogResponseCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSDKLogResponse *)doCopyMessage:(NSString *)message events_logged:(int32_t)events_logged sdk_version:(NSString *)sdk_version platform:(NSString *)platform __attribute__((swift_name("doCopy(message:events_logged:sdk_version:platform:)")));

/**
 * SDK Log response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * SDK Log response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * SDK Log response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t events_logged __attribute__((swift_name("events_logged")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSString *platform __attribute__((swift_name("platform")));
@property (readonly) NSString *sdk_version __attribute__((swift_name("sdk_version")));
@end


/**
 * SDK Log response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SDKLogResponse.Companion")))
@interface TruoraSharedSDKLogResponseCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * SDK Log response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSDKLogResponseCompanion *shared __attribute__((swift_name("shared")));

/**
 * SDK Log response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Validation error codes
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogValidationCode")))
@interface TruoraSharedSdkLogValidationCode : TruoraSharedKotlinEnum<TruoraSharedSdkLogValidationCode *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Validation error codes
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSdkLogValidationCode *emptySdkVersion __attribute__((swift_name("emptySdkVersion")));
@property (class, readonly) TruoraSharedSdkLogValidationCode *emptyPlatform __attribute__((swift_name("emptyPlatform")));
@property (class, readonly) TruoraSharedSdkLogValidationCode *invalidPlatform __attribute__((swift_name("invalidPlatform")));
@property (class, readonly) TruoraSharedSdkLogValidationCode *emptyEvents __attribute__((swift_name("emptyEvents")));
@property (class, readonly) TruoraSharedSdkLogValidationCode *tooManyEvents __attribute__((swift_name("tooManyEvents")));
@property (class, readonly) TruoraSharedSdkLogValidationCode *invalidEventName __attribute__((swift_name("invalidEventName")));
@property (class, readonly) TruoraSharedSdkLogValidationCode *invalidDuration __attribute__((swift_name("invalidDuration")));
+ (TruoraSharedKotlinArray<TruoraSharedSdkLogValidationCode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSdkLogValidationCode *> *entries __attribute__((swift_name("entries")));
@end


/**
 * Exception for SDK log validation errors
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogValidationException")))
@interface TruoraSharedSdkLogValidationException : TruoraSharedKotlinException
- (instancetype)initWithCode:(TruoraSharedSdkLogValidationCode *)code __attribute__((swift_name("init(code:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSdkLogValidationExceptionCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) TruoraSharedSdkLogValidationCode *code __attribute__((swift_name("code")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogValidationException.Companion")))
@interface TruoraSharedSdkLogValidationExceptionCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSdkLogValidationExceptionCompanion *shared __attribute__((swift_name("shared")));
@end


/**
 * Sub validation result response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubValidationResult")))
@interface TruoraSharedSubValidationResult : TruoraSharedBase
- (instancetype)initWithValidation_name:(NSString *)validation_name result:(NSString *)result validation_type:(NSString *)validation_type message:(NSString *)message manually_reviewed:(BOOL)manually_reviewed created_at:(NSString *)created_at data_validations:(NSDictionary<NSString *, NSString *> * _Nullable)data_validations __attribute__((swift_name("init(validation_name:result:validation_type:message:manually_reviewed:created_at:data_validations:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSubValidationResultCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSubValidationResult *)doCopyValidation_name:(NSString *)validation_name result:(NSString *)result validation_type:(NSString *)validation_type message:(NSString *)message manually_reviewed:(BOOL)manually_reviewed created_at:(NSString *)created_at data_validations:(NSDictionary<NSString *, NSString *> * _Nullable)data_validations __attribute__((swift_name("doCopy(validation_name:result:validation_type:message:manually_reviewed:created_at:data_validations:)")));

/**
 * Sub validation result response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Sub validation result response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Sub validation result response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *created_at __attribute__((swift_name("created_at")));
@property (readonly) NSDictionary<NSString *, NSString *> * _Nullable data_validations __attribute__((swift_name("data_validations")));
@property (readonly) BOOL manually_reviewed __attribute__((swift_name("manually_reviewed")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSString *result __attribute__((swift_name("result")));
@property (readonly) NSString *validation_name __attribute__((swift_name("validation_name")));
@property (readonly) NSString *validation_type __attribute__((swift_name("validation_type")));
@end


/**
 * Sub validation result response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubValidationResult.Companion")))
@interface TruoraSharedSubValidationResultCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Sub validation result response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSubValidationResultCompanion *shared __attribute__((swift_name("shared")));

/**
 * Sub validation result response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Supported subvalidation types
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubValidationTypes")))
@interface TruoraSharedSubValidationTypes : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Supported subvalidation types
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)subValidationTypes __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSubValidationTypes *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *PASSIVE_LIVENESS __attribute__((swift_name("PASSIVE_LIVENESS")));
@property (readonly) NSString *SIMILARITY __attribute__((swift_name("SIMILARITY")));
@property (readonly) NSString *SPEECH_MATCH __attribute__((swift_name("SPEECH_MATCH")));
@end


/**
 * User response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserResponse")))
@interface TruoraSharedUserResponse : TruoraSharedBase
- (instancetype)initWithInput_files:(NSArray<NSString *> * _Nullable)input_files __attribute__((swift_name("init(input_files:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedUserResponseCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedUserResponse *)doCopyInput_files:(NSArray<NSString *> * _Nullable)input_files __attribute__((swift_name("doCopy(input_files:)")));

/**
 * User response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * User response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * User response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<NSString *> * _Nullable input_files __attribute__((swift_name("input_files")));
@end


/**
 * User response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserResponse.Companion")))
@interface TruoraSharedUserResponseCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * User response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedUserResponseCompanion *shared __attribute__((swift_name("shared")));

/**
 * User response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Create validation response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationCreateResponse")))
@interface TruoraSharedValidationCreateResponse : TruoraSharedBase
- (instancetype)initWithValidation_id:(NSString *)validation_id ip_address:(NSString *)ip_address account_id:(NSString *)account_id type:(NSString *)type validation_status:(NSString *)validation_status lifecycle_status:(NSString *)lifecycle_status threshold:(TruoraSharedDouble * _Nullable)threshold creation_date:(NSString *)creation_date details:(TruoraSharedValidationDetails * _Nullable)details instructions:(TruoraSharedValidationInstructions * _Nullable)instructions __attribute__((swift_name("init(validation_id:ip_address:account_id:type:validation_status:lifecycle_status:threshold:creation_date:details:instructions:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedValidationCreateResponseCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedValidationCreateResponse *)doCopyValidation_id:(NSString *)validation_id ip_address:(NSString *)ip_address account_id:(NSString *)account_id type:(NSString *)type validation_status:(NSString *)validation_status lifecycle_status:(NSString *)lifecycle_status threshold:(TruoraSharedDouble * _Nullable)threshold creation_date:(NSString *)creation_date details:(TruoraSharedValidationDetails * _Nullable)details instructions:(TruoraSharedValidationInstructions * _Nullable)instructions __attribute__((swift_name("doCopy(validation_id:ip_address:account_id:type:validation_status:lifecycle_status:threshold:creation_date:details:instructions:)")));

/**
 * Create validation response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Create validation response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Create validation response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *account_id __attribute__((swift_name("account_id")));
@property (readonly) NSString *creation_date __attribute__((swift_name("creation_date")));
@property (readonly) TruoraSharedValidationDetails * _Nullable details __attribute__((swift_name("details")));
@property (readonly) TruoraSharedValidationInstructions * _Nullable instructions __attribute__((swift_name("instructions")));
@property (readonly) NSString *ip_address __attribute__((swift_name("ip_address")));
@property (readonly) NSString *lifecycle_status __attribute__((swift_name("lifecycle_status")));
@property (readonly) TruoraSharedDouble * _Nullable threshold __attribute__((swift_name("threshold")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@property (readonly) NSString *validation_id __attribute__((swift_name("validation_id")));
@property (readonly) NSString *validation_status __attribute__((swift_name("validation_status")));
@end


/**
 * Create validation response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationCreateResponse.Companion")))
@interface TruoraSharedValidationCreateResponseCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Create validation response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedValidationCreateResponseCompanion *shared __attribute__((swift_name("shared")));

/**
 * Create validation response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Get validation response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationDetailResponse")))
@interface TruoraSharedValidationDetailResponse : TruoraSharedBase
- (instancetype)initWithType:(NSString *)type validation_status:(NSString *)validation_status expected_expiration_date:(NSString * _Nullable)expected_expiration_date creation_date:(NSString *)creation_date processing_start_date:(NSString * _Nullable)processing_start_date processing_finish_date:(NSString * _Nullable)processing_finish_date failure_status:(TruoraSharedFailureStatus * _Nullable)failure_status details:(TruoraSharedValidationDetails * _Nullable)details validation_inputs:(TruoraSharedValidationInputs * _Nullable)validation_inputs user_response:(TruoraSharedUserResponse * _Nullable)user_response validation_id:(NSString *)validation_id ip_address:(NSString *)ip_address account_id:(NSString *)account_id threshold:(TruoraSharedDouble * _Nullable)threshold __attribute__((swift_name("init(type:validation_status:expected_expiration_date:creation_date:processing_start_date:processing_finish_date:failure_status:details:validation_inputs:user_response:validation_id:ip_address:account_id:threshold:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedValidationDetailResponseCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedValidationDetailResponse *)doCopyType:(NSString *)type validation_status:(NSString *)validation_status expected_expiration_date:(NSString * _Nullable)expected_expiration_date creation_date:(NSString *)creation_date processing_start_date:(NSString * _Nullable)processing_start_date processing_finish_date:(NSString * _Nullable)processing_finish_date failure_status:(TruoraSharedFailureStatus * _Nullable)failure_status details:(TruoraSharedValidationDetails * _Nullable)details validation_inputs:(TruoraSharedValidationInputs * _Nullable)validation_inputs user_response:(TruoraSharedUserResponse * _Nullable)user_response validation_id:(NSString *)validation_id ip_address:(NSString *)ip_address account_id:(NSString *)account_id threshold:(TruoraSharedDouble * _Nullable)threshold __attribute__((swift_name("doCopy(type:validation_status:expected_expiration_date:creation_date:processing_start_date:processing_finish_date:failure_status:details:validation_inputs:user_response:validation_id:ip_address:account_id:threshold:)")));

/**
 * Get validation response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Get validation response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Get validation response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *account_id __attribute__((swift_name("account_id")));
@property (readonly) NSString *creation_date __attribute__((swift_name("creation_date")));
@property (readonly) TruoraSharedValidationDetails * _Nullable details __attribute__((swift_name("details")));
@property (readonly) NSString * _Nullable expected_expiration_date __attribute__((swift_name("expected_expiration_date")));
@property (readonly) TruoraSharedFailureStatus * _Nullable failure_status __attribute__((swift_name("failure_status")));
@property (readonly) NSString *ip_address __attribute__((swift_name("ip_address")));
@property (readonly) NSString * _Nullable processing_finish_date __attribute__((swift_name("processing_finish_date")));
@property (readonly) NSString * _Nullable processing_start_date __attribute__((swift_name("processing_start_date")));
@property (readonly) TruoraSharedDouble * _Nullable threshold __attribute__((swift_name("threshold")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@property (readonly) TruoraSharedUserResponse * _Nullable user_response __attribute__((swift_name("user_response")));
@property (readonly) NSString *validation_id __attribute__((swift_name("validation_id")));
@property (readonly) TruoraSharedValidationInputs * _Nullable validation_inputs __attribute__((swift_name("validation_inputs")));
@property (readonly) NSString *validation_status __attribute__((swift_name("validation_status")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationDetailResponse.Companion")))
@interface TruoraSharedValidationDetailResponseCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedValidationDetailResponseCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedValidationDetailResponse *)fromCreateResponseResponse:(TruoraSharedValidationCreateResponse *)response __attribute__((swift_name("fromCreateResponse(response:)")));
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Validation details response model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationDetails")))
@interface TruoraSharedValidationDetails : TruoraSharedBase
- (instancetype)initWithFace_recognition_validations:(TruoraSharedFaceRecognitionDetails * _Nullable)face_recognition_validations background_check:(TruoraSharedBackgroundCheck * _Nullable)background_check document_details:(TruoraSharedDocumentDetails * _Nullable)document_details document_validations:(TruoraSharedDocumentSubValidations * _Nullable)document_validations __attribute__((swift_name("init(face_recognition_validations:background_check:document_details:document_validations:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedValidationDetailsCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedValidationDetails *)doCopyFace_recognition_validations:(TruoraSharedFaceRecognitionDetails * _Nullable)face_recognition_validations background_check:(TruoraSharedBackgroundCheck * _Nullable)background_check document_details:(TruoraSharedDocumentDetails * _Nullable)document_details document_validations:(TruoraSharedDocumentSubValidations * _Nullable)document_validations __attribute__((swift_name("doCopy(face_recognition_validations:background_check:document_details:document_validations:)")));

/**
 * Validation details response model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Validation details response model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Validation details response model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedBackgroundCheck * _Nullable background_check __attribute__((swift_name("background_check")));
@property (readonly) TruoraSharedDocumentDetails * _Nullable document_details __attribute__((swift_name("document_details")));
@property (readonly) TruoraSharedDocumentSubValidations * _Nullable document_validations __attribute__((swift_name("document_validations")));
@property (readonly) TruoraSharedFaceRecognitionDetails * _Nullable face_recognition_validations __attribute__((swift_name("face_recognition_validations")));
@end


/**
 * Validation details response model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationDetails.Companion")))
@interface TruoraSharedValidationDetailsCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Validation details response model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedValidationDetailsCompanion *shared __attribute__((swift_name("shared")));

/**
 * Validation details response model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Validation Inputs model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationInputs")))
@interface TruoraSharedValidationInputs : TruoraSharedBase
- (instancetype)initWithValidation_input_files:(NSArray<NSString *> * _Nullable)validation_input_files __attribute__((swift_name("init(validation_input_files:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedValidationInputsCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedValidationInputs *)doCopyValidation_input_files:(NSArray<NSString *> * _Nullable)validation_input_files __attribute__((swift_name("doCopy(validation_input_files:)")));

/**
 * Validation Inputs model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Validation Inputs model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Validation Inputs model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<NSString *> * _Nullable validation_input_files __attribute__((swift_name("validation_input_files")));
@end


/**
 * Validation Inputs model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationInputs.Companion")))
@interface TruoraSharedValidationInputsCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Validation Inputs model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedValidationInputsCompanion *shared __attribute__((swift_name("shared")));

/**
 * Validation Inputs model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Validation instructions model
 * - Face recognition use file_upload_link
 * - Document validation use front_url and reverse_url
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationInstructions")))
@interface TruoraSharedValidationInstructions : TruoraSharedBase
- (instancetype)initWithFile_upload_link:(NSString * _Nullable)file_upload_link front_url:(NSString * _Nullable)front_url reverse_url:(NSString * _Nullable)reverse_url __attribute__((swift_name("init(file_upload_link:front_url:reverse_url:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedValidationInstructionsCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedValidationInstructions *)doCopyFile_upload_link:(NSString * _Nullable)file_upload_link front_url:(NSString * _Nullable)front_url reverse_url:(NSString * _Nullable)reverse_url __attribute__((swift_name("doCopy(file_upload_link:front_url:reverse_url:)")));

/**
 * Validation instructions model
 * - Face recognition use file_upload_link
 * - Document validation use front_url and reverse_url
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Validation instructions model
 * - Face recognition use file_upload_link
 * - Document validation use front_url and reverse_url
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Validation instructions model
 * - Face recognition use file_upload_link
 * - Document validation use front_url and reverse_url
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable file_upload_link __attribute__((swift_name("file_upload_link")));
@property (readonly) NSString * _Nullable front_url __attribute__((swift_name("front_url")));
@property (readonly) NSString * _Nullable reverse_url __attribute__((swift_name("reverse_url")));
@end


/**
 * Validation instructions model
 * - Face recognition use file_upload_link
 * - Document validation use front_url and reverse_url
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationInstructions.Companion")))
@interface TruoraSharedValidationInstructionsCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Validation instructions model
 * - Face recognition use file_upload_link
 * - Document validation use front_url and reverse_url
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedValidationInstructionsCompanion *shared __attribute__((swift_name("shared")));

/**
 * Validation instructions model
 * - Face recognition use file_upload_link
 * - Document validation use front_url and reverse_url
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Validation request model
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationRequest")))
@interface TruoraSharedValidationRequest : TruoraSharedBase
- (instancetype)initWithType:(NSString *)type country:(NSString * _Nullable)country account_id:(NSString * _Nullable)account_id threshold:(TruoraSharedDouble * _Nullable)threshold subvalidations:(NSArray<NSString *> * _Nullable)subvalidations retry_of_id:(NSString * _Nullable)retry_of_id allowed_retries:(TruoraSharedInt * _Nullable)allowed_retries document_type:(NSString * _Nullable)document_type __attribute__((swift_name("init(type:country:account_id:threshold:subvalidations:retry_of_id:allowed_retries:document_type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedValidationRequestCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedValidationRequest *)doCopyType:(NSString *)type country:(NSString * _Nullable)country account_id:(NSString * _Nullable)account_id threshold:(TruoraSharedDouble * _Nullable)threshold subvalidations:(NSArray<NSString *> * _Nullable)subvalidations retry_of_id:(NSString * _Nullable)retry_of_id allowed_retries:(TruoraSharedInt * _Nullable)allowed_retries document_type:(NSString * _Nullable)document_type __attribute__((swift_name("doCopy(type:country:account_id:threshold:subvalidations:retry_of_id:allowed_retries:document_type:)")));

/**
 * Validation request model
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Validation request model
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSDictionary<NSString *, NSString *> *)toFormData __attribute__((swift_name("toFormData()")));

/**
 * Validation request model
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable account_id __attribute__((swift_name("account_id")));
@property (readonly) TruoraSharedInt * _Nullable allowed_retries __attribute__((swift_name("allowed_retries")));
@property (readonly) NSString * _Nullable country __attribute__((swift_name("country")));
@property (readonly) NSString * _Nullable document_type __attribute__((swift_name("document_type")));
@property (readonly) NSString * _Nullable retry_of_id __attribute__((swift_name("retry_of_id")));
@property (readonly) NSArray<NSString *> * _Nullable subvalidations __attribute__((swift_name("subvalidations")));
@property (readonly) TruoraSharedDouble * _Nullable threshold __attribute__((swift_name("threshold")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@end


/**
 * Validation request model
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationRequest.Companion")))
@interface TruoraSharedValidationRequestCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Validation request model
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedValidationRequestCompanion *shared __attribute__((swift_name("shared")));

/**
 * Validation request model
 */
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Validation status enum
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationStatus")))
@interface TruoraSharedValidationStatus : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Validation status enum
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)validationStatus __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedValidationStatus *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *FAILURE __attribute__((swift_name("FAILURE")));
@property (readonly) NSString *PENDING __attribute__((swift_name("PENDING")));
@property (readonly) NSString *SUCCESS __attribute__((swift_name("SUCCESS")));
@end


/**
 * Supported validation types
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationTypes")))
@interface TruoraSharedValidationTypes : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Supported validation types
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)validationTypes __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedValidationTypes *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *DOCUMENT_VALIDATION __attribute__((swift_name("DOCUMENT_VALIDATION")));
@property (readonly) NSString *FACE_RECOGNITION __attribute__((swift_name("FACE_RECOGNITION")));
@end


/**
 * Shared HTTP client for Truora SDKs
 * Supports GET and POST requests with x-www-form-urlencoded
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraHttpClient")))
@interface TruoraSharedTruoraHttpClient : TruoraSharedBase
- (instancetype)initWithBaseUrl:(NSString *)baseUrl apiKey:(NSString * _Nullable)apiKey httpClient:(TruoraSharedKtor_client_coreHttpClient *)httpClient __attribute__((swift_name("init(baseUrl:apiKey:httpClient:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedTruoraHttpClientCompanion *companion __attribute__((swift_name("companion")));

/**
 * Close the HTTP client
 */
- (void)close __attribute__((swift_name("close()")));

/**
 * Do GET request to get a specific validation
 * @param endpoint
 * @return a new HttpResponse
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getEndpoint:(NSString *)endpoint completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("get(endpoint:completionHandler:)")));

/**
 * Do POST request to create validation
 * @param formData
 * @return a new HttpResponse
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)postFormFormData:(NSDictionary<NSString *, NSString *> *)formData completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("postForm(formData:completionHandler:)")));

/**
 * Do PUT request to upload file to presigned URL
 * @param url - Presigned URL
 * @param fileData - ByteArray of the file
 * @param contentType - MIME type of the file (e.g., "video/mp4")
 * @return a new HttpResponse
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)putFileUrl:(NSString *)url fileData:(TruoraSharedKotlinByteArray *)fileData contentType:(NSString *)contentType completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("putFile(url:fileData:contentType:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraHttpClient.Companion")))
@interface TruoraSharedTruoraHttpClientCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedTruoraHttpClientCompanion *shared __attribute__((swift_name("shared")));
@end


/**
 * iOS implementation of PlatformFileHandle.
 * Supports both local files (file://) and remote URLs (http://, https://).
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformFileHandle")))
@interface TruoraSharedPlatformFileHandle : TruoraSharedBase
- (instancetype)initWithNsUrl:(NSURL *)nsUrl httpClient:(TruoraSharedKtor_client_coreHttpClient * _Nullable)httpClient __attribute__((swift_name("init(nsUrl:httpClient:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSizeWithCompletionHandler:(void (^)(TruoraSharedLong * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getSize(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAllBytesWithCompletionHandler:(void (^)(TruoraSharedKotlinByteArray * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAllBytes(completionHandler:)")));
@property (readonly) TruoraSharedKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) NSString * _Nullable fileName __attribute__((swift_name("fileName")));
@end


/**
 * HTTP client for SDK log API
 * Handles batch event logging to /v1/sdk/log endpoint
 *
 * Memory Management:
 * - If httpClient is provided via constructor, it is assumed to be externally managed
 *   and close() will NOT close it
 * - If httpClient is not provided, a new one is created and close() will close it
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogClient")))
@interface TruoraSharedSdkLogClient : TruoraSharedBase
- (instancetype)initWithBaseUrl:(NSString *)baseUrl apiKey:(NSString *)apiKey sdkVersion:(NSString *)sdkVersion httpClient:(TruoraSharedKtor_client_coreHttpClient * _Nullable)httpClient __attribute__((swift_name("init(baseUrl:apiKey:sdkVersion:httpClient:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSdkLogClientCompanion *companion __attribute__((swift_name("companion")));

/**
 * Close the HTTP client and release resources
 *
 * Only closes internally created HttpClient.
 * If HttpClient was provided externally, it's the caller's responsibility to close it.
 */
- (void)close __attribute__((swift_name("close()")));

/**
 * Send SDK log batch to the server
 * @param sdkLog The SDK log batch containing events to log
 * @return SDKLogResponse with confirmation details
 * @throws SdkLogException if validation or request fails
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)logSdkLog:(TruoraSharedSDKLog *)sdkLog completionHandler:(void (^)(TruoraSharedSDKLogResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("log(sdkLog:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogClient.Companion")))
@interface TruoraSharedSdkLogClientCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSdkLogClientCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedKtor_client_coreHttpClient *)createDefaultHttpClient __attribute__((swift_name("createDefaultHttpClient()")));
@end


/**
 * Enum defining SDK log error types
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogErrorType")))
@interface TruoraSharedSdkLogErrorType : TruoraSharedKotlinEnum<TruoraSharedSdkLogErrorType *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Enum defining SDK log error types
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSdkLogErrorTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) TruoraSharedSdkLogErrorType *emptySdkVersion __attribute__((swift_name("emptySdkVersion")));
@property (class, readonly) TruoraSharedSdkLogErrorType *emptyPlatform __attribute__((swift_name("emptyPlatform")));
@property (class, readonly) TruoraSharedSdkLogErrorType *invalidPlatform __attribute__((swift_name("invalidPlatform")));
@property (class, readonly) TruoraSharedSdkLogErrorType *emptyEvents __attribute__((swift_name("emptyEvents")));
@property (class, readonly) TruoraSharedSdkLogErrorType *tooManyEvents __attribute__((swift_name("tooManyEvents")));
@property (class, readonly) TruoraSharedSdkLogErrorType *invalidEventName __attribute__((swift_name("invalidEventName")));
@property (class, readonly) TruoraSharedSdkLogErrorType *invalidDuration __attribute__((swift_name("invalidDuration")));
@property (class, readonly) TruoraSharedSdkLogErrorType *networkError __attribute__((swift_name("networkError")));
@property (class, readonly) TruoraSharedSdkLogErrorType *requestFailed __attribute__((swift_name("requestFailed")));
@property (class, readonly) TruoraSharedSdkLogErrorType *timeout __attribute__((swift_name("timeout")));
@property (class, readonly) TruoraSharedSdkLogErrorType *invalidResponse __attribute__((swift_name("invalidResponse")));
@property (class, readonly) TruoraSharedSdkLogErrorType *unauthorized __attribute__((swift_name("unauthorized")));
@property (class, readonly) TruoraSharedSdkLogErrorType *serverError __attribute__((swift_name("serverError")));
+ (TruoraSharedKotlinArray<TruoraSharedSdkLogErrorType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSdkLogErrorType *> *entries __attribute__((swift_name("entries")));

/**
 * Map validation error codes to error types
 */
- (TruoraSharedSdkLogException *)toExceptionDetails:(NSDictionary<NSString *, id> * _Nullable)details cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("toException(details:cause:)")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogErrorType.Companion")))
@interface TruoraSharedSdkLogErrorTypeCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSdkLogErrorTypeCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSdkLogErrorType *)fromValidationCodeCode:(TruoraSharedSdkLogValidationCode *)code __attribute__((swift_name("fromValidationCode(code:)")));
@end


/**
 * Exception class for SDK log errors
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogException")))
@interface TruoraSharedSdkLogException : TruoraSharedKotlinException
- (instancetype)initWithErrorType:(TruoraSharedSdkLogErrorType *)errorType details:(NSDictionary<NSString *, id> * _Nullable)details cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(errorType:details:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSdkLogExceptionCompanion *companion __attribute__((swift_name("companion")));

/**
 * Check if error should be retried
 */
- (BOOL)isRetryable __attribute__((swift_name("isRetryable()")));
@property (readonly) NSDictionary<NSString *, id> * _Nullable details __attribute__((swift_name("details")));
@property (readonly) TruoraSharedSdkLogErrorType *errorType __attribute__((swift_name("errorType")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogException.Companion")))
@interface TruoraSharedSdkLogExceptionCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSdkLogExceptionCompanion *shared __attribute__((swift_name("shared")));

/**
 * Creates exception from HTTP response
 */
- (TruoraSharedSdkLogException *)fromHttpStatusStatusCode:(int32_t)statusCode responseBody:(NSString * _Nullable)responseBody cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("fromHttpStatus(statusCode:responseBody:cause:)")));
@end


/**
 * Global singleton for convenient access to the SDK logging system
 *
 * Must be initialized once at the start of the app with initialize()
 * before using any logging methods.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogManager")))
@interface TruoraSharedSdkLogManager : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Global singleton for convenient access to the SDK logging system
 *
 * Must be initialized once at the start of the app with initialize()
 * before using any logging methods.
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sdkLogManager __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSdkLogManager *shared __attribute__((swift_name("shared")));

/**
 * Close the logger and release resources
 * Flushes any remaining buffered events before closing
 *
 * This is a suspend function that properly waits for buffer flush and cleanup
 * Prefer this method over closeNow() for graceful shutdown
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)closeWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("close(completionHandler:)")));

/**
 * Synchronous close without waiting for buffer flush
 *
 * WARNING: This does NOT wait for buffered events to be flushed to the server.
 * Events in the buffer may be lost. Use close() (suspend) for graceful shutdown.
 *
 * Use closeNow() only when:
 * - You cannot await a suspend function (e.g., on app termination)
 * - You are willing to accept potential data loss
 * - You need synchronous cleanup
 */
- (void)closeNow __attribute__((swift_name("closeNow()")));

/**
 * Flush the buffered events
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)flushWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("flush(completionHandler:)")));

/**
 * Initialize the global logger
 * Must be called once at the start of the app
 *
 * Thread-safe initialization using synchronized block to prevent multiple logger instances
 *
 * @throws IllegalStateException if already initialized
 */
- (void)initializeApiKey:(NSString *)apiKey sdkVersion:(NSString *)sdkVersion platform:(NSString *)platform baseUrl:(NSString *)baseUrl deviceModel:(NSString * _Nullable)deviceModel osVersion:(NSString * _Nullable)osVersion maxBufferSize:(int32_t)maxBufferSize flushIntervalMs:(int64_t)flushIntervalMs __attribute__((swift_name("initialize(apiKey:sdkVersion:platform:baseUrl:deviceModel:osVersion:maxBufferSize:flushIntervalMs:)")));

/**
 * Check if the logger is initialized
 * @return true if the logger is initialized, false otherwise
 */
- (BOOL)isInitialized __attribute__((swift_name("isInitialized()")));

/**
 * Log a camera event
 * @param eventName the event name
 * @param success the success flag
 * @param errorMessage the error message
 * @param level the event level
 * @param durationMs the duration in milliseconds
 * @param metadata the metadata
 */
- (void)logCameraEventName:(NSString *)eventName success:(BOOL)success errorMessage:(NSString * _Nullable)errorMessage level:(TruoraSharedEventLevel * _Nullable)level durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logCamera(eventName:success:errorMessage:level:durationMs:metadata:)")));

/**
 * Log a camera error
 * @param eventName the event name
 * @param exception the exception
 * @param level the event level
 * @param durationMs the duration in milliseconds
 * @param metadata the metadata
 */
- (void)logCameraErrorEventName:(NSString *)eventName exception:(TruoraSharedKotlinThrowable *)exception level:(TruoraSharedEventLevel *)level durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logCameraError(eventName:exception:level:durationMs:metadata:)")));

/**
 * Log a device event
 * @param eventName the event name
 * @param success the success flag
 * @param level the event level
 * @param metadata the metadata
 */
- (void)logDeviceEventName:(NSString *)eventName success:(BOOL)success level:(TruoraSharedEventLevel * _Nullable)level metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logDevice(eventName:success:level:metadata:)")));

/**
 * Log an event
 * @param eventType the event type
 * @param eventName the event name
 * @param success the success flag
 * @param level the event level
 * @param errorMessage the error message
 * @param durationMs the duration in milliseconds
 * @param metadata the metadata
 * @param stackTrace the stack trace
 */
- (void)logEventEventType:(TruoraSharedEventType *)eventType eventName:(NSString *)eventName success:(BOOL)success level:(TruoraSharedEventLevel * _Nullable)level errorMessage:(NSString * _Nullable)errorMessage durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, TruoraSharedKotlinx_serialization_jsonJsonElement *> * _Nullable)metadata stackTrace:(NSString * _Nullable)stackTrace __attribute__((swift_name("logEvent(eventType:eventName:success:level:errorMessage:durationMs:metadata:stackTrace:)")));

/**
 * Log an exception
 * @param eventType the event type
 * @param eventName the event name
 * @param exception the exception
 * @param level the event level
 * @param durationMs the duration in milliseconds
 * @param metadata the metadata
 */
- (void)logExceptionEventType:(TruoraSharedEventType *)eventType eventName:(NSString *)eventName exception:(TruoraSharedKotlinThrowable *)exception level:(TruoraSharedEventLevel *)level durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, TruoraSharedKotlinx_serialization_jsonJsonElement *> * _Nullable)metadata __attribute__((swift_name("logException(eventType:eventName:exception:level:durationMs:metadata:)")));

/**
 * Log a ML event
 * @param eventName the event name
 * @param success the success flag
 * @param level the event level
 * @param errorMessage the error message
 * @param durationMs the duration in milliseconds
 * @param metadata the metadata
 */
- (void)logMLEventName:(NSString *)eventName success:(BOOL)success level:(TruoraSharedEventLevel * _Nullable)level errorMessage:(NSString * _Nullable)errorMessage durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logML(eventName:success:level:errorMessage:durationMs:metadata:)")));

/**
 * Log a ML error
 * @param eventName the event name
 * @param exception the exception
 * @param level the event level
 * @param durationMs the duration in milliseconds
 * @param metadata the metadata
 */
- (void)logMLErrorEventName:(NSString *)eventName exception:(TruoraSharedKotlinThrowable *)exception level:(TruoraSharedEventLevel *)level durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logMLError(eventName:exception:level:durationMs:metadata:)")));

/**
 * Log a view event
 * @param viewName the view name
 * @param success the success flag
 * @param level the event level
 * @param durationMs the duration in milliseconds
 * @param metadata the metadata
 */
- (void)logViewViewName:(NSString *)viewName success:(BOOL)success level:(TruoraSharedEventLevel * _Nullable)level durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logView(viewName:success:level:durationMs:metadata:)")));

/**
 * Reset the logger and release resources
 *
 * WARNING: This does NOT wait for buffered events to be flushed to the server.
 * Events in the buffer may be lost. Use close() (suspend) for graceful shutdown.
 *
 * This is equivalent to closeNow() - use for compatibility with testing scenarios
 */
- (void)reset __attribute__((swift_name("reset()")));

/**
 * Set the context for all subsequent log events
 * @param processId the process ID
 * @param flowId the flow ID
 * @param validationId the validation ID
 * @param accountId the account ID
 * @param clientId the client ID
 */
- (void)setContextProcessId:(NSString * _Nullable)processId flowId:(NSString * _Nullable)flowId validationId:(NSString * _Nullable)validationId accountId:(NSString * _Nullable)accountId clientId:(NSString * _Nullable)clientId __attribute__((swift_name("setContext(processId:flowId:validationId:accountId:clientId:)")));
@end


/**
 * Helper class for easy SDK logging with automatic event batching
 * Provides convenient methods to log events without directly managing the client
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkLogger")))
@interface TruoraSharedSdkLogger : TruoraSharedBase
- (instancetype)initWithApiKey:(NSString *)apiKey sdkVersion:(NSString *)sdkVersion platform:(NSString *)platform baseUrl:(NSString *)baseUrl deviceModel:(NSString * _Nullable)deviceModel osVersion:(NSString * _Nullable)osVersion maxBufferSize:(int32_t)maxBufferSize flushIntervalMs:(int64_t)flushIntervalMs __attribute__((swift_name("init(apiKey:sdkVersion:platform:baseUrl:deviceModel:osVersion:maxBufferSize:flushIntervalMs:)"))) __attribute__((objc_designated_initializer));

/**
 * Close the logger and release resources
 * Flushes any remaining buffered events before closing
 *
 * Uses NonCancellable context to ensure cleanup completes even if caller cancels the coroutine.
 * All buffered events will be flushed before returning.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)closeWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("close(completionHandler:)")));

/**
 * Synchronous close (for cases where suspend is not available)
 * Note: This will not wait for buffer flush
 */
- (void)closeNow __attribute__((swift_name("closeNow()")));

/**
 * Manually flush buffered events
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)flushWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("flush(completionHandler:)")));

/**
 * Log a batch of events (bypasses buffer)
 */
- (void)logBatchEvents:(NSArray<TruoraSharedSDKEvent *> *)events __attribute__((swift_name("logBatch(events:)")));

/**
 * Convenience method to log camera events
 */
- (void)logCameraEventName:(NSString *)eventName success:(BOOL)success errorMessage:(NSString * _Nullable)errorMessage level:(TruoraSharedEventLevel * _Nullable)level durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logCamera(eventName:success:errorMessage:level:durationMs:metadata:)")));

/**
 * Convenience method to log camera errors with exception
 */
- (void)logCameraErrorEventName:(NSString *)eventName exception:(TruoraSharedKotlinThrowable *)exception level:(TruoraSharedEventLevel *)level durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logCameraError(eventName:exception:level:durationMs:metadata:)")));

/**
 * Convenience method to log device events
 */
- (void)logDeviceEventName:(NSString *)eventName success:(BOOL)success level:(TruoraSharedEventLevel * _Nullable)level metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logDevice(eventName:success:level:metadata:)")));

/**
 * Log a single event (convenience method)
 */
- (void)logEventEventType:(TruoraSharedEventType *)eventType eventName:(NSString *)eventName success:(BOOL)success level:(TruoraSharedEventLevel * _Nullable)level errorMessage:(NSString * _Nullable)errorMessage durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, TruoraSharedKotlinx_serialization_jsonJsonElement *> * _Nullable)metadata stackTrace:(NSString * _Nullable)stackTrace __attribute__((swift_name("logEvent(eventType:eventName:success:level:errorMessage:durationMs:metadata:stackTrace:)")));

/**
 * Log an exception with automatic stack trace extraction
 */
- (void)logExceptionEventType:(TruoraSharedEventType *)eventType eventName:(NSString *)eventName exception:(TruoraSharedKotlinThrowable *)exception level:(TruoraSharedEventLevel *)level durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, TruoraSharedKotlinx_serialization_jsonJsonElement *> * _Nullable)metadata __attribute__((swift_name("logException(eventType:eventName:exception:level:durationMs:metadata:)")));

/**
 * Convenience method to log ML model events
 */
- (void)logMLEventName:(NSString *)eventName success:(BOOL)success level:(TruoraSharedEventLevel * _Nullable)level errorMessage:(NSString * _Nullable)errorMessage durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logML(eventName:success:level:errorMessage:durationMs:metadata:)")));

/**
 * Convenience method to log ML errors with exception
 */
- (void)logMLErrorEventName:(NSString *)eventName exception:(TruoraSharedKotlinThrowable *)exception level:(TruoraSharedEventLevel *)level durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logMLError(eventName:exception:level:durationMs:metadata:)")));

/**
 * Convenience method to log view events
 */
- (void)logViewViewName:(NSString *)viewName success:(BOOL)success level:(TruoraSharedEventLevel * _Nullable)level durationMs:(TruoraSharedLong * _Nullable)durationMs metadata:(NSDictionary<NSString *, id> * _Nullable)metadata __attribute__((swift_name("logView(viewName:success:level:durationMs:metadata:)")));

/**
 * Set context IDs for all subsequent log events
 */
- (void)setContextProcessId:(NSString * _Nullable)processId flowId:(NSString * _Nullable)flowId validationId:(NSString * _Nullable)validationId accountId:(NSString * _Nullable)accountId clientId:(NSString * _Nullable)clientId __attribute__((swift_name("setContext(processId:flowId:validationId:accountId:clientId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ImageUtils_iosKt")))
@interface TruoraSharedImageUtils_iosKt : TruoraSharedBase

/**
 * iOS implementation: Creates a simple test image for previews using Skia.
 */
+ (TruoraSharedKotlinByteArray *)createMockImageBytes __attribute__((swift_name("createMockImageBytes()")));

/**
 * iOS implementation: Decodes JPEG/PNG ByteArray to ImageBitmap using Skia.
 */
+ (id<TruoraSharedUi_graphicsImageBitmap> _Nullable)decodeImageBitmapFromBytesBytes:(TruoraSharedKotlinByteArray *)bytes __attribute__((swift_name("decodeImageBitmapFromBytes(bytes:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocaleKt")))
@interface TruoraSharedLocaleKt : TruoraSharedBase
@property (class) NSString * _Nullable customAppLocale __attribute__((swift_name("customAppLocale")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ModifierExtensionsKt")))
@interface TruoraSharedModifierExtensionsKt : TruoraSharedBase
+ (id<TruoraSharedUiModifier>)fadingEdge:(id<TruoraSharedUiModifier>)receiver brush:(TruoraSharedUi_graphicsBrush *)brush __attribute__((swift_name("fadingEdge(_:brush:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PassiveCaptureOverlayKt")))
@interface TruoraSharedPassiveCaptureOverlayKt : TruoraSharedBase

/**
 * Height of the face capture oval. Exposed for positioning elements relative to the oval.
 */
@property (class, readonly) float PASSIVE_CAPTURE_OVAL_HEIGHT __attribute__((swift_name("PASSIVE_CAPTURE_OVAL_HEIGHT")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Platform_iosKt")))
@interface TruoraSharedPlatform_iosKt : TruoraSharedBase
+ (id<TruoraSharedPlatform>)getPlatform __attribute__((swift_name("getPlatform()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformFileHandle_iosKt")))
@interface TruoraSharedPlatformFileHandle_iosKt : TruoraSharedBase

/**
 * Factory function to create a PlatformFileHandle from iOS NSURL.
 *
 * @param url NSURL pointing to the file (can be local or remote)
 * @param httpClient Optional HttpClient for downloading remote URLs. If not provided, a temporary client will be created.
 * @return PlatformFileHandle instance
 */
+ (TruoraSharedPlatformFileHandle *)createPlatformFileHandleUrl:(NSURL *)url httpClient:(TruoraSharedKtor_client_coreHttpClient * _Nullable)httpClient __attribute__((swift_name("createPlatformFileHandle(url:httpClient:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThemeKt")))
@interface TruoraSharedThemeKt : TruoraSharedBase
@property (class, readonly) TruoraSharedRuntimeProvidableCompositionLocal<TruoraSharedTruoraExtendedColors *> *LocalTruoraExtendedColors __attribute__((swift_name("LocalTruoraExtendedColors")));
@property (class, readonly) TruoraSharedRuntimeProvidableCompositionLocal<TruoraSharedTruoraUIConfig *> *LocalTruoraUIConfig __attribute__((swift_name("LocalTruoraUIConfig")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TruoraUIExportsKt")))
@interface TruoraSharedTruoraUIExportsKt : TruoraSharedBase

/**
 * Helper function to convert UIImage to ByteArray for logo customization.
 * Encodes the image as PNG format.
 *
 * Example Swift usage:
 * ```swift
 * func convertUIImageToByteArray(_ image: UIImage) -> KotlinByteArray {
 *     guard let pngData = image.pngData() else {
 *         return KotlinByteArray(size: 0)
 *     }
 *     return pngData.toKotlinByteArray()
 * }
 *
 * extension Data {
 *     func toKotlinByteArray() -> KotlinByteArray {
 *         let byteArray = KotlinByteArray(size: Int32(self.count))
 *         self.withUnsafeBytes { bufferPointer in
 *             if let baseAddress = bufferPointer.baseAddress {
 *                 for i in 0..<self.count {
 *                     byteArray.set(index: Int32(i), value: Int8(bitPattern: baseAddress.advanced(by: i).load(as: UInt8.self)))
 *                 }
 *             }
 *         }
 *         return byteArray
 *     }
 * }
 * ```
 */
+ (TruoraSharedKotlinByteArray *)convertUIImageToByteArrayImage:(UIImage *)image __attribute__((swift_name("convertUIImageToByteArray(image:)")));

/**
 * Helper function to create a Compose Color from RGBA components (0.0-1.0 range).
 * Use this from Swift to convert UIColor to Compose Color.
 *
 * Example Swift usage:
 * ```swift
 * extension UIColor {
 *     func toComposeColor() -> Color {
 *         var red: CGFloat = 0
 *         var green: CGFloat = 0
 *         var blue: CGFloat = 0
 *         var alpha: CGFloat = 0
 *         getRed(&red, green: &green, blue: &blue, alpha: &alpha)
 *         return TruoraUIExportsKt.createColorFromRGBA(
 *             red: Float(red),
 *             green: Float(green),
 *             blue: Float(blue),
 *             alpha: Float(alpha)
 *         )
 *     }
 * }
 * ```
 *
 * @param red Red component (0.0 to 1.0)
 * @param green Green component (0.0 to 1.0)
 * @param blue Blue component (0.0 to 1.0)
 * @param alpha Alpha component (0.0 to 1.0)
 * @return Compose Color
 */
+ (uint64_t)createColorFromRGBARed:(float)red green:(float)green blue:(float)blue alpha:(float)alpha __attribute__((swift_name("createColorFromRGBA(red:green:blue:alpha:)")));

/**
 * Factory function to create a DocumentIntro (instructions) view controller for iOS integration.
 * This displays the introductory screen before document capture begins.
 *
 * @param isLoading Whether the start button should show loading state
 * @param showHeader Whether to show the header with close button (default: true)
 * @param onEvent Callback for all intro events (StartClicked, CancelClicked)
 * @param config Optional UI configuration for customizing colors and logo
 * @return UIViewController that can be presented or embedded in iOS views
 *
 * Example Swift usage:
 * ```swift
 * let viewController = TruoraUIExportsKt.createDocumentIntroViewController(
 *     isLoading: false,
 *     showHeader: true,
 *     onEvent: { event in
 *         if event is DocumentAutoCaptureIntroEventStartClicked {
 *             self.startDocumentCapture()
 *         } else if event is DocumentAutoCaptureIntroEventCancelClicked {
 *             self.dismiss(animated: true)
 *         }
 *     },
 *     config: nil
 * )
 * navigationController?.pushViewController(viewController, animated: true)
 * ```
 *
 * Example with custom branding:
 * ```swift
 * let config = TruoraUIConfig(
 *     colors: TruoraCustomColors(
 *         purpleDark: UIColor(red: 0.38, green: 0, blue: 0.93, alpha: 1).toComposeColor()
 *     ),
 *     logo: TruoraCustomLogo(
 *         logoData: convertUIImageToByteArray(myLogoImage)
 *     )
 * )
 * let viewController = TruoraUIExportsKt.createDocumentIntroViewController(
 *     isLoading: false,
 *     showHeader: true,
 *     onEvent: { event in // handle events // },
 *     config: config
 * )
 * ```
 */
+ (UIViewController *)createDocumentIntroViewControllerIsLoading:(BOOL)isLoading showHeader:(BOOL)showHeader onEvent:(void (^)(id<TruoraSharedDocumentAutoCaptureIntroEvent>))onEvent config:(TruoraSharedTruoraUIConfig * _Nullable)config __attribute__((swift_name("createDocumentIntroViewController(isLoading:showHeader:onEvent:config:)")));

/**
 * Factory function to create a PassiveCapture view controller for iOS integration.
 * This is the main entry point for Swift/Objective-C code to use the PassiveCapture composable.
 *
 * @param state Current capture state (COUNTDOWN, RECORDING, MANUAL)
 * @param feedback Current feedback type shown to user
 * @param countdown Current countdown value (for COUNTDOWN state)
 * @param showHelpDialog Whether to show the help dialog
 * @param config Optional UI configuration for customizing colors and logo
 * @param lastFrameData Optional JPEG-encoded byte array of the last captured frame for preview
 * @param uploadState Current upload state (NONE, UPLOADING, SUCCESS)
 * @param onEvent Callback for all capture events
 * @param onViewportChanged Optional callback when footer height changes (footerHeight in pixels)
 * @return UIViewController that can be presented or embedded in iOS views
 *
 * Example Swift usage:
 * ```swift
 * let viewController = TruoraUIExportsKt.createPassiveCaptureViewController(
 *     state: .countdown,
 *     feedback: .showFace,
 *     countdown: 3,
 *     showHelpDialog: false,
 *     config: nil,
 *     lastFrameData: nil,
 *     uploadState: .none,
 *     onEvent: { event in
 *         // Handle capture events
 *     }
 * )
 * navigationController?.pushViewController(viewController, animated: true)
 * ```
 *
 * Example with custom branding:
 * ```swift
 * let config = TruoraUIConfig(
 *     colors: TruoraCustomColors(
 *         surface: UIColor(red: 1, green: 1, blue: 1, alpha: 1).toComposeColor(),
 *         onSurface: UIColor(red: 0.16, green: 0.16, blue: 0.16, alpha: 1).toComposeColor(),
 *         error: UIColor(red: 1, green: 0.33, blue: 0.33, alpha: 1).toComposeColor()
 *     ),
 *     logo: TruoraCustomLogo(
 *         logoData: convertUIImageToByteArray(myLogoImage)
 *     )
 * )
 * let viewController = TruoraUIExportsKt.createPassiveCaptureViewController(
 *     state: .countdown,
 *     feedback: .showFace,
 *     config: config,
 *     onEvent: { event in ** handle events ** }
 * )
 * ```
 */
+ (UIViewController *)createPassiveCaptureViewControllerState:(TruoraSharedPassiveCaptureState *)state feedback:(TruoraSharedFeedbackType *)feedback countdown:(int32_t)countdown showHelpDialog:(BOOL)showHelpDialog config:(TruoraSharedTruoraUIConfig * _Nullable)config lastFrameData:(TruoraSharedKotlinByteArray * _Nullable)lastFrameData uploadState:(TruoraSharedUploadState *)uploadState onEvent:(void (^)(id<TruoraSharedPassiveCaptureEvent>))onEvent onViewportChanged:(void (^ _Nullable)(TruoraSharedInt *))onViewportChanged __attribute__((swift_name("createPassiveCaptureViewController(state:feedback:countdown:showHelpDialog:config:lastFrameData:uploadState:onEvent:onViewportChanged:)")));

/**
 * Factory function to create a PassiveIntro (instructions) view controller for iOS integration.
 * This displays the introductory screen before passive capture begins.
 *
 * @param onStart Callback when user taps start button
 * @param onCancel Callback when user taps cancel/close button
 * @param config Optional UI configuration for customizing colors and logo
 * @return UIViewController that can be presented or embedded in iOS views
 *
 * Example Swift usage:
 * ```swift
 * let viewController = TruoraUIExportsKt.createPassiveIntroViewController(
 *     onStart: { [weak self] in
 *         self?.startPassiveCapture()
 *     },
 *     onCancel: { [weak self] in
 *         self?.dismiss(animated: true)
 *     },
 *     config: nil
 * )
 * navigationController?.pushViewController(viewController, animated: true)
 * ```
 *
 * Example with custom branding:
 * ```swift
 * let config = TruoraUIConfig(
 *     colors: TruoraCustomColors(
 *         surface: UIColor(red: 1, green: 1, blue: 1, alpha: 1).toComposeColor(),
 *         onSurface: UIColor(red: 0.16, green: 0.16, blue: 0.16, alpha: 1).toComposeColor()
 *     ),
 *     logo: TruoraCustomLogo(
 *         logoData: convertUIImageToByteArray(myLogoImage)
 *     )
 * )
 * let viewController = TruoraUIExportsKt.createPassiveIntroViewController(
 *     onStart: { // handle start },
 *     onCancel: { // handle cancel },
 *     config: config
 * )
 * ```
 */
+ (UIViewController *)createPassiveIntroViewControllerOnStart:(void (^)(void))onStart onCancel:(void (^)(void))onCancel config:(TruoraSharedTruoraUIConfig * _Nullable)config __attribute__((swift_name("createPassiveIntroViewController(onStart:onCancel:config:)")));

/**
 * Factory function to create a ValidationResult view controller for iOS integration.
 * This displays the final result screen for any validation process (success, completed, failure).
 *
 * @param validationResult The type of validation result (SUCCESS, COMPLETED, or FAILURE)
 * @param date The date when the verification was completed/attempted
 * @param isLoading Whether the finish button should show loading state
 * @param showLoadingScreen Whether to display the loading screen instead of the result view
 * @param loadingType The type of loading animation (Face or Document), defaults to Face
 * @param onEvent Callback for validation result events
 * @param config Optional UI configuration for customizing colors and logo
 * @return UIViewController that can be presented or embedded in iOS views
 *
 * Example Swift usage:
 * ```swift
 * let config = TruoraUIConfig(
 *     colors: TruoraCustomColors(
 *         surface: UIColor(red: 1, green: 1, blue: 1, alpha: 1).toComposeColor(),
 *         onSurface: UIColor(red: 0.16, green: 0.16, blue: 0.16, alpha: 1).toComposeColor()
 *     ),
 *     logo: TruoraCustomLogo(
 *         logoData: convertUIImageToByteArray(myLogoImage)
 *     )
 * )
 *
 * let viewController = TruoraUIExportsKt.createValidationResultViewController(
 *     validationResult: .success,
 *     date: "26 de noviembre de 2024",
 *     isLoading: false,
 *     showLoadingScreen: false,
 *     loadingType: .face,
 *     onEvent: {
 *         // Handle finish button click
 *         self.dismiss(animated: true)
 *     },
 *     config: config
 * )
 * navigationController?.pushViewController(viewController, animated: true)
 * ```
 */
+ (UIViewController *)createValidationResultViewControllerValidationResult:(TruoraSharedValidationResultType *)validationResult date:(NSString *)date isLoading:(BOOL)isLoading showLoadingScreen:(BOOL)showLoadingScreen loadingType:(TruoraSharedLoadingType *)loadingType onEvent:(void (^)(void))onEvent config:(TruoraSharedTruoraUIConfig * _Nullable)config __attribute__((swift_name("createValidationResultViewController(validationResult:date:isLoading:showLoadingScreen:loadingType:onEvent:config:)")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface TruoraSharedKotlinRuntimeException : TruoraSharedKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface TruoraSharedKotlinIllegalStateException : TruoraSharedKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface TruoraSharedKotlinCancellationException : TruoraSharedKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface TruoraSharedKotlinEnumCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface TruoraSharedKotlinArray<T> : TruoraSharedBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(TruoraSharedInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<TruoraSharedKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Ui_graphicsImageBitmap")))
@protocol TruoraSharedUi_graphicsImageBitmap
@required
- (void)prepareToDraw __attribute__((swift_name("prepareToDraw()")));
- (void)readPixelsBuffer:(TruoraSharedKotlinIntArray *)buffer startX:(int32_t)startX startY:(int32_t)startY width:(int32_t)width height:(int32_t)height bufferOffset:(int32_t)bufferOffset stride:(int32_t)stride __attribute__((swift_name("readPixels(buffer:startX:startY:width:height:bufferOffset:stride:)")));
@property (readonly) TruoraSharedUi_graphicsColorSpace *colorSpace __attribute__((swift_name("colorSpace")));
@property (readonly) int32_t config __attribute__((swift_name("config")));
@property (readonly) BOOL hasAlpha __attribute__((swift_name("hasAlpha")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((swift_name("LibraryResource")))
@interface TruoraSharedLibraryResource : TruoraSharedBase
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LibraryStringResource")))
@interface TruoraSharedLibraryStringResource : TruoraSharedLibraryResource
- (instancetype)initWithId:(NSString *)id key:(NSString *)key items:(NSSet<TruoraSharedLibraryResourceItem *> *)items __attribute__((swift_name("init(id:key:items:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LibraryDrawableResource")))
@interface TruoraSharedLibraryDrawableResource : TruoraSharedLibraryResource
- (instancetype)initWithId:(NSString *)id items:(NSSet<TruoraSharedLibraryResourceItem *> *)items __attribute__((swift_name("init(id:items:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface TruoraSharedKotlinByteArray : TruoraSharedBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(TruoraSharedByte *(^)(TruoraSharedInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (TruoraSharedKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end


/**
 * A message either from the client or the server,
 * that has [headers] associated.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMessage)
 */
__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol TruoraSharedKtor_httpHttpMessage
@required

/**
 * Message [Headers]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMessage.headers)
 */
@property (readonly) id<TruoraSharedKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol TruoraSharedKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<TruoraSharedKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end


/**
 * An [HttpClient]'s response, a second part of [HttpClientCall].
 *
 * Learn more from [Receiving responses](https://ktor.io/docs/response.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse)
 */
__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface TruoraSharedKtor_client_coreHttpResponse : TruoraSharedBase <TruoraSharedKtor_httpHttpMessage, TruoraSharedKotlinx_coroutines_coreCoroutineScope>

/**
 * An [HttpClient]'s response, a second part of [HttpClientCall].
 *
 * Learn more from [Receiving responses](https://ktor.io/docs/response.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse)
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * An [HttpClient]'s response, a second part of [HttpClientCall].
 *
 * Learn more from [Receiving responses](https://ktor.io/docs/response.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse)
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * The associated [HttpClientCall] containing both
 * the underlying [HttpClientCall.request] and [HttpClientCall.response].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.call)
 */
@property (readonly) TruoraSharedKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));

/**
 * Provides a raw [ByteReadChannel] to the response content as it is read from the network.
 * This content can be still compressed or encoded.
 *
 * This content doesn't go through any interceptors from [HttpResponsePipeline].
 *
 * If you need to read the content as decoded bytes, use the [bodyAsChannel] method instead.
 *
 * This property produces a new channel every time it's accessed.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.rawContent)
 */
@property (readonly) id<TruoraSharedKtor_ioByteReadChannel> rawContent __attribute__((swift_name("rawContent")));

/**
 * [GMTDate] of the request start.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.requestTime)
 */
@property (readonly) TruoraSharedKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));

/**
 * [GMTDate] of the response start.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.responseTime)
 */
@property (readonly) TruoraSharedKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));

/**
 * The [HttpStatusCode] returned by the server. It includes both,
 * the [HttpStatusCode.description] and the [HttpStatusCode.value] (code).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.status)
 */
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));

/**
 * HTTP version. Usually [HttpProtocolVersion.HTTP_1_1] or [HttpProtocolVersion.HTTP_2_0].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponse.version)
 */
@property (readonly) TruoraSharedKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="2.0")
*/
__attribute__((swift_name("KotlinAutoCloseable")))
@protocol TruoraSharedKotlinAutoCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol TruoraSharedKtor_ioCloseable <TruoraSharedKotlinAutoCloseable>
@required
@end


/**
 * A multiplatform asynchronous HTTP client that allows you to make requests, handle responses,
 * and extend its functionality with plugins such as authentication, JSON serialization, and more.
 *
 * # Creating client
 * To create a new client, you can call:
 * ```kotlin
 * val client = HttpClient()
 * ```
 * You can create as many clients as you need.
 *
 * If you no longer need the client, please consider closing it to release resources:
 * ```
 * client.close()
 * ```
 *
 * To learn more on how to create and configure an [HttpClient] see the tutorial page:
 * [Creating and configuring a client](https://ktor.io/docs/create-client.html).
 *
 * # Making API Requests
 * For every HTTP method (GET, POST, PUT, etc.), there is a corresponding function:
 * ```kotlin
 * val response: HttpResponse = client.get("https://ktor.io/")
 * val body = response.bodyAsText()
 * ```
 * See [Making HTTP requests](https://ktor.io/docs/client-requests.html) for more details.
 *
 * # Query Parameters
 * Add query parameters to your request using the `parameter` function:
 * ```kotlin
 * val response = client.get("https://google.com/search") {
 *     url {
 *         parameter("q", "REST API with Ktor")
 *     }
 * }
 * ```
 * For more information, refer to [Passing request parameters](https://ktor.io/docs/client-requests.html#parameters).
 *
 * # Adding Headers
 * Include headers in your request using the `headers` builder or the `header` function:
 * ```kotlin
 * val response = client.get("https://httpbin.org/bearer") {
 *     headers {
 *         append("Authorization", "Bearer your_token_here")
 *         append("Accept", "application/json")
 *     }
 * }
 * ```
 * Learn more at [Adding headers to a request](https://ktor.io/docs/client-requests.html#headers).
 *
 * # JSON Serialization
 * Add dependencies:
 * - io.ktor:ktor-client-content-negotiation:3.+
 * - io.ktor:ktor-serialization-kotlinx-json:3.+
 * Add Gradle plugin:
 * ```
 * plugins {
 *     kotlin("plugin.serialization")
 * }
 * ```
 *
 * Send and receive JSON data by installing the `ContentNegotiation` plugin with `kotlinx.serialization`:
 * ```kotlin
 * val client = HttpClient {
 *     install(ContentNegotiation) {
 *         json()
 *     }
 * }
 *
 * @Serializable
 * data class MyRequestType(val someData: String)
 *
 * @Serializable
 * data class MyResponseType(val someResponseData: String)
 *
 * val response: MyResponseType = client.post("https://api.example.com/data") {
 *     contentType(ContentType.Application.Json)
 *     setBody(MyRequestType(someData = "value"))
 * }.body()
 * ```
 * See [Serializing JSON data](https://ktor.io/docs/client-serialization.html) for maven configuration and other details.
 *
 * # Submitting Forms
 * Submit form data using `FormDataContent` or the `submitForm` function:
 * ```kotlin
 * // Using FormDataContent
 * val response = client.post("https://example.com/submit") {
 *     setBody(FormDataContent(Parameters.build {
 *         append("username", "user")
 *         append("password", "pass")
 *     }))
 * }
 *
 * // Or using submitForm
 * val response = client.submitForm(
 *     url = "https://example.com/submit",
 *     formParameters = Parameters.build {
 *         append("username", "user")
 *         append("password", "pass")
 *     }
 * )
 * ```
 * More information is available at [Submitting form parameters](https://ktor.io/docs/client-requests.html#form_parameters).
 *
 * # Handling Authentication
 * Add dependency: io.ktor:ktor-client-auth:3.+
 *
 * Use the `Auth` plugin to handle various authentication schemes like Basic or Bearer token authentication:
 * ```kotlin
 * val client = HttpClient {
 *     install(Auth) {
 *         bearer {
 *             loadTokens {
 *                 BearerTokens(accessToken = "your_access_token", refreshToken = "your_refresh_token")
 *             }
 *         }
 *     }
 * }
 *
 * val response = client.get("https://api.example.com/protected")
 * ```
 * Refer to [Client authentication](https://ktor.io/docs/client-auth.html) for more details.
 *
 * # Setting Timeouts and Retries
 * Configure timeouts and implement retry logic for your requests:
 * ```kotlin
 * val client = HttpClient {
 *     install(HttpTimeout) {
 *         requestTimeoutMillis = 10000
 *         connectTimeoutMillis = 5000
 *         socketTimeoutMillis = 15000
 *     }
 * }
 * ```
 *
 * For the request timeout:
 * ```kotlin
 * client.get("") {
 *     timeout {
 *         requestTimeoutMillis = 1000
 *     }
 * }
 * ```
 * See [Timeout](https://ktor.io/docs/client-timeout.html) for more information.
 *
 * # Handling Cookies
 *
 * Manage cookies automatically by installing the `HttpCookies` plugin:
 * ```kotlin
 * val client = HttpClient {
 *     install(HttpCookies) {
 *         storage = AcceptAllCookiesStorage()
 *     }
 * }
 *
 * // Accessing cookies
 * val cookies: List<Cookie> = client.cookies("https://example.com")
 * ```
 * Learn more at [Cookies](https://ktor.io/docs/client-cookies.html).
 *
 * # Uploading Files
 * Upload files using multipart/form-data requests:
 * ```kotlin
 * client.submitFormWithBinaryData(
 *      url = "https://example.com/upload",
 *      formData = formData {
 *          append("description", "File upload example")
 *          append("file", {
 *              File("path/to/file.txt").readChannel()
 *          })
 *      }
 *  )
 *
 * See [Uploading data](https://ktor.io/docs/client-requests.html#upload_file) for details.
 *
 * # Using WebSockets
 *
 * Communicate over WebSockets using the `webSocket` function:
 * ```kotlin
 * client.webSocket("wss://echo.websocket.org") {
 *     send(Frame.Text("Hello, WebSocket!"))
 *     val frame = incoming.receive()
 *     if (frame is Frame.Text) {
 *         println("Received: ${frame.readText()}")
 *     }
 * }
 * ```
 * Learn more at [Client WebSockets](https://ktor.io/docs/client-websockets.html).
 *
 * # Error Handling
 * Handle exceptions and HTTP error responses gracefully:
 * val client = HttpClient {
 *     HttpResponseValidator {
 *         validateResponse { response ->
 *             val statusCode = response.status.value
 *             when (statusCode) {
 *                 in 300..399 -> error("Redirects are not allowed")
 *             }
 *         }
 *     }
 * }
 * See [Error handling](https://ktor.io/docs/client-response-validation.html) for more information.
 *
 * # Configuring SSL/TLS
 *
 * Customize SSL/TLS settings for secure connections is engine-specific. Please refer to the following page for
 * the details: [Client SSL/TLS](https://ktor.io/docs/client-ssl.html).
 *
 * # Using Proxies
 * Route requests through an HTTP or SOCKS proxy:
 * ```kotlin
 * val client = HttpClient() {
 *     engine {
 *         proxy = ProxyBuilder.http("http://proxy.example.com:8080")
 *         // For a SOCKS proxy:
 *         // proxy = ProxyBuilder.socks(host = "proxy.example.com", port = 1080)
 *     }
 * }
 * ```
 * See [Using a proxy](https://ktor.io/docs/client-proxy.html) for details.
 *
 * # Streaming Data
 *
 * Stream large data efficiently without loading it entirely into memory.
 *
 * Stream request:
 * ```kotlin
 * val response = client.post("https://example.com/upload") {
 *      setBody(object: OutgoingContent.WriteChannelContent() {
 *          override suspend fun writeTo(channel: ByteWriteChannel) {
 *              repeat(1000) {
 *                  channel.writeString("Hello!")
 *              }
 *          }
 *      })
 * }
 * ```
 *
 * Stream response:
 * ```kotlin
 * client.prepareGet("https://example.com/largefile.zip").execute { response ->
 *     val channel: ByteReadChannel = response.bodyAsChannel()
 *
 *     while (!channel.exhausted()) {
 *         val chunk = channel.readBuffer()
 *         // ...
 *     }
 * }
 * ```
 * Learn more at [Streaming data](https://ktor.io/docs/client-responses.html#streaming).
 *
 * # Using SSE
 * Server-Sent Events (SSE) is a technology that allows a server to continuously push events to a client over an HTTP
 * connection. It's particularly useful in cases where the server needs to send event-based updates without requiring
 * the client to repeatedly poll the server.
 *
 * Install the plugin:
 * ```kotlin
 * val client = HttpClient(CIO) {
 *     install(SSE)
 * }
 * ```
 *
 * ```
 * client.sse(host = "0.0.0.0", port = 8080, path = "/events") {
 *     while (true) {
 *         for (event in incoming) {
 *             println("Event from server:")
 *             println(event)
 *         }
 *     }
 * }
 * ```
 *
 * Visit [Using SSE](https://ktor.io/docs/client-server-sent-events.html#install_plugin) to learn more.
 *
 * # Customizing a client with plugins
 * To extend out-of-the-box functionality, you can install plugins for a Ktor client:
 * ```kotlin
 * val client = HttpClient {
 *     install(ContentNegotiation) {
 *         json()
 *     }
 * }
 * ```
 *
 * There are many plugins available out of the box, and you can write your own. See
 * [Create custom client plugins](https://ktor.io/docs/client-custom-plugins.html) to learn more.
 *
 * # Service Loader and Default Engine
 * On JVM, calling `HttpClient()` without specifying an engine uses a service loader mechanism to
 * determine the appropriate default engine. This can introduce a performance overhead, especially on
 * slower devices, such as Android.
 *
 * **Performance Note**: If you are targeting platforms where initialization speed is critical,
 * consider explicitly specifying an engine to avoid the service loader lookup.
 *
 * Example with manual engine specification:
 * ```
 * val client = HttpClient(Apache) // Explicitly uses Apache engine, bypassing service loader
 * ```
 *
 * By directly setting the engine (e.g., `Apache`, `OkHttp`), you can optimize startup performance
 * by preventing the default service loader mechanism.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface TruoraSharedKtor_client_coreHttpClient : TruoraSharedBase <TruoraSharedKotlinx_coroutines_coreCoroutineScope, TruoraSharedKtor_ioCloseable>
- (instancetype)initWithEngine:(id<TruoraSharedKtor_client_coreHttpClientEngine>)engine userConfig:(TruoraSharedKtor_client_coreHttpClientConfig<TruoraSharedKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));

/**
 * Initiates the shutdown process for the `HttpClient`. This is a non-blocking call, which
 * means it returns immediately and begins the client closure in the background.
 *
 * ## Usage
 * ```
 * val client = HttpClient()
 * client.close()
 * client.coroutineContext.job.join() // Waits for complete termination if necessary
 * ```
 *
 * ## Important Notes
 * - **Non-blocking**: `close()` only starts the closing process and does not wait for it to complete.
 * - **Coroutine Context**: To wait for all client resources to be freed, use `client.coroutineContext.job.join()`
 *   or `client.coroutineContext.cancel()` to terminate ongoing tasks.
 * - **Manual Engine Management**: If a custom `engine` was manually created, it must be closed explicitly
 *   after calling `client.close()` to release all resources.
 *
 * Example with custom engine management:
 * ```
 * val engine = HttpClientEngine() // Custom engine instance
 * val client = HttpClient(engine)
 *
 * client.close()
 * engine.close() // Ensure manually created engine is also closed
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.close)
 */
- (void)close __attribute__((swift_name("close()")));

/**
 * Returns a new [HttpClient] by copying this client's configuration
 * and additionally configured by the [block] parameter.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.config)
 */
- (TruoraSharedKtor_client_coreHttpClient *)configBlock:(void (^)(TruoraSharedKtor_client_coreHttpClientConfig<id> *))block __attribute__((swift_name("config(block:)")));

/**
 * Checks if the specified [capability] is supported by this client.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.isSupported)
 */
- (BOOL)isSupportedCapability:(id<TruoraSharedKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * Typed attributes used as a lightweight container for this client.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.attributes)
 */
@property (readonly) id<TruoraSharedKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<TruoraSharedKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<TruoraSharedKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));

/**
 * Provides access to the client's engine configuration.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.engineConfig)
 */
@property (readonly) TruoraSharedKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));

/**
 * Provides access to the events of the client's lifecycle.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.monitor)
 */
@property (readonly) TruoraSharedKtor_eventsEvents *monitor __attribute__((swift_name("monitor")));

/**
 * A pipeline used for receiving a request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.receivePipeline)
 */
@property (readonly) TruoraSharedKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));

/**
 * A pipeline used for processing all requests sent by this client.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.requestPipeline)
 */
@property (readonly) TruoraSharedKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));

/**
 * A pipeline used for processing all responses sent by the server.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.responsePipeline)
 */
@property (readonly) TruoraSharedKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));

/**
 * A pipeline used for sending a request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClient.sendPipeline)
 */
@property (readonly) TruoraSharedKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol TruoraSharedKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<TruoraSharedKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<TruoraSharedKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol TruoraSharedKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<TruoraSharedKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<TruoraSharedKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol TruoraSharedKotlinx_serialization_coreKSerializer <TruoraSharedKotlinx_serialization_coreSerializationStrategy, TruoraSharedKotlinx_serialization_coreDeserializationStrategy>
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/serialization/json/JsonElementSerializer))
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface TruoraSharedKotlinx_serialization_jsonJsonElement : TruoraSharedBase
@property (class, readonly, getter=companion) TruoraSharedKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinPair")))
@interface TruoraSharedKotlinPair<__covariant A, __covariant B> : TruoraSharedBase
- (instancetype)initWithFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("init(first:second:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedKotlinPair<A, B> *)doCopyFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("doCopy(first:second:)")));
- (BOOL)equalsOther:(id _Nullable)other __attribute__((swift_name("equals(other:)")));
- (int32_t)hashCode __attribute__((swift_name("hashCode()")));
- (NSString *)toString __attribute__((swift_name("toString()")));
@property (readonly) A _Nullable first __attribute__((swift_name("first")));
@property (readonly) B _Nullable second __attribute__((swift_name("second")));
@end


/**
 * Represents a header value that consist of [content] followed by [parameters].
 * Useful for headers such as `Content-Type`, `Content-Disposition` and so on.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HeaderValueWithParameters)
 *
 * @property content header's content without parameters
 * @property parameters
 */
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface TruoraSharedKtor_httpHeaderValueWithParameters : TruoraSharedBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<TruoraSharedKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKtor_httpHeaderValueWithParametersCompanion *companion __attribute__((swift_name("companion")));

/**
 * The first value for the parameter with [name] comparing case-insensitively or `null` if no such parameters found
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HeaderValueWithParameters.parameter)
 */
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<TruoraSharedKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end


/**
 * Represents a value for a `Content-Type` header.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType)
 *
 * @property contentType represents a type part of the media type.
 * @property contentSubtype represents a subtype part of the media type.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface TruoraSharedKtor_httpContentType : TruoraSharedKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<TruoraSharedKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<TruoraSharedKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedKtor_httpContentTypeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Checks if `this` type matches a [pattern] type taking into account placeholder symbols `*` and parameters.
 * The `this` type must be a more specific type than the [pattern] type. In other words:
 *
 * ```kotlin
 * ContentType("a", "b").match(ContentType("a", "b").withParameter("foo", "bar")) === false
 * ContentType("a", "b").withParameter("foo", "bar").match(ContentType("a", "b")) === true
 * ContentType("a", "*").match(ContentType("a", "b")) === false
 * ContentType("a", "b").match(ContentType("a", "*")) === true
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.match)
 */
- (BOOL)matchPattern:(TruoraSharedKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));

/**
 * Checks if `this` type matches a [pattern] type taking into account placeholder symbols `*` and parameters.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.match)
 */
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));

/**
 * Creates a copy of `this` type with the added parameter with the [name] and [value].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.withParameter)
 */
- (TruoraSharedKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));

/**
 * Creates a copy of `this` type without any parameters
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.withoutParameters)
 */
- (TruoraSharedKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
__attribute__((swift_name("UiModifier")))
@protocol TruoraSharedUiModifier
@required
- (BOOL)allPredicate:(TruoraSharedBoolean *(^)(id<TruoraSharedUiModifierElement>))predicate __attribute__((swift_name("all(predicate:)")));
- (BOOL)anyPredicate:(TruoraSharedBoolean *(^)(id<TruoraSharedUiModifierElement>))predicate __attribute__((swift_name("any(predicate:)")));
- (id _Nullable)foldInInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<TruoraSharedUiModifierElement>))operation __attribute__((swift_name("foldIn(initial:operation:)")));
- (id _Nullable)foldOutInitial:(id _Nullable)initial operation:(id _Nullable (^)(id<TruoraSharedUiModifierElement>, id _Nullable))operation __attribute__((swift_name("foldOut(initial:operation:)")));
- (id<TruoraSharedUiModifier>)thenOther:(id<TruoraSharedUiModifier>)other __attribute__((swift_name("then(other:)")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((swift_name("Ui_graphicsBrush")))
@interface TruoraSharedUi_graphicsBrush : TruoraSharedBase
@property (class, readonly, getter=companion) TruoraSharedUi_graphicsBrushCompanion *companion __attribute__((swift_name("companion")));
- (void)applyToSize:(int64_t)size p:(id<TruoraSharedUi_graphicsPaint>)p alpha:(float)alpha __attribute__((swift_name("applyTo(size:p:alpha:)")));
@property (readonly) int64_t intrinsicSize __attribute__((swift_name("intrinsicSize")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
__attribute__((swift_name("RuntimeCompositionLocal")))
@interface TruoraSharedRuntimeCompositionLocal<T> : TruoraSharedBase
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
__attribute__((swift_name("RuntimeProvidableCompositionLocal")))
@interface TruoraSharedRuntimeProvidableCompositionLocal<T> : TruoraSharedRuntimeCompositionLocal<T>
- (TruoraSharedRuntimeProvidedValue<T> *)providesValue:(T _Nullable)value __attribute__((swift_name("provides(value:)")));
- (TruoraSharedRuntimeProvidedValue<T> *)providesComputedCompute:(T _Nullable (^)(id<TruoraSharedRuntimeCompositionLocalAccessorScope>))compute __attribute__((swift_name("providesComputed(compute:)")));
- (TruoraSharedRuntimeProvidedValue<T> *)providesDefaultValue:(T _Nullable)value __attribute__((swift_name("providesDefault(value:)")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol TruoraSharedKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinIntArray")))
@interface TruoraSharedKotlinIntArray : TruoraSharedBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(TruoraSharedInt *(^)(TruoraSharedInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int32_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (TruoraSharedKotlinIntIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int32_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Ui_graphicsColorSpace")))
@interface TruoraSharedUi_graphicsColorSpace : TruoraSharedBase
- (instancetype)initWithName:(NSString *)name model:(int64_t)model __attribute__((swift_name("init(name:model:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * @note annotations
 *   androidx.annotation.Size(min=3.toLong())
 * @param v annotations androidx.annotation.Size(min=3.toLong())
*/
- (TruoraSharedKotlinFloatArray *)fromXyzV:(TruoraSharedKotlinFloatArray *)v __attribute__((swift_name("fromXyz(v:)")));

/**
 * @note annotations
 *   androidx.annotation.Size(min=3.toLong())
*/
- (TruoraSharedKotlinFloatArray *)fromXyzX:(float)x y:(float)y z:(float)z __attribute__((swift_name("fromXyz(x:y:z:)")));

/**
 * @param component annotations androidx.annotation.IntRange(from=0.toLong(), to=3.toLong())
*/
- (float)getMaxValueComponent:(int32_t)component __attribute__((swift_name("getMaxValue(component:)")));

/**
 * @param component annotations androidx.annotation.IntRange(from=0.toLong(), to=3.toLong())
*/
- (float)getMinValueComponent:(int32_t)component __attribute__((swift_name("getMinValue(component:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   androidx.annotation.Size(min=3.toLong())
 * @param v annotations androidx.annotation.Size(min=3.toLong())
*/
- (TruoraSharedKotlinFloatArray *)toXyzV:(TruoraSharedKotlinFloatArray *)v __attribute__((swift_name("toXyz(v:)")));

/**
 * @note annotations
 *   androidx.annotation.Size(value=3.toLong())
*/
- (TruoraSharedKotlinFloatArray *)toXyzR:(float)r g:(float)g b:(float)b __attribute__((swift_name("toXyz(r:g:b:)")));
@property (readonly) int32_t componentCount __attribute__((swift_name("componentCount")));
@property (readonly) BOOL isSrgb __attribute__((swift_name("isSrgb")));
@property (readonly) BOOL isWideGamut __attribute__((swift_name("isWideGamut")));
@property (readonly) int64_t model __attribute__((swift_name("model")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LibraryResourceItem")))
@interface TruoraSharedLibraryResourceItem : TruoraSharedBase
- (instancetype)initWithQualifiers:(NSSet<id<TruoraSharedLibraryQualifier>> *)qualifiers path:(NSString *)path offset:(int64_t)offset size:(int64_t)size __attribute__((swift_name("init(qualifiers:path:offset:size:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedLibraryResourceItem *)doCopyQualifiers:(NSSet<id<TruoraSharedLibraryQualifier>> *)qualifiers path:(NSString *)path offset:(int64_t)offset size:(int64_t)size __attribute__((swift_name("doCopy(qualifiers:path:offset:size:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface TruoraSharedKotlinByteIterator : TruoraSharedBase <TruoraSharedKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (TruoraSharedByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end


/**
 * Provides data structure for associating a [String] with a [List] of Strings
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues)
 */
__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol TruoraSharedKtor_utilsStringValues
@required

/**
 * Checks if the given [name] exists in the map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.contains)
 */
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));

/**
 * Checks if the given [name] and [value] pair exists in the map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.contains)
 */
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));

/**
 * Gets all entries from the map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.entries)
 */
- (NSSet<id<TruoraSharedKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));

/**
 * Iterates over all entries in this map and calls [body] for each pair
 *
 * Can be optimized in implementations
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.forEach)
 */
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));

/**
 * Gets first value from the list of values associated with a [name], or null if the name is not present
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.get)
 */
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));

/**
 * Gets all values associated with the [name], or null if the name is not present
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.getAll)
 */
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));

/**
 * Checks if this map is empty
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.isEmpty)
 */
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));

/**
 * Gets all names from the map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.names)
 */
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));

/**
 * Specifies if map has case-sensitive or case-insensitive names
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.StringValues.caseInsensitiveName)
 */
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end


/**
 * Represents HTTP headers as a map from case-insensitive names to collection of [String] values
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Headers)
 */
__attribute__((swift_name("Ktor_httpHeaders")))
@protocol TruoraSharedKtor_httpHeaders <TruoraSharedKtor_utilsStringValues>
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol TruoraSharedKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<TruoraSharedKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<TruoraSharedKotlinCoroutineContextElement> _Nullable)getKey:(id<TruoraSharedKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<TruoraSharedKotlinCoroutineContext>)minusKeyKey:(id<TruoraSharedKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<TruoraSharedKotlinCoroutineContext>)plusContext:(id<TruoraSharedKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end


/**
 * A pair of a [request] and [response] for a specific [HttpClient].
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall)
 *
 * @property client the client that executed the call.
 */
__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface TruoraSharedKtor_client_coreHttpClientCall : TruoraSharedBase <TruoraSharedKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithClient:(TruoraSharedKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithClient:(TruoraSharedKtor_client_coreHttpClient *)client requestData:(TruoraSharedKtor_client_coreHttpRequestData *)requestData responseData:(TruoraSharedKtor_client_coreHttpResponseData *)responseData __attribute__((swift_name("init(client:requestData:responseData:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKtor_client_coreHttpClientCallCompanion *companion __attribute__((swift_name("companion")));

/**
 * Tries to receive the payload of the [response] as a specific expected type provided in [info].
 * Returns [response] if [info] corresponds to [HttpResponse].
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall.body)
 *
 * @throws NoTransformationFoundException If no transformation is found for the type [info].
 * @throws DoubleReceiveException If already called [body].
 * @throws NullPointerException If content is `null`.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyInfo:(TruoraSharedKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("body(info:completionHandler:)")));

/**
 * Tries to receive the payload of the [response] as a specific expected type provided in [info].
 * Returns [response] if [info] corresponds to [HttpResponse].
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall.bodyNullable)
 *
 * @throws NoTransformationFoundException If no transformation is found for the type [info].
 * @throws DoubleReceiveException If already called [body].
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyNullableInfo:(TruoraSharedKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("bodyNullable(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)getResponseContentWithCompletionHandler:(void (^)(id<TruoraSharedKtor_ioByteReadChannel> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseContent(completionHandler:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) BOOL allowDoubleReceive __attribute__((swift_name("allowDoubleReceive")));

/**
 * Typed [Attributes] associated to this call serving as a lightweight container.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall.attributes)
 */
@property (readonly) id<TruoraSharedKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) TruoraSharedKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<TruoraSharedKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));

/**
 * The [request] sent by the client.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall.request)
 */
@property id<TruoraSharedKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));

/**
 * The [response] sent by the server.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.call.HttpClientCall.response)
 */
@property TruoraSharedKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end


/**
 * Channel for asynchronous reading of sequences of bytes.
 * This is a **single-reader channel**.
 *
 * Operations on this channel cannot be invoked concurrently.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.utils.io.ByteReadChannel)
 */
__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol TruoraSharedKtor_ioByteReadChannel
@required

/**
 * Suspend the channel until it has [min] bytes or gets closed. Throws exception if the channel was closed with an
 * error. If there are bytes available in the channel, this function returns immediately.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.utils.io.ByteReadChannel.awaitContent)
 *
 * @return return `false` eof is reached, otherwise `true`.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitContentMin:(int32_t)min completionHandler:(void (^)(TruoraSharedBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("awaitContent(min:completionHandler:)")));
- (void)cancelCause:(TruoraSharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
@property (readonly) TruoraSharedKotlinThrowable * _Nullable closedCause __attribute__((swift_name("closedCause")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) id<TruoraSharedKotlinx_io_coreSource> readBuffer __attribute__((swift_name("readBuffer")));
@end


/**
 * Date in GMT timezone
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.GMTDate)
 *
 * @property seconds: seconds from 0 to 60(last is for leap second)
 * @property minutes: minutes from 0 to 59
 * @property hours: hours from 0 to 23
 * @property dayOfWeek an instance of the corresponding day of week
 * @property dayOfMonth: day of month from 1 to 31
 * @property dayOfYear: day of year from 1 to 366
 * @property month an instance of the corresponding month
 * @property year: year in common era(CE: https://en.wikipedia.org/wiki/Common_Era)
 *
 * @property timestamp is a number of epoch milliseconds
 *
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface TruoraSharedKtor_utilsGMTDate : TruoraSharedBase <TruoraSharedKotlinComparable>
- (instancetype)initWithSeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(TruoraSharedKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(TruoraSharedKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("init(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKtor_utilsGMTDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(TruoraSharedKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (TruoraSharedKtor_utilsGMTDate *)doCopy __attribute__((swift_name("doCopy()")));
- (TruoraSharedKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(TruoraSharedKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(TruoraSharedKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));

/**
 * Date in GMT timezone
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.GMTDate)
 *
 * @property seconds: seconds from 0 to 60(last is for leap second)
 * @property minutes: minutes from 0 to 59
 * @property hours: hours from 0 to 23
 * @property dayOfWeek an instance of the corresponding day of week
 * @property dayOfMonth: day of month from 1 to 31
 * @property dayOfYear: day of year from 1 to 366
 * @property month an instance of the corresponding month
 * @property year: year in common era(CE: https://en.wikipedia.org/wiki/Common_Era)
 *
 * @property timestamp is a number of epoch milliseconds
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Date in GMT timezone
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.GMTDate)
 *
 * @property seconds: seconds from 0 to 60(last is for leap second)
 * @property minutes: minutes from 0 to 59
 * @property hours: hours from 0 to 23
 * @property dayOfWeek an instance of the corresponding day of week
 * @property dayOfMonth: day of month from 1 to 31
 * @property dayOfYear: day of year from 1 to 366
 * @property month an instance of the corresponding month
 * @property year: year in common era(CE: https://en.wikipedia.org/wiki/Common_Era)
 *
 * @property timestamp is a number of epoch milliseconds
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Date in GMT timezone
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.GMTDate)
 *
 * @property seconds: seconds from 0 to 60(last is for leap second)
 * @property minutes: minutes from 0 to 59
 * @property hours: hours from 0 to 23
 * @property dayOfWeek an instance of the corresponding day of week
 * @property dayOfMonth: day of month from 1 to 31
 * @property dayOfYear: day of year from 1 to 366
 * @property month an instance of the corresponding month
 * @property year: year in common era(CE: https://en.wikipedia.org/wiki/Common_Era)
 *
 * @property timestamp is a number of epoch milliseconds
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) TruoraSharedKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) TruoraSharedKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end


/**
 * Represents an HTTP status code and description.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpStatusCode)
 *
 * @param value is a numeric code.
 * @param description is free form description of a status.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface TruoraSharedKtor_httpHttpStatusCode : TruoraSharedBase <TruoraSharedKotlinComparable>
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKtor_httpHttpStatusCodeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(TruoraSharedKtor_httpHttpStatusCode *)other __attribute__((swift_name("compareTo(other:)")));
- (TruoraSharedKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));

/**
 * Returns a copy of `this` code with a description changed to [value].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpStatusCode.description)
 */
- (TruoraSharedKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end


/**
 * Represents an HTTP protocol version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion)
 *
 * @property name specifies name of the protocol, e.g. "HTTP".
 * @property major specifies protocol major version.
 * @property minor specifies protocol minor version.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface TruoraSharedKtor_httpHttpProtocolVersion : TruoraSharedBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKtor_httpHttpProtocolVersionCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));

/**
 * Represents an HTTP protocol version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion)
 *
 * @property name specifies name of the protocol, e.g. "HTTP".
 * @property major specifies protocol major version.
 * @property minor specifies protocol minor version.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Represents an HTTP protocol version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion)
 *
 * @property name specifies name of the protocol, e.g. "HTTP".
 * @property major specifies protocol major version.
 * @property minor specifies protocol minor version.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end


/**
 * Serves as the base interface for an [HttpClient]'s engine.
 *
 * An `HttpClientEngine` represents the underlying network implementation that
 * performs HTTP requests and handles responses.
 * Developers can implement this interface to create custom engines for use with [HttpClient].
 *
 * This interface provides a set of properties and methods that define the
 * contract for configuring, executing, and managing HTTP requests within the engine.
 *
 * For a base implementation that handles common engine functionality, see [HttpClientEngineBase].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine)
 */
__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol TruoraSharedKtor_client_coreHttpClientEngine <TruoraSharedKotlinx_coroutines_coreCoroutineScope, TruoraSharedKtor_ioCloseable>
@required

/**
 * Executes an HTTP request and produces an HTTP response.
 *
 * This function takes [HttpRequestData], which contains all details of the HTTP request,
 * and returns [HttpResponseData] with the server's response, including headers, status code, and body.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine.execute)
 *
 * @param data The [HttpRequestData] representing the request to be executed.
 * @return An [HttpResponseData] object containing the server's response.
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeData:(TruoraSharedKtor_client_coreHttpRequestData *)data completionHandler:(void (^)(TruoraSharedKtor_client_coreHttpResponseData * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(data:completionHandler:)")));

/**
 * Installs the engine into an [HttpClient].
 *
 * This method is called when the engine is being set up within an `HttpClient`.
 * Use it to register interceptors, validate configuration, or prepare the engine
 * for use with the client.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine.install)
 *
 * @param client The [HttpClient] instance to which the engine is being installed.
 */
- (void)installClient:(TruoraSharedKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));

/**
 * Provides access to the engine's configuration via [HttpClientEngineConfig].
 *
 * The [config] object stores user-defined parameters or settings that control
 * how the engine operates. When creating a custom engine, this property
 * should return the specific configuration implementation.
 *
 * Example:
 * ```kotlin
 * override val config: HttpClientEngineConfig = CustomEngineConfig()
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine.config)
 */
@property (readonly) TruoraSharedKtor_client_coreHttpClientEngineConfig *config_ __attribute__((swift_name("config_")));

/**
 * Specifies the [CoroutineDispatcher] for I/O operations in the engine.
 *
 * This dispatcher is used for all network-related operations, such as
 * sending requests and receiving responses.
 * By default, it should be optimized for I/O tasks.
 *
 * Example:
 * ```kotlin
 * override val dispatcher: CoroutineDispatcher = Dispatchers.IO
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine.dispatcher)
 */
@property (readonly) TruoraSharedKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));

/**
 * Specifies the set of capabilities supported by this HTTP client engine.
 *
 * Capabilities provide a mechanism for plugins and other components to
 * determine whether the engine supports specific features such as timeouts,
 * WebSocket communication, HTTP/2, HTTP/3, or other advanced networking
 * capabilities. This allows seamless integration of features based on the
 * engine's functionality.
 *
 * Each capability is represented as an instance of [HttpClientEngineCapability],
 * which can carry additional metadata or configurations for the capability.
 *
 * Example:
 * ```kotlin
 * override val supportedCapabilities: Set<HttpClientEngineCapability<*>> = setOf(
 *     WebSocketCapability,
 *     Http2Capability,
 *     TimeoutCapability
 * )
 * ```
 *
 * **Usage in Plugins**:
 * Plugins can check if the engine supports a specific capability before
 * applying behavior:
 * ```kotlin
 * if (engine.supportedCapabilities.contains(WebSocketCapability)) {
 *     // Configure WebSocket-specific settings
 * }
 * ```
 *
 * When implementing a custom engine, ensure this property accurately reflects
 * the engine's abilities to avoid unexpected plugin behavior or runtime errors.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngine.supportedCapabilities)
 */
@property (readonly) NSSet<id<TruoraSharedKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end


/**
 * Base configuration for [HttpClientEngine].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig)
 */
__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface TruoraSharedKtor_client_coreHttpClientEngineConfig : TruoraSharedBase

/**
 * Base configuration for [HttpClientEngine].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig)
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Base configuration for [HttpClientEngine].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig)
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * Allow specifying the coroutine dispatcher to use for IO operations.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig.dispatcher)
 */
@property TruoraSharedKotlinx_coroutines_coreCoroutineDispatcher * _Nullable dispatcher __attribute__((swift_name("dispatcher")));

/**
 * Enables HTTP pipelining advice.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig.pipelining)
 */
@property BOOL pipelining __attribute__((swift_name("pipelining")));

/**
 * Specifies a proxy address to use.
 * Uses a system proxy by default.
 *
 * You can learn more from [Proxy](https://ktor.io/docs/proxy.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig.proxy)
 */
@property TruoraSharedKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));

/**
 * Specifies network threads count advice.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineConfig.threadsCount)
 */
@property int32_t threadsCount __attribute__((swift_name("threadsCount"))) __attribute__((unavailable("The [threadsCount] property is deprecated. Consider setting [dispatcher] instead.")));
@end


/**
 * A mutable [HttpClient] configuration used to adjust settings, install plugins and interceptors.
 *
 * This configuration can be provided as a lambda in the [HttpClient] constructor or the [HttpClient.config] builder:
 * ```kotlin
 * val client = HttpClient { // HttpClientConfig<Engine>()
 *     // Configure engine settings
 *     engine { // HttpClientEngineConfig
 *         threadsCount = 4
 *         pipelining = true
 *     }
 *
 *     // Install and configure plugins
 *     install(ContentNegotiation) {
 *         json()
 *     }
 *
 *     // Configure default request parameters
 *     defaultRequest {
 *         url("https://api.example.com")
 *         header("X-Custom-Header", "value")
 *     }
 *
 *     // Configure client-wide settings
 *     expectSuccess = true
 *     followRedirects = true
 * }
 * ```
 * ## Configuring [HttpClientEngine]
 *
 * If the engine is specified explicitly, engine-specific properties will be available in the `engine` block:
 * ```kotlin
 * val client = HttpClient(CIO) { // HttpClientConfig<CIOEngineConfig>.() -> Unit
 *     engine { // CIOEngineConfig.() -> Unit
 *         // engine specific properties
 *     }
 * }
 * ```
 *
 * Learn more about the client's configuration from
 * [Creating and configuring a client](https://ktor.io/docs/create-client.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface TruoraSharedKtor_client_coreHttpClientConfig<T> : TruoraSharedBase

/**
 * A mutable [HttpClient] configuration used to adjust settings, install plugins and interceptors.
 *
 * This configuration can be provided as a lambda in the [HttpClient] constructor or the [HttpClient.config] builder:
 * ```kotlin
 * val client = HttpClient { // HttpClientConfig<Engine>()
 *     // Configure engine settings
 *     engine { // HttpClientEngineConfig
 *         threadsCount = 4
 *         pipelining = true
 *     }
 *
 *     // Install and configure plugins
 *     install(ContentNegotiation) {
 *         json()
 *     }
 *
 *     // Configure default request parameters
 *     defaultRequest {
 *         url("https://api.example.com")
 *         header("X-Custom-Header", "value")
 *     }
 *
 *     // Configure client-wide settings
 *     expectSuccess = true
 *     followRedirects = true
 * }
 * ```
 * ## Configuring [HttpClientEngine]
 *
 * If the engine is specified explicitly, engine-specific properties will be available in the `engine` block:
 * ```kotlin
 * val client = HttpClient(CIO) { // HttpClientConfig<CIOEngineConfig>.() -> Unit
 *     engine { // CIOEngineConfig.() -> Unit
 *         // engine specific properties
 *     }
 * }
 * ```
 *
 * Learn more about the client's configuration from
 * [Creating and configuring a client](https://ktor.io/docs/create-client.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig)
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * A mutable [HttpClient] configuration used to adjust settings, install plugins and interceptors.
 *
 * This configuration can be provided as a lambda in the [HttpClient] constructor or the [HttpClient.config] builder:
 * ```kotlin
 * val client = HttpClient { // HttpClientConfig<Engine>()
 *     // Configure engine settings
 *     engine { // HttpClientEngineConfig
 *         threadsCount = 4
 *         pipelining = true
 *     }
 *
 *     // Install and configure plugins
 *     install(ContentNegotiation) {
 *         json()
 *     }
 *
 *     // Configure default request parameters
 *     defaultRequest {
 *         url("https://api.example.com")
 *         header("X-Custom-Header", "value")
 *     }
 *
 *     // Configure client-wide settings
 *     expectSuccess = true
 *     followRedirects = true
 * }
 * ```
 * ## Configuring [HttpClientEngine]
 *
 * If the engine is specified explicitly, engine-specific properties will be available in the `engine` block:
 * ```kotlin
 * val client = HttpClient(CIO) { // HttpClientConfig<CIOEngineConfig>.() -> Unit
 *     engine { // CIOEngineConfig.() -> Unit
 *         // engine specific properties
 *     }
 * }
 * ```
 *
 * Learn more about the client's configuration from
 * [Creating and configuring a client](https://ktor.io/docs/create-client.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig)
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * Clones this [HttpClientConfig] by duplicating all the [plugins] and [customInterceptors].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.clone)
 */
- (TruoraSharedKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));

/**
 * A builder for configuring engine-specific settings in [HttpClientEngineConfig],
 * such as dispatcher, thread count, proxy, and more.
 *
 * ```kotlin
 * val client = HttpClient(CIO) { // HttpClientConfig<CIOEngineConfig>
 *     engine { // CIOEngineConfig.() -> Unit
 *         proxy = ProxyBuilder.http("proxy.example.com", 8080)
 *     }
 * ```
 *
 * You can learn more from [Engines](https://ktor.io/docs/http-client-engines.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.engine)
 */
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));

/**
 * Applies all the installed [plugins] and [customInterceptors] from this configuration
 * into the specified [client].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.install)
 */
- (void)installClient:(TruoraSharedKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));

/**
 * Installs the specified [plugin] and optionally configures it using the [configure] block.
 *
 * ```kotlin
 * val client = HttpClient {
 *     install(ContentNegotiation) {
 *         // configuration block
 *         json()
 *     }
 * }
 * ```
 *
 * If the plugin is already installed, the configuration block will be applied to the existing configuration class.
 *
 * Learn more from [Plugins](https://ktor.io/docs/http-client-plugins.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.install)
 */
- (void)installPlugin:(id<TruoraSharedKtor_client_coreHttpClientPlugin>)plugin configure:(void (^)(id))configure __attribute__((swift_name("install(plugin:configure:)")));

/**
 * Installs an interceptor defined by [block].
 * The [key] parameter is used as a unique name, that also prevents installing duplicated interceptors.
 *
 * If the [key] is already used, the new interceptor will replace the old one.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.install)
 */
- (void)installKey:(NSString *)key block:(void (^)(TruoraSharedKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));

/**
 * Installs the plugin from the [other] client's configuration.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.plusAssign)
 */
- (void)plusAssignOther:(TruoraSharedKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));

/**
 * Development mode is no longer required all functionality is enabled by default. The property is safe to remove.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.developmentMode)
 */
@property BOOL developmentMode __attribute__((swift_name("developmentMode"))) __attribute__((deprecated("Development mode is no longer required. The property will be removed in the future.")));

/**
 * Terminates [HttpClient.receivePipeline] if the status code is not successful (>=300).
 * Learn more from [Response validation](https://ktor.io/docs/response-validation.html).
 *
 * For more details, see the [HttpCallValidator] documentation.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.expectSuccess)
 */
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));

/**
 * Specifies whether the client redirects to URLs provided in the `Location` header.
 * You can disable redirections by setting this property to `false`.
 *
 * For an advanced redirection configuration, use the [HttpRedirect] plugin.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.followRedirects)
 */
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));

/**
 * Enables body transformations for many common types like [String], [ByteArray], [ByteReadChannel], etc.
 * These transformations are applied to the request and response bodies.
 *
 * The transformers will be used when the response body is received with a type:
 * ```kotlin
 * val client = HttpClient()
 * val bytes = client.get("https://ktor.io")
 *                   .body<ByteArray>()
 * ```
 *
 * This flag is enabled by default.
 * You might want to disable it if you want to write your own transformers or handle body manually.
 *
 * For more details, see the [defaultTransformers] documentation.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.HttpClientConfig.useDefaultTransformers)
 */
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end


/**
 * Represents a capability that an [HttpClientEngine] can support, with [T] representing the type
 * of configuration or metadata associated with the capability.
 *
 * Capabilities are used to declare optional features or behaviors that an engine may support,
 * such as WebSocket communication, HTTP/2, or custom timeouts. They enable plugins and request
 * builders to configure engine-specific functionality by associating a capability with a
 * specific configuration.
 *
 * Capabilities can be set on a per-request basis using the `HttpRequestBuilder.setCapability` method,
 * allowing users to configure engine-specific behavior for individual requests.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.HttpClientEngineCapability)
 *
 * @param T The type of the configuration or metadata associated with this capability.
 *
 * Example:
 * Suppose you have a custom capability for WebSocket support that requires a specific configuration:
 * ```kotlin
 * object WebSocketCapability : HttpClientEngineCapability<WebSocketConfig>
 *
 * data class WebSocketConfig(val maxFrameSize: Int, val pingIntervalMillis: Long)
 * ```
 *
 * Setting a capability in a request:
 * ```kotlin
 * client.request {
 *     setCapability(WebSocketCapability, WebSocketConfig(
 *         maxFrameSize = 65536,
 *         pingIntervalMillis = 30000
 *     ))
 * }
 * ```
 *
 * Engine Example:
 * A custom engine implementation can declare support for specific capabilities in its `supportedCapabilities` property:
 * ```kotlin
 * override val supportedCapabilities: Set<HttpClientEngineCapability<*>> = setOf(WebSocketCapability)
 * ```
 *
 * Plugin Integration Example:
 * Plugins use capabilities to interact with engine-specific features. For example:
 * ```kotlin
 * if (engine.supportedCapabilities.contains(WebSocketCapability)) {
 *     // Configure WebSocket behavior if supported by the engine
 * }
 * ```
 *
 * When creating a custom capability:
 * - Define a singleton object implementing `HttpClientEngineCapability`.
 * - Use the type parameter [T] to provide the associated configuration type or metadata.
 * - Ensure that engines supporting the capability handle the associated configuration properly.
 */
__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol TruoraSharedKtor_client_coreHttpClientEngineCapability
@required
@end


/**
 * Map of attributes accessible by [AttributeKey] in a typed manner
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes)
 */
__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol TruoraSharedKtor_utilsAttributes
@required

/**
 * Gets a value of the attribute for the specified [key], or calls supplied [block] to compute its value
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.computeIfAbsent)
 */
- (id)computeIfAbsentKey:(TruoraSharedKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));

/**
 * Checks if an attribute with the specified [key] exists
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.contains)
 */
- (BOOL)containsKey:(TruoraSharedKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));

/**
 * Gets a value of the attribute for the specified [key], or throws an exception if an attribute doesn't exist
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.get)
 */
- (id)getKey_:(TruoraSharedKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key_:)")));

/**
 * Gets a value of the attribute for the specified [key], or return `null` if an attribute doesn't exist
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.getOrNull)
 */
- (id _Nullable)getOrNullKey:(TruoraSharedKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));

/**
 * Creates or changes an attribute with the specified [key] using [value]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.put)
 */
- (void)putKey:(TruoraSharedKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));

/**
 * Removes an attribute with the specified [key]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.remove)
 */
- (void)removeKey:(TruoraSharedKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));

/**
 * Creates or changes an attribute with the specified [key] using [value]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.set)
 */
- (void)setKey:(TruoraSharedKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("set(key:value:)")));

/**
 * Removes an attribute with the specified [key] and returns its current value, throws an exception if an attribute doesn't exist
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.take)
 */
- (id)takeKey:(TruoraSharedKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));

/**
 * Removes an attribute with the specified [key] and returns its current value, returns `null` if an attribute doesn't exist
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.takeOrNull)
 */
- (id _Nullable)takeOrNullKey:(TruoraSharedKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));

/**
 * Returns [List] of all [AttributeKey] instances in this map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.Attributes.allKeys)
 */
@property (readonly) NSArray<TruoraSharedKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_eventsEvents")))
@interface TruoraSharedKtor_eventsEvents : TruoraSharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * Raises the event specified by [definition] with the [value] and calls all handlers.
 *
 * Handlers are called in order of subscriptions.
 * If some handler throws an exception, all remaining handlers will still run. The exception will eventually be re-thrown.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.Events.raise)
 */
- (void)raiseDefinition:(TruoraSharedKtor_eventsEventDefinition<id> *)definition value:(id _Nullable)value __attribute__((swift_name("raise(definition:value:)")));

/**
 * Subscribe [handler] to an event specified by [definition]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.Events.subscribe)
 */
- (id<TruoraSharedKotlinx_coroutines_coreDisposableHandle>)subscribeDefinition:(TruoraSharedKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("subscribe(definition:handler:)")));

/**
 * Unsubscribe [handler] from an event specified by [definition]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.Events.unsubscribe)
 */
- (void)unsubscribeDefinition:(TruoraSharedKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("unsubscribe(definition:handler:)")));
@end


/**
 * Represents an execution pipeline for asynchronous extensible computations
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline)
 */
__attribute__((swift_name("Ktor_utilsPipeline")))
@interface TruoraSharedKtor_utilsPipeline<TSubject, TContext> : TruoraSharedBase
- (instancetype)initWithPhases:(TruoraSharedKotlinArray<TruoraSharedKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(TruoraSharedKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<TruoraSharedKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));

/**
 * Adds [phase] to the end of this pipeline
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.addPhase)
 */
- (void)addPhasePhase:(TruoraSharedKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));

/**
 * Invoked after an interceptor has been installed
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.afterIntercepted)
 */
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));

/**
 * Executes this pipeline in the given [context] and with the given [subject]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.execute)
 *
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeContext:(TContext)context subject:(TSubject)subject completionHandler:(void (^)(TSubject _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(context:subject:completionHandler:)")));

/**
 * Inserts [phase] after the [reference] phase. If there are other phases inserted after [reference], then [phase]
 * will be inserted after them.
 * Example:
 * ```
 * val pipeline = Pipeline<String, String>(a)
 * pipeline.insertPhaseAfter(a, b)
 * pipeline.insertPhaseAfter(a, c)
 * assertEquals(listOf(a, b, c), pipeline.items)
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.insertPhaseAfter)
 */
- (void)insertPhaseAfterReference:(TruoraSharedKtor_utilsPipelinePhase *)reference phase:(TruoraSharedKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));

/**
 * Inserts [phase] before the [reference] phase.
 * Example:
 * ```
 * val pipeline = Pipeline<String, String>(c)
 * pipeline.insertPhaseBefore(c, a)
 * pipeline.insertPhaseBefore(c, b)
 * assertEquals(listOf(a, b, c), pipeline.items)
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.insertPhaseBefore)
 */
- (void)insertPhaseBeforeReference:(TruoraSharedKtor_utilsPipelinePhase *)reference phase:(TruoraSharedKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));

/**
 * Adds [block] to the [phase] of this pipeline
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.intercept)
 */
- (void)interceptPhase:(TruoraSharedKtor_utilsPipelinePhase *)phase block:(id<TruoraSharedKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (NSArray<id<TruoraSharedKotlinSuspendFunction2>> *)interceptorsForPhasePhase:(TruoraSharedKtor_utilsPipelinePhase *)phase __attribute__((swift_name("interceptorsForPhase(phase:)")));

/**
 * Merges another pipeline into this pipeline, maintaining relative phases order
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.merge)
 */
- (void)mergeFrom:(TruoraSharedKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
- (void)mergePhasesFrom:(TruoraSharedKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("mergePhases(from:)")));

/**
 * Reset current pipeline from other.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.resetFrom)
 */
- (void)resetFromFrom:(TruoraSharedKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("resetFrom(from:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * Provides common place to store pipeline attributes
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.attributes)
 */
@property (readonly) id<TruoraSharedKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));

/**
 * Indicated if debug mode is enabled. In debug mode users will get more details in the stacktrace.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.developmentMode)
 */
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));

/**
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.isEmpty)
 *
 * @return `true` if there are no interceptors installed regardless number of phases
 */
@property (readonly, getter=isEmpty_) BOOL isEmpty __attribute__((swift_name("isEmpty")));

/**
 * Phases of this pipeline
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.Pipeline.items)
 */
@property (readonly) NSArray<TruoraSharedKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end


/**
 * [HttpClient] Pipeline used for receiving [HttpResponse] without any processing.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpReceivePipeline)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface TruoraSharedKtor_client_coreHttpReceivePipeline : TruoraSharedKtor_utilsPipeline<TruoraSharedKtor_client_coreHttpResponse *, TruoraSharedKotlinUnit *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(TruoraSharedKotlinArray<TruoraSharedKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(TruoraSharedKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<TruoraSharedKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedKtor_client_coreHttpReceivePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end


/**
 * An [HttpClient]'s pipeline used for executing [HttpRequest].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface TruoraSharedKtor_client_coreHttpRequestPipeline : TruoraSharedKtor_utilsPipeline<id, TruoraSharedKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(TruoraSharedKotlinArray<TruoraSharedKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(TruoraSharedKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<TruoraSharedKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedKtor_client_coreHttpRequestPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end


/**
 * [HttpClient] Pipeline used for executing [HttpResponse].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface TruoraSharedKtor_client_coreHttpResponsePipeline : TruoraSharedKtor_utilsPipeline<TruoraSharedKtor_client_coreHttpResponseContainer *, TruoraSharedKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(TruoraSharedKotlinArray<TruoraSharedKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(TruoraSharedKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<TruoraSharedKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedKtor_client_coreHttpResponsePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end


/**
 * An [HttpClient]'s pipeline used for sending [HttpRequest] to a remote server.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface TruoraSharedKtor_client_coreHttpSendPipeline : TruoraSharedKtor_utilsPipeline<id, TruoraSharedKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(TruoraSharedKotlinArray<TruoraSharedKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(TruoraSharedKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<TruoraSharedKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedKtor_client_coreHttpSendPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol TruoraSharedKotlinx_serialization_coreEncoder
@required
- (id<TruoraSharedKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<TruoraSharedKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<TruoraSharedKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<TruoraSharedKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<TruoraSharedKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) TruoraSharedKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol TruoraSharedKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<TruoraSharedKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<TruoraSharedKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) TruoraSharedKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol TruoraSharedKotlinx_serialization_coreDecoder
@required
- (id<TruoraSharedKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<TruoraSharedKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (TruoraSharedKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<TruoraSharedKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<TruoraSharedKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) TruoraSharedKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface TruoraSharedKotlinx_serialization_jsonJsonElementCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Represents a single value parameter
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HeaderValueParam)
 *
 * @property name of parameter
 * @property value of parameter
 * @property escapeValue specifies if the value should be escaped
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface TruoraSharedKtor_httpHeaderValueParam : TruoraSharedBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("init(name:value:escapeValue:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("doCopy(name:value:escapeValue:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Represents a single value parameter
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HeaderValueParam)
 *
 * @property name of parameter
 * @property value of parameter
 * @property escapeValue specifies if the value should be escaped
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL escapeValue __attribute__((swift_name("escapeValue")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters.Companion")))
@interface TruoraSharedKtor_httpHeaderValueWithParametersCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_httpHeaderValueWithParametersCompanion *shared __attribute__((swift_name("shared")));

/**
 * Parse header with parameter and pass it to [init] function to instantiate particular type
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HeaderValueWithParameters.Companion.parse)
 */
- (id _Nullable)parseValue:(NSString *)value init:(id _Nullable (^)(NSString *, NSArray<TruoraSharedKtor_httpHeaderValueParam *> *))init __attribute__((swift_name("parse(value:init:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType.Companion")))
@interface TruoraSharedKtor_httpContentTypeCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_httpContentTypeCompanion *shared __attribute__((swift_name("shared")));

/**
 * Parses a string representing a `Content-Type` header into a [ContentType] instance.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.Companion.parse)
 */
- (TruoraSharedKtor_httpContentType *)parseValue:(NSString *)value __attribute__((swift_name("parse(value:)")));

/**
 * Represents a pattern `* / *` to match any content type.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.ContentType.Companion.Any)
 */
@property (readonly) TruoraSharedKtor_httpContentType *Any __attribute__((swift_name("Any")));
@end

__attribute__((swift_name("UiModifierElement")))
@protocol TruoraSharedUiModifierElement <TruoraSharedUiModifier>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ui_graphicsBrush.Companion")))
@interface TruoraSharedUi_graphicsBrushCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedUi_graphicsBrushCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)compositeDstBrush:(TruoraSharedUi_graphicsBrush *)dstBrush srcBrush:(TruoraSharedUi_graphicsBrush *)srcBrush blendMode:(int32_t)blendMode __attribute__((swift_name("composite(dstBrush:srcBrush:blendMode:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)horizontalGradientColorStops:(TruoraSharedKotlinArray<TruoraSharedKotlinPair<TruoraSharedFloat *, id> *> *)colorStops startX:(float)startX endX:(float)endX tileMode:(int32_t)tileMode __attribute__((swift_name("horizontalGradient(colorStops:startX:endX:tileMode:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)horizontalGradientColors:(NSArray<id> *)colors startX:(float)startX endX:(float)endX tileMode:(int32_t)tileMode __attribute__((swift_name("horizontalGradient(colors:startX:endX:tileMode:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)linearGradientColorStops:(TruoraSharedKotlinArray<TruoraSharedKotlinPair<TruoraSharedFloat *, id> *> *)colorStops start:(int64_t)start end:(int64_t)end tileMode:(int32_t)tileMode __attribute__((swift_name("linearGradient(colorStops:start:end:tileMode:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)linearGradientColors:(NSArray<id> *)colors start:(int64_t)start end:(int64_t)end tileMode:(int32_t)tileMode __attribute__((swift_name("linearGradient(colors:start:end:tileMode:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)radialGradientColorStops:(TruoraSharedKotlinArray<TruoraSharedKotlinPair<TruoraSharedFloat *, id> *> *)colorStops center:(int64_t)center radius:(float)radius tileMode:(int32_t)tileMode __attribute__((swift_name("radialGradient(colorStops:center:radius:tileMode:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)radialGradientColors:(NSArray<id> *)colors center:(int64_t)center radius:(float)radius tileMode:(int32_t)tileMode __attribute__((swift_name("radialGradient(colors:center:radius:tileMode:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)sweepGradientColorStops:(TruoraSharedKotlinArray<TruoraSharedKotlinPair<TruoraSharedFloat *, id> *> *)colorStops center:(int64_t)center __attribute__((swift_name("sweepGradient(colorStops:center:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)sweepGradientColors:(NSArray<id> *)colors center:(int64_t)center __attribute__((swift_name("sweepGradient(colors:center:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)verticalGradientColorStops:(TruoraSharedKotlinArray<TruoraSharedKotlinPair<TruoraSharedFloat *, id> *> *)colorStops startY:(float)startY endY:(float)endY tileMode:(int32_t)tileMode __attribute__((swift_name("verticalGradient(colorStops:startY:endY:tileMode:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsBrush *)verticalGradientColors:(NSArray<id> *)colors startY:(float)startY endY:(float)endY tileMode:(int32_t)tileMode __attribute__((swift_name("verticalGradient(colors:startY:endY:tileMode:)")));
@end

__attribute__((swift_name("Ui_graphicsPaint")))
@protocol TruoraSharedUi_graphicsPaint
@required
- (TruoraSharedSkikoPaint *)asFrameworkPaint __attribute__((swift_name("asFrameworkPaint()")));
@property float alpha __attribute__((swift_name("alpha")));
@property int32_t blendMode __attribute__((swift_name("blendMode")));
@property uint64_t color __attribute__((swift_name("color")));
@property TruoraSharedUi_graphicsColorFilter * _Nullable colorFilter __attribute__((swift_name("colorFilter")));
@property int32_t filterQuality __attribute__((swift_name("filterQuality")));
@property BOOL isAntiAlias __attribute__((swift_name("isAntiAlias")));
@property id<TruoraSharedUi_graphicsPathEffect> _Nullable pathEffect __attribute__((swift_name("pathEffect")));
@property TruoraSharedSkikoShader * _Nullable shader __attribute__((swift_name("shader")));
@property int32_t strokeCap __attribute__((swift_name("strokeCap")));
@property int32_t strokeJoin __attribute__((swift_name("strokeJoin")));
@property float strokeMiterLimit __attribute__((swift_name("strokeMiterLimit")));
@property float strokeWidth __attribute__((swift_name("strokeWidth")));
@property int32_t style __attribute__((swift_name("style")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RuntimeProvidedValue")))
@interface TruoraSharedRuntimeProvidedValue<T> : TruoraSharedBase
@property (readonly) BOOL canOverride __attribute__((swift_name("canOverride")));
@property (readonly) TruoraSharedRuntimeCompositionLocal<T> *compositionLocal __attribute__((swift_name("compositionLocal")));
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("RuntimeCompositionLocalAccessorScope")))
@protocol TruoraSharedRuntimeCompositionLocalAccessorScope
@required
- (id _Nullable)currentValue:(TruoraSharedRuntimeCompositionLocal<id> *)receiver __attribute__((swift_name("currentValue(_:)")));
@end

__attribute__((swift_name("KotlinIntIterator")))
@interface TruoraSharedKotlinIntIterator : TruoraSharedBase <TruoraSharedKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (TruoraSharedInt *)next __attribute__((swift_name("next()")));
- (int32_t)nextInt __attribute__((swift_name("nextInt()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinFloatArray")))
@interface TruoraSharedKotlinFloatArray : TruoraSharedBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(TruoraSharedFloat *(^)(TruoraSharedInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (float)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (TruoraSharedKotlinFloatIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(float)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("LibraryQualifier")))
@protocol TruoraSharedLibraryQualifier
@required
@end

__attribute__((swift_name("KotlinMapEntry")))
@protocol TruoraSharedKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol TruoraSharedKotlinCoroutineContextElement <TruoraSharedKotlinCoroutineContext>
@required
@property (readonly) id<TruoraSharedKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol TruoraSharedKotlinCoroutineContextKey
@required
@end


/**
 * Actual data of the [HttpRequest], including [url], [method], [headers], [body] and [executionContext].
 * Built by [HttpRequestBuilder].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestData)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface TruoraSharedKtor_client_coreHttpRequestData : TruoraSharedBase
- (instancetype)initWithUrl:(TruoraSharedKtor_httpUrl *)url method:(TruoraSharedKtor_httpHttpMethod *)method headers:(id<TruoraSharedKtor_httpHeaders>)headers body:(TruoraSharedKtor_httpOutgoingContent *)body executionContext:(id<TruoraSharedKotlinx_coroutines_coreJob>)executionContext attributes:(id<TruoraSharedKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));

/**
 * Retrieve extension by its key.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestData.getCapabilityOrNull)
 */
- (id _Nullable)getCapabilityOrNullKey:(id<TruoraSharedKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<TruoraSharedKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) TruoraSharedKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<TruoraSharedKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<TruoraSharedKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) TruoraSharedKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) TruoraSharedKtor_httpUrl *url __attribute__((swift_name("url")));
@end


/**
 * Data prepared for [HttpResponse].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpResponseData)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseData")))
@interface TruoraSharedKtor_client_coreHttpResponseData : TruoraSharedBase
- (instancetype)initWithStatusCode:(TruoraSharedKtor_httpHttpStatusCode *)statusCode requestTime:(TruoraSharedKtor_utilsGMTDate *)requestTime headers:(id<TruoraSharedKtor_httpHeaders>)headers version:(TruoraSharedKtor_httpHttpProtocolVersion *)version body:(id)body callContext:(id<TruoraSharedKotlinCoroutineContext>)callContext __attribute__((swift_name("init(statusCode:requestTime:headers:version:body:callContext:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id body __attribute__((swift_name("body")));
@property (readonly) id<TruoraSharedKotlinCoroutineContext> callContext __attribute__((swift_name("callContext")));
@property (readonly) id<TruoraSharedKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) TruoraSharedKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) TruoraSharedKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@property (readonly) TruoraSharedKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientCall.Companion")))
@interface TruoraSharedKtor_client_coreHttpClientCallCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_client_coreHttpClientCallCompanion *shared __attribute__((swift_name("shared")));
@end


/**
 * Ktor type information.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.reflect.TypeInfo)
 *
 * @property type Source KClass<*>
 * @property kotlinType Kotlin reified type with all generic type parameters.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsTypeInfo")))
@interface TruoraSharedKtor_utilsTypeInfo : TruoraSharedBase
- (instancetype)initWithType:(id<TruoraSharedKotlinKClass>)type kotlinType:(id<TruoraSharedKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithType:(id<TruoraSharedKotlinKClass>)type reifiedType:(id<TruoraSharedKotlinKType>)reifiedType kotlinType:(id<TruoraSharedKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use constructor without reifiedType parameter.")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<TruoraSharedKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<TruoraSharedKotlinKClass> type __attribute__((swift_name("type")));
@end


/**
 * A request for [HttpClient], first part of [HttpClientCall].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest)
 */
__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol TruoraSharedKtor_client_coreHttpRequest <TruoraSharedKtor_httpHttpMessage, TruoraSharedKotlinx_coroutines_coreCoroutineScope>
@required

/**
 * Typed [Attributes] associated to this call serving as a lightweight container.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest.attributes)
 */
@property (readonly) id<TruoraSharedKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));

/**
 * The associated [HttpClientCall] containing both
 * the underlying [HttpClientCall.request] and [HttpClientCall.response].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest.call)
 */
@property (readonly) TruoraSharedKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));

/**
 * An [OutgoingContent] representing the request body
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest.content)
 */
@property (readonly) TruoraSharedKtor_httpOutgoingContent *content __attribute__((swift_name("content")));

/**
 * The [HttpMethod] or HTTP VERB used for this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest.method)
 */
@property (readonly) TruoraSharedKtor_httpHttpMethod *method __attribute__((swift_name("method")));

/**
 * The [Url] representing the endpoint and the uri for this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequest.url)
 */
@property (readonly) TruoraSharedKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("Kotlinx_io_coreRawSource")))
@protocol TruoraSharedKotlinx_io_coreRawSource <TruoraSharedKotlinAutoCloseable>
@required
- (int64_t)readAtMostToSink:(TruoraSharedKotlinx_io_coreBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readAtMostTo(sink:byteCount:)")));
@end

__attribute__((swift_name("Kotlinx_io_coreSource")))
@protocol TruoraSharedKotlinx_io_coreSource <TruoraSharedKotlinx_io_coreRawSource>
@required
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (id<TruoraSharedKotlinx_io_coreSource>)peek __attribute__((swift_name("peek()")));
- (int32_t)readAtMostToSink:(TruoraSharedKotlinByteArray *)sink startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("readAtMostTo(sink:startIndex:endIndex:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (void)readToSink:(id<TruoraSharedKotlinx_io_coreRawSink>)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readTo(sink:byteCount:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (int64_t)transferToSink:(id<TruoraSharedKotlinx_io_coreRawSink>)sink __attribute__((swift_name("transferTo(sink:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) TruoraSharedKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@end


/**
 * Day of week
 * [value] is 3 letter shortcut
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.WeekDay)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface TruoraSharedKtor_utilsWeekDay : TruoraSharedKotlinEnum<TruoraSharedKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Day of week
 * [value] is 3 letter shortcut
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.WeekDay)
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedKtor_utilsWeekDayCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) TruoraSharedKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) TruoraSharedKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) TruoraSharedKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) TruoraSharedKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) TruoraSharedKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) TruoraSharedKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) TruoraSharedKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
+ (TruoraSharedKotlinArray<TruoraSharedKtor_utilsWeekDay *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedKtor_utilsWeekDay *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end


/**
 * Month
 * [value] is 3 letter shortcut
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.Month)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface TruoraSharedKtor_utilsMonth : TruoraSharedKotlinEnum<TruoraSharedKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));

/**
 * Month
 * [value] is 3 letter shortcut
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.Month)
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedKtor_utilsMonthCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) TruoraSharedKtor_utilsMonth *december __attribute__((swift_name("december")));
+ (TruoraSharedKotlinArray<TruoraSharedKtor_utilsMonth *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedKtor_utilsMonth *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate.Companion")))
@interface TruoraSharedKtor_utilsGMTDateCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_utilsGMTDateCompanion *shared __attribute__((swift_name("shared")));
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));

/**
 * An instance of [GMTDate] corresponding to the epoch beginning
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.GMTDate.Companion.START)
 */
@property (readonly) TruoraSharedKtor_utilsGMTDate *START __attribute__((swift_name("START")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode.Companion")))
@interface TruoraSharedKtor_httpHttpStatusCodeCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_httpHttpStatusCodeCompanion *shared __attribute__((swift_name("shared")));

/**
 * Creates an instance of [HttpStatusCode] with the given numeric value.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpStatusCode.Companion.fromValue)
 */
- (TruoraSharedKtor_httpHttpStatusCode *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *Accepted __attribute__((swift_name("Accepted")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *BadGateway __attribute__((swift_name("BadGateway")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *BadRequest __attribute__((swift_name("BadRequest")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *Conflict __attribute__((swift_name("Conflict")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *Continue __attribute__((swift_name("Continue")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *Created __attribute__((swift_name("Created")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *ExpectationFailed __attribute__((swift_name("ExpectationFailed")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *FailedDependency __attribute__((swift_name("FailedDependency")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *Forbidden __attribute__((swift_name("Forbidden")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *Found __attribute__((swift_name("Found")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *GatewayTimeout __attribute__((swift_name("GatewayTimeout")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *Gone __attribute__((swift_name("Gone")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *InsufficientStorage __attribute__((swift_name("InsufficientStorage")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *InternalServerError __attribute__((swift_name("InternalServerError")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *LengthRequired __attribute__((swift_name("LengthRequired")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *Locked __attribute__((swift_name("Locked")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *MethodNotAllowed __attribute__((swift_name("MethodNotAllowed")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *MovedPermanently __attribute__((swift_name("MovedPermanently")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *MultiStatus __attribute__((swift_name("MultiStatus")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *MultipleChoices __attribute__((swift_name("MultipleChoices")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *NoContent __attribute__((swift_name("NoContent")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *NonAuthoritativeInformation __attribute__((swift_name("NonAuthoritativeInformation")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *NotAcceptable __attribute__((swift_name("NotAcceptable")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *NotFound __attribute__((swift_name("NotFound")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *NotImplemented __attribute__((swift_name("NotImplemented")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *NotModified __attribute__((swift_name("NotModified")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *OK __attribute__((swift_name("OK")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *PartialContent __attribute__((swift_name("PartialContent")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *PayloadTooLarge __attribute__((swift_name("PayloadTooLarge")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *PaymentRequired __attribute__((swift_name("PaymentRequired")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *PermanentRedirect __attribute__((swift_name("PermanentRedirect")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *PreconditionFailed __attribute__((swift_name("PreconditionFailed")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *Processing __attribute__((swift_name("Processing")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *ProxyAuthenticationRequired __attribute__((swift_name("ProxyAuthenticationRequired")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *RequestHeaderFieldTooLarge __attribute__((swift_name("RequestHeaderFieldTooLarge")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *RequestTimeout __attribute__((swift_name("RequestTimeout")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *RequestURITooLong __attribute__((swift_name("RequestURITooLong")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *RequestedRangeNotSatisfiable __attribute__((swift_name("RequestedRangeNotSatisfiable")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *ResetContent __attribute__((swift_name("ResetContent")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *SeeOther __attribute__((swift_name("SeeOther")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *ServiceUnavailable __attribute__((swift_name("ServiceUnavailable")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *SwitchProxy __attribute__((swift_name("SwitchProxy")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *SwitchingProtocols __attribute__((swift_name("SwitchingProtocols")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *TemporaryRedirect __attribute__((swift_name("TemporaryRedirect")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *TooEarly __attribute__((swift_name("TooEarly")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *TooManyRequests __attribute__((swift_name("TooManyRequests")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *Unauthorized __attribute__((swift_name("Unauthorized")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *UnprocessableEntity __attribute__((swift_name("UnprocessableEntity")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *UnsupportedMediaType __attribute__((swift_name("UnsupportedMediaType")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *UpgradeRequired __attribute__((swift_name("UpgradeRequired")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *UseProxy __attribute__((swift_name("UseProxy")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *VariantAlsoNegotiates __attribute__((swift_name("VariantAlsoNegotiates")));
@property (readonly) TruoraSharedKtor_httpHttpStatusCode *VersionNotSupported __attribute__((swift_name("VersionNotSupported")));

/**
 * All known status codes
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpStatusCode.Companion.allStatusCodes)
 */
@property (readonly) NSArray<TruoraSharedKtor_httpHttpStatusCode *> *allStatusCodes __attribute__((swift_name("allStatusCodes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion.Companion")))
@interface TruoraSharedKtor_httpHttpProtocolVersionCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_httpHttpProtocolVersionCompanion *shared __attribute__((swift_name("shared")));

/**
 * Creates an instance of [HttpProtocolVersion] from the given parameters.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.fromValue)
 */
- (TruoraSharedKtor_httpHttpProtocolVersion *)fromValueName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("fromValue(name:major:minor:)")));

/**
 * Create an instance of [HttpProtocolVersion] from http string representation.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.parse)
 */
- (TruoraSharedKtor_httpHttpProtocolVersion *)parseValue:(id)value __attribute__((swift_name("parse(value:)")));

/**
 * HTTP/1.0 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.HTTP_1_0)
 */
@property (readonly) TruoraSharedKtor_httpHttpProtocolVersion *HTTP_1_0 __attribute__((swift_name("HTTP_1_0")));

/**
 * HTTP/1.1 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.HTTP_1_1)
 */
@property (readonly) TruoraSharedKtor_httpHttpProtocolVersion *HTTP_1_1 __attribute__((swift_name("HTTP_1_1")));

/**
 * HTTP/2.0 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.HTTP_2_0)
 */
@property (readonly) TruoraSharedKtor_httpHttpProtocolVersion *HTTP_2_0 __attribute__((swift_name("HTTP_2_0")));

/**
 * HTTP/3.0 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.HTTP_3_0)
 */
@property (readonly) TruoraSharedKtor_httpHttpProtocolVersion *HTTP_3_0 __attribute__((swift_name("HTTP_3_0")));

/**
 * QUIC/1.0 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.QUIC)
 */
@property (readonly) TruoraSharedKtor_httpHttpProtocolVersion *QUIC __attribute__((swift_name("QUIC")));

/**
 * SPDY/3.0 version.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpProtocolVersion.Companion.SPDY_3)
 */
@property (readonly) TruoraSharedKtor_httpHttpProtocolVersion *SPDY_3 __attribute__((swift_name("SPDY_3")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface TruoraSharedKotlinAbstractCoroutineContextElement : TruoraSharedBase <TruoraSharedKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<TruoraSharedKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<TruoraSharedKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol TruoraSharedKotlinContinuationInterceptor <TruoraSharedKotlinCoroutineContextElement>
@required
- (id<TruoraSharedKotlinContinuation>)interceptContinuationContinuation:(id<TruoraSharedKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<TruoraSharedKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface TruoraSharedKotlinx_coroutines_coreCoroutineDispatcher : TruoraSharedKotlinAbstractCoroutineContextElement <TruoraSharedKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<TruoraSharedKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<TruoraSharedKotlinCoroutineContext>)context block:(id<TruoraSharedKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)dispatchYieldContext:(id<TruoraSharedKotlinCoroutineContext>)context block:(id<TruoraSharedKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<TruoraSharedKotlinContinuation>)interceptContinuationContinuation:(id<TruoraSharedKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<TruoraSharedKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (TruoraSharedKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism name:(NSString * _Nullable)name __attribute__((swift_name("limitedParallelism(parallelism:name:)")));
- (TruoraSharedKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(TruoraSharedKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<TruoraSharedKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * Proxy configuration.
 *
 * See [ProxyBuilder] to create proxy.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.engine.ProxyConfig)
 *
 * @param url: proxy url address.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface TruoraSharedKtor_client_coreProxyConfig : TruoraSharedBase
- (instancetype)initWithUrl:(TruoraSharedKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedKtor_httpUrl *url __attribute__((swift_name("url")));
@end


/**
 * Base interface representing a [HttpClient] plugin.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.plugins.HttpClientPlugin)
 */
__attribute__((swift_name("Ktor_client_coreHttpClientPlugin")))
@protocol TruoraSharedKtor_client_coreHttpClientPlugin
@required

/**
 * Installs the [plugin] class for a [HttpClient] defined at [scope].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.plugins.HttpClientPlugin.install)
 */
- (void)installPlugin:(id)plugin scope:(TruoraSharedKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(plugin:scope:)")));

/**
 * Builds a [TPlugin] by calling the [block] with a [TConfig] config instance as receiver.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.plugins.HttpClientPlugin.prepare)
 */
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));

/**
 * The [AttributeKey] for this plugin.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.plugins.HttpClientPlugin.key)
 */
@property (readonly) TruoraSharedKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end


/**
 * Specifies a key for an attribute in [Attributes]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.AttributeKey)
 *
 * @param T is a type of the value stored in the attribute
 * @property name is a name of the attribute for diagnostic purposes. Can't be blank
 * @property type the recorded kotlin type of T
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface TruoraSharedKtor_utilsAttributeKey<T> : TruoraSharedBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString *)name type:(TruoraSharedKtor_utilsTypeInfo *)type __attribute__((swift_name("init(name:type:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedKtor_utilsAttributeKey<T> *)doCopyName:(NSString *)name type:(TruoraSharedKtor_utilsTypeInfo *)type __attribute__((swift_name("doCopy(name:type:)")));

/**
 * Specifies a key for an attribute in [Attributes]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.AttributeKey)
 *
 * @param T is a type of the value stored in the attribute
 * @property name is a name of the attribute for diagnostic purposes. Can't be blank
 * @property type the recorded kotlin type of T
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Specifies a key for an attribute in [Attributes]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.AttributeKey)
 *
 * @param T is a type of the value stored in the attribute
 * @property name is a name of the attribute for diagnostic purposes. Can't be blank
 * @property type the recorded kotlin type of T
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end


/**
 * Definition of an event.
 * Event is used as a key so both [hashCode] and [equals] need to be implemented properly.
 * Inheriting of this class is an experimental feature.
 * Instantiate directly if inheritance not necessary.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.EventDefinition)
 *
 * @param T specifies what is a type of value passed to the event
 */
__attribute__((swift_name("Ktor_eventsEventDefinition")))
@interface TruoraSharedKtor_eventsEventDefinition<T> : TruoraSharedBase

/**
 * Definition of an event.
 * Event is used as a key so both [hashCode] and [equals] need to be implemented properly.
 * Inheriting of this class is an experimental feature.
 * Instantiate directly if inheritance not necessary.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.EventDefinition)
 *
 * @param T specifies what is a type of value passed to the event
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Definition of an event.
 * Event is used as a key so both [hashCode] and [equals] need to be implemented properly.
 * Inheriting of this class is an experimental feature.
 * Instantiate directly if inheritance not necessary.
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.events.EventDefinition)
 *
 * @param T specifies what is a type of value passed to the event
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol TruoraSharedKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end


/**
 * Represents a phase in a pipeline
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.pipeline.PipelinePhase)
 *
 * @param name a name for this phase
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface TruoraSharedKtor_utilsPipelinePhase : TruoraSharedBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol TruoraSharedKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol TruoraSharedKotlinSuspendFunction2 <TruoraSharedKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline.Phases")))
@interface TruoraSharedKtor_client_coreHttpReceivePipelinePhases : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_client_coreHttpReceivePipelinePhases *shared __attribute__((swift_name("shared")));

/**
 * Latest response pipeline phase
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpReceivePipeline.Phases.After)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));

/**
 * The earliest phase that happens before any other
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpReceivePipeline.Phases.Before)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));

/**
 * Use this phase to store request shared state
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpReceivePipeline.Phases.State)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface TruoraSharedKotlinUnit : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end


/**
 * All interceptors accept payload as [subject] and try to convert it to [OutgoingContent].
 * Last phase should proceed with [HttpClientCall].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline.Phases")))
@interface TruoraSharedKtor_client_coreHttpRequestPipelinePhases : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));

/**
 * All interceptors accept payload as [subject] and try to convert it to [OutgoingContent].
 * Last phase should proceed with [HttpClientCall].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases)
 */
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_client_coreHttpRequestPipelinePhases *shared __attribute__((swift_name("shared")));

/**
 * The earliest phase that happens before any other.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases.Before)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));

/**
 * Encode a request body to [OutgoingContent].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases.Render)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Render __attribute__((swift_name("Render")));

/**
 * A phase for the [HttpSend] plugin.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases.Send)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Send __attribute__((swift_name("Send")));

/**
 * Use this phase to modify a request with a shared state.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases.State)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));

/**
 * Transform a request body to supported render format.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestPipeline.Phases.Transform)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end


/**
 * A builder message either for the client or the server,
 * that has a [headers] builder associated.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMessageBuilder)
 */
__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol TruoraSharedKtor_httpHttpMessageBuilder
@required

/**
 * MessageBuilder [HeadersBuilder]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMessageBuilder.headers)
 */
@property (readonly) TruoraSharedKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end


/**
 * Contains parameters used to make an HTTP request.
 *
 * Learn more from [Making requests](https://ktor.io/docs/request.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder)
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface TruoraSharedKtor_client_coreHttpRequestBuilder : TruoraSharedBase <TruoraSharedKtor_httpHttpMessageBuilder>

/**
 * Contains parameters used to make an HTTP request.
 *
 * Learn more from [Making requests](https://ktor.io/docs/request.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder)
 */
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));

/**
 * Contains parameters used to make an HTTP request.
 *
 * Learn more from [Making requests](https://ktor.io/docs/request.html).
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder)
 */
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) TruoraSharedKtor_client_coreHttpRequestBuilderCompanion *companion __attribute__((swift_name("companion")));

/**
 * Creates immutable [HttpRequestData].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.build)
 */
- (TruoraSharedKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));

/**
 * Retrieves capability by the key.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.getCapabilityOrNull)
 */
- (id _Nullable)getCapabilityOrNullKey:(id<TruoraSharedKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));

/**
 * Sets request-specific attributes specified by [block].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.setAttributes)
 */
- (void)setAttributesBlock:(void (^)(id<TruoraSharedKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));

/**
 * Sets capability configuration.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.setCapability)
 */
- (void)setCapabilityKey:(id<TruoraSharedKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));

/**
 * Mutates [this] by copying all the data but execution context from another [builder] using it as the base.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.takeFrom)
 */
- (TruoraSharedKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(TruoraSharedKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));

/**
 * Mutates [this] copying all the data from another [builder] using it as the base.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.takeFromWithExecutionContext)
 */
- (TruoraSharedKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(TruoraSharedKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));

/**
 * Executes a [block] that configures the [URLBuilder] associated to this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.url)
 */
- (void)urlBlock:(void (^)(TruoraSharedKtor_httpURLBuilder *, TruoraSharedKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));

/**
 * Provides access to attributes specific for this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.attributes)
 */
@property (readonly) id<TruoraSharedKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));

/**
 * The [body] for this request. Initially [EmptyContent].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.body)
 */
@property id body __attribute__((swift_name("body")));

/**
 * The [KType] of [body] for this request. Null for default types that don't need serialization.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.bodyType)
 */
@property TruoraSharedKtor_utilsTypeInfo * _Nullable bodyType __attribute__((swift_name("bodyType")));

/**
 * A deferred used to control the execution of this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.executionContext)
 */
@property (readonly) id<TruoraSharedKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));

/**
 * [HeadersBuilder] to configure the headers for this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.headers)
 */
@property (readonly) TruoraSharedKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));

/**
 * [HttpMethod] used by this request. [HttpMethod.Get] by default.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.method)
 */
@property TruoraSharedKtor_httpHttpMethod *method __attribute__((swift_name("method")));

/**
 * [URLBuilder] to configure the URL for this request.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpRequestBuilder.url)
 */
@property (readonly) TruoraSharedKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline.Phases")))
@interface TruoraSharedKtor_client_coreHttpResponsePipelinePhases : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_client_coreHttpResponsePipelinePhases *shared __attribute__((swift_name("shared")));

/**
 * Latest response pipeline phase
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline.Phases.After)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));

/**
 * Decode response body
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline.Phases.Parse)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Parse __attribute__((swift_name("Parse")));

/**
 * The earliest phase that happens before any other
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline.Phases.Receive)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));

/**
 * Use this phase to store request shared state
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline.Phases.State)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));

/**
 * Transform response body to expected format
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponsePipeline.Phases.Transform)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end


/**
 * Class representing a typed [response] with an attached [expectedType].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponseContainer)
 *
 * @param expectedType: information about expected type.
 * @param response: current response state.
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface TruoraSharedKtor_client_coreHttpResponseContainer : TruoraSharedBase
- (instancetype)initWithExpectedType:(TruoraSharedKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(TruoraSharedKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));

/**
 * Class representing a typed [response] with an attached [expectedType].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponseContainer)
 *
 * @param expectedType: information about expected type.
 * @param response: current response state.
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Class representing a typed [response] with an attached [expectedType].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponseContainer)
 *
 * @param expectedType: information about expected type.
 * @param response: current response state.
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Class representing a typed [response] with an attached [expectedType].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.statement.HttpResponseContainer)
 *
 * @param expectedType: information about expected type.
 * @param response: current response state.
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedKtor_utilsTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline.Phases")))
@interface TruoraSharedKtor_client_coreHttpSendPipelinePhases : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_client_coreHttpSendPipelinePhases *shared __attribute__((swift_name("shared")));

/**
 * The earliest phase that happens before any other.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline.Phases.Before)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));

/**
 * Send a request to a remote server.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline.Phases.Engine)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Engine __attribute__((swift_name("Engine")));

/**
 * Use this phase for logging and other actions that don't modify a request or shared data.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline.Phases.Monitoring)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Monitoring __attribute__((swift_name("Monitoring")));

/**
 * Receive a pipeline execution phase.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline.Phases.Receive)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));

/**
 * Use this phase to modify request with a shared state.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.client.request.HttpSendPipeline.Phases.State)
 */
@property (readonly) TruoraSharedKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol TruoraSharedKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<TruoraSharedKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<TruoraSharedKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<TruoraSharedKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) TruoraSharedKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface TruoraSharedKotlinx_serialization_coreSerializersModule : TruoraSharedBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<TruoraSharedKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<TruoraSharedKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<TruoraSharedKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<TruoraSharedKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<TruoraSharedKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<TruoraSharedKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<TruoraSharedKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<TruoraSharedKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol TruoraSharedKotlinAnnotation
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface TruoraSharedKotlinx_serialization_coreSerialKind : TruoraSharedBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol TruoraSharedKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<TruoraSharedKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<TruoraSharedKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<TruoraSharedKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<TruoraSharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) TruoraSharedKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface TruoraSharedKotlinNothing : TruoraSharedBase
@end

__attribute__((swift_name("SkikoNative")))
@interface TruoraSharedSkikoNative : TruoraSharedBase
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoNativeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("SkikoManaged")))
@interface TruoraSharedSkikoManaged : TruoraSharedSkikoNative
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)close __attribute__((swift_name("close()")));
@property (readonly) BOOL isClosed __attribute__((swift_name("isClosed")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPaint")))
@interface TruoraSharedSkikoPaint : TruoraSharedSkikoManaged
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoPaintCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)hasNothingToDraw __attribute__((swift_name("hasNothingToDraw()")));
- (TruoraSharedSkikoPaint *)makeClone __attribute__((swift_name("makeClone()")));
- (TruoraSharedSkikoPaint *)reset __attribute__((swift_name("reset()")));
- (TruoraSharedSkikoPaint *)setARGBA:(int32_t)a r:(int32_t)r g:(int32_t)g b:(int32_t)b __attribute__((swift_name("setARGB(a:r:g:b:)")));
- (TruoraSharedSkikoPaint *)setAlphafA:(float)a __attribute__((swift_name("setAlphaf(a:)")));
- (TruoraSharedSkikoPaint *)setColor4fColor:(TruoraSharedSkikoColor4f *)color colorSpace:(TruoraSharedSkikoColorSpace * _Nullable)colorSpace __attribute__((swift_name("setColor4f(color:colorSpace:)")));
- (TruoraSharedSkikoPaint *)setStrokeValue:(BOOL)value __attribute__((swift_name("setStroke(value:)")));
@property int32_t alpha __attribute__((swift_name("alpha")));
@property (readonly) float alphaf __attribute__((swift_name("alphaf")));
@property TruoraSharedSkikoBlendMode *blendMode __attribute__((swift_name("blendMode")));
@property int32_t color __attribute__((swift_name("color")));
@property TruoraSharedSkikoColor4f *color4f __attribute__((swift_name("color4f")));
@property TruoraSharedSkikoColorFilter * _Nullable colorFilter __attribute__((swift_name("colorFilter")));
@property TruoraSharedSkikoImageFilter * _Nullable imageFilter __attribute__((swift_name("imageFilter")));
@property BOOL isAntiAlias __attribute__((swift_name("isAntiAlias")));
@property BOOL isDither __attribute__((swift_name("isDither")));
@property (readonly) BOOL isSrcOver __attribute__((swift_name("isSrcOver")));
@property TruoraSharedSkikoMaskFilter * _Nullable maskFilter __attribute__((swift_name("maskFilter")));
@property TruoraSharedSkikoPaintMode *mode __attribute__((swift_name("mode")));
@property TruoraSharedSkikoPathEffect * _Nullable pathEffect __attribute__((swift_name("pathEffect")));
@property TruoraSharedSkikoShader * _Nullable shader __attribute__((swift_name("shader")));
@property TruoraSharedSkikoPaintStrokeCap *strokeCap __attribute__((swift_name("strokeCap")));
@property TruoraSharedSkikoPaintStrokeJoin *strokeJoin __attribute__((swift_name("strokeJoin")));
@property float strokeMiter __attribute__((swift_name("strokeMiter")));
@property float strokeWidth __attribute__((swift_name("strokeWidth")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Immutable
*/
__attribute__((swift_name("Ui_graphicsColorFilter")))
@interface TruoraSharedUi_graphicsColorFilter : TruoraSharedBase
@property (class, readonly, getter=companion) TruoraSharedUi_graphicsColorFilterCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((swift_name("Ui_graphicsPathEffect")))
@protocol TruoraSharedUi_graphicsPathEffect
@required
@end

__attribute__((swift_name("SkikoRefCnt")))
@interface TruoraSharedSkikoRefCnt : TruoraSharedSkikoManaged

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t refCount __attribute__((swift_name("refCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoShader")))
@interface TruoraSharedSkikoShader : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoShaderCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoShader *)makeWithColorFilterFilter:(TruoraSharedSkikoColorFilter * _Nullable)filter __attribute__((swift_name("makeWithColorFilter(filter:)")));
- (TruoraSharedSkikoShader *)makeWithLocalMatrixLocalMatrix:(TruoraSharedSkikoMatrix33 *)localMatrix __attribute__((swift_name("makeWithLocalMatrix(localMatrix:)")));
@end

__attribute__((swift_name("KotlinFloatIterator")))
@interface TruoraSharedKotlinFloatIterator : TruoraSharedBase <TruoraSharedKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (TruoraSharedFloat *)next __attribute__((swift_name("next()")));
- (float)nextFloat __attribute__((swift_name("nextFloat()")));
@end

__attribute__((swift_name("Ktor_ioJvmSerializable")))
@protocol TruoraSharedKtor_ioJvmSerializable
@required
@end


/**
 * Represents an immutable URL
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Url)
 *
 * @property protocol
 * @property host name without port (domain)
 * @property port the specified port or protocol default port
 * @property specifiedPort port number that was specified to override protocol's default
 * @property encodedPath encoded path without query string
 * @property parameters URL query parameters
 * @property fragment URL fragment (anchor name)
 * @property user username part of URL
 * @property password password part of URL
 * @property trailingQuery keep trailing question character even if there are no query parameters
 *
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=io/ktor/http/UrlSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface TruoraSharedKtor_httpUrl : TruoraSharedBase <TruoraSharedKtor_ioJvmSerializable>
@property (class, readonly, getter=companion) TruoraSharedKtor_httpUrlCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property (readonly) NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *encodedPathAndQuery __attribute__((swift_name("encodedPathAndQuery")));
@property (readonly) NSString *encodedQuery __attribute__((swift_name("encodedQuery")));
@property (readonly) NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<TruoraSharedKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));

/**
 * A list containing the segments of the URL path.
 *
 * This property was designed to distinguish between absolute and relative paths,
 * so it will have an empty segment at the beginning for URLs with a hostname
 * and an empty segment at the end for URLs with a trailing slash.
 *
 * ```kotlin
 * val fullUrl = Url("http://ktor.io/docs/")
 * fullUrl.pathSegments == listOf("", "docs", "")
 *
 * val absolute = Url("/docs/")
 * absolute.pathSegments == listOf("", "docs", "")
 *
 * val relative = Url("docs")
 * relative.pathSegments == listOf("docs")
 * ```
 *
 * This behaviour may not be ideal if you're working only with full URLs.
 * If you don't require the specific handling of empty segments, consider using the [segments] property instead:
 *
 * ```kotlin
 * val fullUrl = Url("http://ktor.io/docs/")
 * fullUrl.segments == listOf("docs")
 *
 * val absolute = Url("/docs/")
 * absolute.segments == listOf("docs")
 *
 * val relative = Url("docs")
 * relative.segments == listOf("docs")
 * ```
 *
 * To address this issue, the current [pathSegments] property will be renamed to [rawSegments].
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Url.pathSegments)
 */
@property (readonly) NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments"))) __attribute__((deprecated("\n        `pathSegments` is deprecated.\n\n        This property will contain an empty path segment at the beginning for URLs with a hostname,\n        and an empty path segment at the end for the URLs with a trailing slash. If you need to keep this behaviour please\n        use [rawSegments]. If you only need to access the meaningful parts of the path, consider using [segments] instead.\n             \n        Please decide if you need [rawSegments] or [segments] explicitly.\n        ")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) TruoraSharedKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) TruoraSharedKtor_httpURLProtocol * _Nullable protocolOrNull __attribute__((swift_name("protocolOrNull")));

/**
 * A list containing the segments of the URL path.
 *
 * This property is designed to distinguish between absolute and relative paths,
 * so it will have an empty segment at the beginning for URLs with a hostname
 * and an empty segment at the end for URLs with a trailing slash.
 *
 * ```kotlin
 * val fullUrl = Url("http://ktor.io/docs/")
 * fullUrl.rawSegments == listOf("", "docs", "")
 *
 * val absolute = Url("/docs/")
 * absolute.rawSegments == listOf("", "docs", "")
 *
 * val relative = Url("docs")
 * relative.rawSegments == listOf("docs")
 * ```
 *
 * This behaviour may not be ideal if you're working only with full URLs.
 * If you don't require the specific handling of empty segments, consider using the [segments] property instead:
 *
 * ```kotlin
 * val fullUrl = Url("http://ktor.io/docs/")
 * fullUrl.segments == listOf("docs")
 *
 * val absolute = Url("/docs/")
 * absolute.segments == listOf("docs")
 *
 * val relative = Url("docs")
 * relative.segments == listOf("docs")
 * ```
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Url.rawSegments)
 */
@property (readonly) NSArray<NSString *> *rawSegments __attribute__((swift_name("rawSegments")));

/**
 * A list of path segments derived from the URL, excluding any leading
 * and trailing empty segments.
 *
 * ```kotlin
 * val fullUrl = Url("http://ktor.io/docs/")
 * fullUrl.segments == listOf("docs")
 *
 * val absolute = Url("/docs/")
 * absolute.segments == listOf("docs")
 * val relative = Url("docs")
 * relative.segments == listOf("docs")
 * ```
 *
 * If you need to check for trailing slash and relative/absolute paths, please check the [rawSegments] property.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Url.segments)
 **/
@property (readonly) NSArray<NSString *> *segments __attribute__((swift_name("segments")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end


/**
 * Represents an HTTP method (verb)
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMethod)
 *
 * @property value contains method name
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface TruoraSharedKtor_httpHttpMethod : TruoraSharedBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKtor_httpHttpMethodCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));

/**
 * Represents an HTTP method (verb)
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMethod)
 *
 * @property value contains method name
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Represents an HTTP method (verb)
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMethod)
 *
 * @property value contains method name
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end


/**
 * Information about the content to be sent to the peer, recognized by a client or server engine
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent)
 */
__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface TruoraSharedKtor_httpOutgoingContent : TruoraSharedBase

/**
 * Gets an extension property for this content
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.getProperty)
 */
- (id _Nullable)getPropertyKey:(TruoraSharedKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));

/**
 * Sets an extension property for this content
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.setProperty)
 */
- (void)setPropertyKey:(TruoraSharedKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));

/**
 * Trailers to set when sending this content, will be ignored if request is not in HTTP2 mode
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.trailers)
 */
- (id<TruoraSharedKtor_httpHeaders> _Nullable)trailers __attribute__((swift_name("trailers()")));

/**
 * Specifies content length in bytes for this resource.
 *
 * If null, the resources will be sent as `Transfer-Encoding: chunked`
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.contentLength)
 */
@property (readonly) TruoraSharedLong * _Nullable contentLength __attribute__((swift_name("contentLength")));

/**
 * Specifies [ContentType] for this resource.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.contentType)
 */
@property (readonly) TruoraSharedKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));

/**
 * Headers to set when sending this content
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.headers)
 */
@property (readonly) id<TruoraSharedKtor_httpHeaders> headers __attribute__((swift_name("headers")));

/**
 * Status code to set when sending this content
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.content.OutgoingContent.status)
 */
@property (readonly) TruoraSharedKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol TruoraSharedKotlinx_coroutines_coreJob <TruoraSharedKotlinCoroutineContextElement>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id<TruoraSharedKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<TruoraSharedKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause_:(TruoraSharedKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (TruoraSharedKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<TruoraSharedKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(TruoraSharedKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id<TruoraSharedKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(TruoraSharedKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<TruoraSharedKotlinx_coroutines_coreJob>)plusOther_:(id<TruoraSharedKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<TruoraSharedKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<TruoraSharedKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
@property (readonly) id<TruoraSharedKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol TruoraSharedKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol TruoraSharedKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol TruoraSharedKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol TruoraSharedKotlinKClass <TruoraSharedKotlinKDeclarationContainer, TruoraSharedKotlinKAnnotatedElement, TruoraSharedKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((swift_name("KotlinKType")))
@protocol TruoraSharedKotlinKType
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) NSArray<TruoraSharedKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) id<TruoraSharedKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end

__attribute__((swift_name("Kotlinx_io_coreRawSink")))
@protocol TruoraSharedKotlinx_io_coreRawSink <TruoraSharedKotlinAutoCloseable>
@required
- (void)flush __attribute__((swift_name("flush()")));
- (void)writeSource:(TruoraSharedKotlinx_io_coreBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
@end

__attribute__((swift_name("Kotlinx_io_coreSink")))
@protocol TruoraSharedKotlinx_io_coreSink <TruoraSharedKotlinx_io_coreRawSink>
@required
- (void)emit __attribute__((swift_name("emit()")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
- (void)hintEmit __attribute__((swift_name("hintEmit()")));
- (int64_t)transferFromSource:(id<TruoraSharedKotlinx_io_coreRawSource>)source __attribute__((swift_name("transferFrom(source:)")));
- (void)writeSource:(id<TruoraSharedKotlinx_io_coreRawSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (void)writeSource:(TruoraSharedKotlinByteArray *)source startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("write(source:startIndex:endIndex:)")));
- (void)writeByteByte:(int8_t)byte __attribute__((swift_name("writeByte(byte:)")));
- (void)writeIntInt:(int32_t)int_ __attribute__((swift_name("writeInt(int:)")));
- (void)writeLongLong:(int64_t)long_ __attribute__((swift_name("writeLong(long:)")));
- (void)writeShortShort:(int16_t)short_ __attribute__((swift_name("writeShort(short:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) TruoraSharedKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_io_coreBuffer")))
@interface TruoraSharedKotlinx_io_coreBuffer : TruoraSharedBase <TruoraSharedKotlinx_io_coreSource, TruoraSharedKotlinx_io_coreSink>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));
- (void)close __attribute__((swift_name("close()")));
- (TruoraSharedKotlinx_io_coreBuffer *)doCopy __attribute__((swift_name("doCopy()")));
- (void)doCopyToOut:(TruoraSharedKotlinx_io_coreBuffer *)out startIndex:(int64_t)startIndex endIndex:(int64_t)endIndex __attribute__((swift_name("doCopyTo(out:startIndex:endIndex:)")));
- (void)emit __attribute__((swift_name("emit()")));
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (void)flush __attribute__((swift_name("flush()")));
- (int8_t)getPosition:(int64_t)position __attribute__((swift_name("get(position:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
- (void)hintEmit __attribute__((swift_name("hintEmit()")));
- (id<TruoraSharedKotlinx_io_coreSource>)peek __attribute__((swift_name("peek()")));
- (int64_t)readAtMostToSink:(TruoraSharedKotlinx_io_coreBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readAtMostTo(sink:byteCount:)")));
- (int32_t)readAtMostToSink:(TruoraSharedKotlinByteArray *)sink startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("readAtMostTo(sink:startIndex:endIndex:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (void)readToSink:(id<TruoraSharedKotlinx_io_coreRawSink>)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readTo(sink:byteCount:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int64_t)transferFromSource:(id<TruoraSharedKotlinx_io_coreRawSource>)source __attribute__((swift_name("transferFrom(source:)")));
- (int64_t)transferToSink:(id<TruoraSharedKotlinx_io_coreRawSink>)sink __attribute__((swift_name("transferTo(sink:)")));
- (void)writeSource:(TruoraSharedKotlinx_io_coreBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (void)writeSource:(id<TruoraSharedKotlinx_io_coreRawSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (void)writeSource:(TruoraSharedKotlinByteArray *)source startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("write(source:startIndex:endIndex:)")));
- (void)writeByteByte:(int8_t)byte __attribute__((swift_name("writeByte(byte:)")));
- (void)writeIntInt:(int32_t)int_ __attribute__((swift_name("writeInt(int:)")));
- (void)writeLongLong:(int64_t)long_ __attribute__((swift_name("writeLong(long:)")));
- (void)writeShortShort:(int16_t)short_ __attribute__((swift_name("writeShort(short:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) TruoraSharedKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay.Companion")))
@interface TruoraSharedKtor_utilsWeekDayCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_utilsWeekDayCompanion *shared __attribute__((swift_name("shared")));

/**
 * Lookup an instance by [ordinal]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.WeekDay.Companion.from)
 */
- (TruoraSharedKtor_utilsWeekDay *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));

/**
 * Lookup an instance by short week day name [WeekDay.value]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.WeekDay.Companion.from)
 */
- (TruoraSharedKtor_utilsWeekDay *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth.Companion")))
@interface TruoraSharedKtor_utilsMonthCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_utilsMonthCompanion *shared __attribute__((swift_name("shared")));

/**
 * Lookup an instance by [ordinal]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.Month.Companion.from)
 */
- (TruoraSharedKtor_utilsMonth *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));

/**
 * Lookup an instance by short month name [Month.value]
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.util.date.Month.Companion.from)
 */
- (TruoraSharedKtor_utilsMonth *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol TruoraSharedKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<TruoraSharedKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface TruoraSharedKotlinAbstractCoroutineContextKey<B, E> : TruoraSharedBase <TruoraSharedKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<TruoraSharedKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<TruoraSharedKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface TruoraSharedKotlinx_coroutines_coreCoroutineDispatcherKey : TruoraSharedKotlinAbstractCoroutineContextKey<id<TruoraSharedKotlinContinuationInterceptor>, TruoraSharedKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<TruoraSharedKotlinCoroutineContextKey>)baseKey safeCast:(id<TruoraSharedKotlinCoroutineContextElement> _Nullable (^)(id<TruoraSharedKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol TruoraSharedKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@protocol TruoraSharedKtor_utilsStringValuesBuilder
@required
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<TruoraSharedKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<TruoraSharedKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<TruoraSharedKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<TruoraSharedKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilderImpl")))
@interface TruoraSharedKtor_utilsStringValuesBuilderImpl : TruoraSharedBase <TruoraSharedKtor_utilsStringValuesBuilder>
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<TruoraSharedKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<TruoraSharedKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<TruoraSharedKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<TruoraSharedKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) TruoraSharedMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface TruoraSharedKtor_httpHeadersBuilder : TruoraSharedKtor_utilsStringValuesBuilderImpl
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<TruoraSharedKtor_httpHeaders>)build __attribute__((swift_name("build()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder.Companion")))
@interface TruoraSharedKtor_client_coreHttpRequestBuilderCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_client_coreHttpRequestBuilderCompanion *shared __attribute__((swift_name("shared")));
@end


/**
 * A URL builder with all mutable components
 *
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLBuilder)
 *
 * @property protocol URL protocol (scheme)
 * @property host name without port (domain)
 * @property port port number
 * @property user username part (optional)
 * @property password password part (optional)
 * @property pathSegments URL path without query
 * @property parameters URL query parameters
 * @property fragment URL fragment (anchor name)
 * @property trailingQuery keep a trailing question character even if there are no query parameters
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface TruoraSharedKtor_httpURLBuilder : TruoraSharedBase
- (instancetype)initWithProtocol:(TruoraSharedKtor_httpURLProtocol * _Nullable)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password pathSegments:(NSArray<NSString *> *)pathSegments parameters:(id<TruoraSharedKtor_httpParameters>)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:pathSegments:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKtor_httpURLBuilderCompanion *companion __attribute__((swift_name("companion")));

/**
 * Build a [Url] instance (everything is copied to a new instance)
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLBuilder.build)
 */
- (TruoraSharedKtor_httpUrl *)build __attribute__((swift_name("build()")));

/**
 * Build a URL string
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLBuilder.buildString)
 */
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property id<TruoraSharedKtor_httpParametersBuilder> encodedParameters __attribute__((swift_name("encodedParameters")));
@property NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property NSArray<NSString *> *encodedPathSegments __attribute__((swift_name("encodedPathSegments")));
@property NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) id<TruoraSharedKtor_httpParametersBuilder> parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property int32_t port __attribute__((swift_name("port")));
@property TruoraSharedKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property TruoraSharedKtor_httpURLProtocol * _Nullable protocolOrNull __attribute__((swift_name("protocolOrNull")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol TruoraSharedKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<TruoraSharedKotlinKClass>)kClass provider:(id<TruoraSharedKotlinx_serialization_coreKSerializer> (^)(NSArray<id<TruoraSharedKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<TruoraSharedKotlinKClass>)kClass serializer:(id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<TruoraSharedKotlinKClass>)baseClass actualClass:(id<TruoraSharedKotlinKClass>)actualClass actualSerializer:(id<TruoraSharedKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<TruoraSharedKotlinKClass>)baseClass defaultDeserializerProvider:(id<TruoraSharedKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<TruoraSharedKotlinKClass>)baseClass defaultDeserializerProvider:(id<TruoraSharedKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<TruoraSharedKotlinKClass>)baseClass defaultSerializerProvider:(id<TruoraSharedKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoNative.Companion")))
@interface TruoraSharedSkikoNativeCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoNativeCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) void * _Nullable NullPointer __attribute__((swift_name("NullPointer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPaint.Companion")))
@interface TruoraSharedSkikoPaintCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoPaintCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColor4f")))
@interface TruoraSharedSkikoColor4f : TruoraSharedBase
- (instancetype)initWithRgba:(TruoraSharedKotlinFloatArray *)rgba __attribute__((swift_name("init(rgba:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithC:(int32_t)c __attribute__((swift_name("init(c:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithR:(float)r g:(float)g b:(float)b a:(float)a __attribute__((swift_name("init(r:g:b:a:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoColor4fCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (TruoraSharedKotlinFloatArray *)flatten __attribute__((swift_name("flatten()")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (TruoraSharedSkikoColor4f *)makeLerpOther:(TruoraSharedSkikoColor4f *)other weight:(float)weight __attribute__((swift_name("makeLerp(other:weight:)")));
- (int32_t)toColor __attribute__((swift_name("toColor()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (TruoraSharedSkikoColor4f *)withA_a:(float)_a __attribute__((swift_name("withA(_a:)")));
- (TruoraSharedSkikoColor4f *)withB_b:(float)_b __attribute__((swift_name("withB(_b:)")));
- (TruoraSharedSkikoColor4f *)withG_g:(float)_g __attribute__((swift_name("withG(_g:)")));
- (TruoraSharedSkikoColor4f *)withR_r:(float)_r __attribute__((swift_name("withR(_r:)")));
@property (readonly) float a __attribute__((swift_name("a")));
@property (readonly) float b __attribute__((swift_name("b")));
@property (readonly) float g __attribute__((swift_name("g")));
@property (readonly) float r __attribute__((swift_name("r")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorSpace")))
@interface TruoraSharedSkikoColorSpace : TruoraSharedSkikoManaged
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoColorSpaceCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoColor4f *)convertToColor:(TruoraSharedSkikoColorSpace * _Nullable)toColor color:(TruoraSharedSkikoColor4f *)color __attribute__((swift_name("convert(toColor:color:)")));
@property (readonly) BOOL isGammaCloseToSRGB __attribute__((swift_name("isGammaCloseToSRGB")));
@property (readonly) BOOL isGammaLinear __attribute__((swift_name("isGammaLinear")));
@property (readonly) BOOL isSRGB __attribute__((swift_name("isSRGB")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoBlendMode")))
@interface TruoraSharedSkikoBlendMode : TruoraSharedKotlinEnum<TruoraSharedSkikoBlendMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoBlendMode *clear __attribute__((swift_name("clear")));
@property (class, readonly) TruoraSharedSkikoBlendMode *src __attribute__((swift_name("src")));
@property (class, readonly) TruoraSharedSkikoBlendMode *dst __attribute__((swift_name("dst")));
@property (class, readonly) TruoraSharedSkikoBlendMode *srcOver __attribute__((swift_name("srcOver")));
@property (class, readonly) TruoraSharedSkikoBlendMode *dstOver __attribute__((swift_name("dstOver")));
@property (class, readonly) TruoraSharedSkikoBlendMode *srcIn __attribute__((swift_name("srcIn")));
@property (class, readonly) TruoraSharedSkikoBlendMode *dstIn __attribute__((swift_name("dstIn")));
@property (class, readonly) TruoraSharedSkikoBlendMode *srcOut __attribute__((swift_name("srcOut")));
@property (class, readonly) TruoraSharedSkikoBlendMode *dstOut __attribute__((swift_name("dstOut")));
@property (class, readonly) TruoraSharedSkikoBlendMode *srcAtop __attribute__((swift_name("srcAtop")));
@property (class, readonly) TruoraSharedSkikoBlendMode *dstAtop __attribute__((swift_name("dstAtop")));
@property (class, readonly) TruoraSharedSkikoBlendMode *xor_ __attribute__((swift_name("xor_")));
@property (class, readonly) TruoraSharedSkikoBlendMode *plus __attribute__((swift_name("plus")));
@property (class, readonly) TruoraSharedSkikoBlendMode *modulate __attribute__((swift_name("modulate")));
@property (class, readonly) TruoraSharedSkikoBlendMode *screen __attribute__((swift_name("screen")));
@property (class, readonly) TruoraSharedSkikoBlendMode *overlay __attribute__((swift_name("overlay")));
@property (class, readonly) TruoraSharedSkikoBlendMode *darken __attribute__((swift_name("darken")));
@property (class, readonly) TruoraSharedSkikoBlendMode *lighten __attribute__((swift_name("lighten")));
@property (class, readonly) TruoraSharedSkikoBlendMode *colorDodge __attribute__((swift_name("colorDodge")));
@property (class, readonly) TruoraSharedSkikoBlendMode *colorBurn __attribute__((swift_name("colorBurn")));
@property (class, readonly) TruoraSharedSkikoBlendMode *hardLight __attribute__((swift_name("hardLight")));
@property (class, readonly) TruoraSharedSkikoBlendMode *softLight __attribute__((swift_name("softLight")));
@property (class, readonly) TruoraSharedSkikoBlendMode *difference __attribute__((swift_name("difference")));
@property (class, readonly) TruoraSharedSkikoBlendMode *exclusion __attribute__((swift_name("exclusion")));
@property (class, readonly) TruoraSharedSkikoBlendMode *multiply __attribute__((swift_name("multiply")));
@property (class, readonly) TruoraSharedSkikoBlendMode *hue __attribute__((swift_name("hue")));
@property (class, readonly) TruoraSharedSkikoBlendMode *saturation __attribute__((swift_name("saturation")));
@property (class, readonly) TruoraSharedSkikoBlendMode *color __attribute__((swift_name("color")));
@property (class, readonly) TruoraSharedSkikoBlendMode *luminosity __attribute__((swift_name("luminosity")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoBlendMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoBlendMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorFilter")))
@interface TruoraSharedSkikoColorFilter : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoColorFilterCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoImageFilter")))
@interface TruoraSharedSkikoImageFilter : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoImageFilterCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoMaskFilter")))
@interface TruoraSharedSkikoMaskFilter : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoMaskFilterCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPaintMode")))
@interface TruoraSharedSkikoPaintMode : TruoraSharedKotlinEnum<TruoraSharedSkikoPaintMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoPaintMode *fill __attribute__((swift_name("fill")));
@property (class, readonly) TruoraSharedSkikoPaintMode *stroke __attribute__((swift_name("stroke")));
@property (class, readonly) TruoraSharedSkikoPaintMode *strokeAndFill __attribute__((swift_name("strokeAndFill")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoPaintMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoPaintMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathEffect")))
@interface TruoraSharedSkikoPathEffect : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoPathEffectCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoPathEffect *)makeComposeInner:(TruoraSharedSkikoPathEffect * _Nullable)inner __attribute__((swift_name("makeCompose(inner:)")));
- (TruoraSharedSkikoPathEffect *)makeSumSecond:(TruoraSharedSkikoPathEffect * _Nullable)second __attribute__((swift_name("makeSum(second:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPaintStrokeCap")))
@interface TruoraSharedSkikoPaintStrokeCap : TruoraSharedKotlinEnum<TruoraSharedSkikoPaintStrokeCap *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoPaintStrokeCap *butt __attribute__((swift_name("butt")));
@property (class, readonly) TruoraSharedSkikoPaintStrokeCap *round __attribute__((swift_name("round")));
@property (class, readonly) TruoraSharedSkikoPaintStrokeCap *square __attribute__((swift_name("square")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoPaintStrokeCap *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoPaintStrokeCap *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPaintStrokeJoin")))
@interface TruoraSharedSkikoPaintStrokeJoin : TruoraSharedKotlinEnum<TruoraSharedSkikoPaintStrokeJoin *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoPaintStrokeJoin *miter __attribute__((swift_name("miter")));
@property (class, readonly) TruoraSharedSkikoPaintStrokeJoin *round __attribute__((swift_name("round")));
@property (class, readonly) TruoraSharedSkikoPaintStrokeJoin *bevel __attribute__((swift_name("bevel")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoPaintStrokeJoin *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoPaintStrokeJoin *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ui_graphicsColorFilter.Companion")))
@interface TruoraSharedUi_graphicsColorFilterCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedUi_graphicsColorFilterCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsColorFilter *)colorMatrixColorMatrix:(id)colorMatrix __attribute__((swift_name("colorMatrix(colorMatrix:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsColorFilter *)lightingMultiply:(uint64_t)multiply add:(uint64_t)add __attribute__((swift_name("lighting(multiply:add:)")));

/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
- (TruoraSharedUi_graphicsColorFilter *)tintColor:(uint64_t)color blendMode:(int32_t)blendMode __attribute__((swift_name("tint(color:blendMode:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoShader.Companion")))
@interface TruoraSharedSkikoShaderCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoShaderCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoShader *)makeBlendMode:(TruoraSharedSkikoBlendMode *)mode dst:(TruoraSharedSkikoShader * _Nullable)dst src:(TruoraSharedSkikoShader * _Nullable)src __attribute__((swift_name("makeBlend(mode:dst:src:)")));
- (TruoraSharedSkikoShader *)makeColorColor:(int32_t)color __attribute__((swift_name("makeColor(color:)")));
- (TruoraSharedSkikoShader *)makeColorColor:(TruoraSharedSkikoColor4f *)color space:(TruoraSharedSkikoColorSpace * _Nullable)space __attribute__((swift_name("makeColor(color:space:)")));
- (TruoraSharedSkikoShader *)makeEmpty __attribute__((swift_name("makeEmpty()")));
- (TruoraSharedSkikoShader *)makeFractalNoiseBaseFrequencyX:(float)baseFrequencyX baseFrequencyY:(float)baseFrequencyY numOctaves:(int32_t)numOctaves seed:(float)seed tileSize:(TruoraSharedSkikoISize *)tileSize __attribute__((swift_name("makeFractalNoise(baseFrequencyX:baseFrequencyY:numOctaves:seed:tileSize:)")));
- (TruoraSharedSkikoShader *)makeLinearGradientP0:(TruoraSharedSkikoPoint *)p0 p1:(TruoraSharedSkikoPoint *)p1 colors:(TruoraSharedKotlinIntArray *)colors __attribute__((swift_name("makeLinearGradient(p0:p1:colors:)")));
- (TruoraSharedSkikoShader *)makeLinearGradientP0:(TruoraSharedSkikoPoint *)p0 p1:(TruoraSharedSkikoPoint *)p1 colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions __attribute__((swift_name("makeLinearGradient(p0:p1:colors:positions:)")));
- (TruoraSharedSkikoShader *)makeLinearGradientP0:(TruoraSharedSkikoPoint *)p0 p1:(TruoraSharedSkikoPoint *)p1 colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeLinearGradient(p0:p1:colors:positions:style:)")));
- (TruoraSharedSkikoShader *)makeLinearGradientP0:(TruoraSharedSkikoPoint *)p0 p1:(TruoraSharedSkikoPoint *)p1 colors:(TruoraSharedKotlinArray<TruoraSharedSkikoColor4f *> *)colors cs:(TruoraSharedSkikoColorSpace * _Nullable)cs positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeLinearGradient(p0:p1:colors:cs:positions:style:)")));
- (TruoraSharedSkikoShader *)makeLinearGradientX0:(float)x0 y0:(float)y0 x1:(float)x1 y1:(float)y1 colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeLinearGradient(x0:y0:x1:y1:colors:positions:style:)")));
- (TruoraSharedSkikoShader *)makeLinearGradientX0:(float)x0 y0:(float)y0 x1:(float)x1 y1:(float)y1 colors:(TruoraSharedKotlinArray<TruoraSharedSkikoColor4f *> *)colors cs:(TruoraSharedSkikoColorSpace * _Nullable)cs positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeLinearGradient(x0:y0:x1:y1:colors:cs:positions:style:)")));
- (TruoraSharedSkikoShader *)makeRadialGradientCenter:(TruoraSharedSkikoPoint *)center r:(float)r colors:(TruoraSharedKotlinIntArray *)colors __attribute__((swift_name("makeRadialGradient(center:r:colors:)")));
- (TruoraSharedSkikoShader *)makeRadialGradientCenter:(TruoraSharedSkikoPoint *)center r:(float)r colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions __attribute__((swift_name("makeRadialGradient(center:r:colors:positions:)")));
- (TruoraSharedSkikoShader *)makeRadialGradientCenter:(TruoraSharedSkikoPoint *)center r:(float)r colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeRadialGradient(center:r:colors:positions:style:)")));
- (TruoraSharedSkikoShader *)makeRadialGradientX:(float)x y:(float)y r:(float)r colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeRadialGradient(x:y:r:colors:positions:style:)")));
- (TruoraSharedSkikoShader *)makeRadialGradientCenter:(TruoraSharedSkikoPoint *)center r:(float)r colors:(TruoraSharedKotlinArray<TruoraSharedSkikoColor4f *> *)colors cs:(TruoraSharedSkikoColorSpace * _Nullable)cs positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeRadialGradient(center:r:colors:cs:positions:style:)")));
- (TruoraSharedSkikoShader *)makeRadialGradientX:(float)x y:(float)y r:(float)r colors:(TruoraSharedKotlinArray<TruoraSharedSkikoColor4f *> *)colors cs:(TruoraSharedSkikoColorSpace * _Nullable)cs positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeRadialGradient(x:y:r:colors:cs:positions:style:)")));
- (TruoraSharedSkikoShader *)makeSweepGradientCenter:(TruoraSharedSkikoPoint *)center colors:(TruoraSharedKotlinIntArray *)colors __attribute__((swift_name("makeSweepGradient(center:colors:)")));
- (TruoraSharedSkikoShader *)makeSweepGradientX:(float)x y:(float)y colors:(TruoraSharedKotlinIntArray *)colors __attribute__((swift_name("makeSweepGradient(x:y:colors:)")));
- (TruoraSharedSkikoShader *)makeSweepGradientCenter:(TruoraSharedSkikoPoint *)center colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions __attribute__((swift_name("makeSweepGradient(center:colors:positions:)")));
- (TruoraSharedSkikoShader *)makeSweepGradientX:(float)x y:(float)y colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions __attribute__((swift_name("makeSweepGradient(x:y:colors:positions:)")));
- (TruoraSharedSkikoShader *)makeSweepGradientCenter:(TruoraSharedSkikoPoint *)center colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeSweepGradient(center:colors:positions:style:)")));
- (TruoraSharedSkikoShader *)makeSweepGradientX:(float)x y:(float)y colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeSweepGradient(x:y:colors:positions:style:)")));
- (TruoraSharedSkikoShader *)makeSweepGradientCenter:(TruoraSharedSkikoPoint *)center startAngle:(float)startAngle endAngle:(float)endAngle colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeSweepGradient(center:startAngle:endAngle:colors:positions:style:)")));
- (TruoraSharedSkikoShader *)makeSweepGradientX:(float)x y:(float)y startAngle:(float)startAngle endAngle:(float)endAngle colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeSweepGradient(x:y:startAngle:endAngle:colors:positions:style:)")));
- (TruoraSharedSkikoShader *)makeSweepGradientCenter:(TruoraSharedSkikoPoint *)center startAngle:(float)startAngle endAngle:(float)endAngle colors:(TruoraSharedKotlinArray<TruoraSharedSkikoColor4f *> *)colors cs:(TruoraSharedSkikoColorSpace * _Nullable)cs positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeSweepGradient(center:startAngle:endAngle:colors:cs:positions:style:)")));
- (TruoraSharedSkikoShader *)makeSweepGradientX:(float)x y:(float)y startAngle:(float)startAngle endAngle:(float)endAngle colors:(TruoraSharedKotlinArray<TruoraSharedSkikoColor4f *> *)colors cs:(TruoraSharedSkikoColorSpace * _Nullable)cs positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeSweepGradient(x:y:startAngle:endAngle:colors:cs:positions:style:)")));
- (TruoraSharedSkikoShader *)makeTurbulenceBaseFrequencyX:(float)baseFrequencyX baseFrequencyY:(float)baseFrequencyY numOctaves:(int32_t)numOctaves seed:(float)seed tileSize:(TruoraSharedSkikoISize *)tileSize __attribute__((swift_name("makeTurbulence(baseFrequencyX:baseFrequencyY:numOctaves:seed:tileSize:)")));
- (TruoraSharedSkikoShader *)makeTwoPointConicalGradientP0:(TruoraSharedSkikoPoint *)p0 r0:(float)r0 p1:(TruoraSharedSkikoPoint *)p1 r1:(float)r1 colors:(TruoraSharedKotlinIntArray *)colors __attribute__((swift_name("makeTwoPointConicalGradient(p0:r0:p1:r1:colors:)")));
- (TruoraSharedSkikoShader *)makeTwoPointConicalGradientP0:(TruoraSharedSkikoPoint *)p0 r0:(float)r0 p1:(TruoraSharedSkikoPoint *)p1 r1:(float)r1 colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions __attribute__((swift_name("makeTwoPointConicalGradient(p0:r0:p1:r1:colors:positions:)")));
- (TruoraSharedSkikoShader *)makeTwoPointConicalGradientP0:(TruoraSharedSkikoPoint *)p0 r0:(float)r0 p1:(TruoraSharedSkikoPoint *)p1 r1:(float)r1 colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeTwoPointConicalGradient(p0:r0:p1:r1:colors:positions:style:)")));
- (TruoraSharedSkikoShader *)makeTwoPointConicalGradientP0:(TruoraSharedSkikoPoint *)p0 r0:(float)r0 p1:(TruoraSharedSkikoPoint *)p1 r1:(float)r1 colors:(TruoraSharedKotlinArray<TruoraSharedSkikoColor4f *> *)colors cs:(TruoraSharedSkikoColorSpace * _Nullable)cs positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeTwoPointConicalGradient(p0:r0:p1:r1:colors:cs:positions:style:)")));
- (TruoraSharedSkikoShader *)makeTwoPointConicalGradientX0:(float)x0 y0:(float)y0 r0:(float)r0 x1:(float)x1 y1:(float)y1 r1:(float)r1 colors:(TruoraSharedKotlinIntArray *)colors positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeTwoPointConicalGradient(x0:y0:r0:x1:y1:r1:colors:positions:style:)")));
- (TruoraSharedSkikoShader *)makeTwoPointConicalGradientX0:(float)x0 y0:(float)y0 r0:(float)r0 x1:(float)x1 y1:(float)y1 r1:(float)r1 colors:(TruoraSharedKotlinArray<TruoraSharedSkikoColor4f *> *)colors cs:(TruoraSharedSkikoColorSpace * _Nullable)cs positions:(TruoraSharedKotlinFloatArray * _Nullable)positions style:(TruoraSharedSkikoGradientStyle *)style __attribute__((swift_name("makeTwoPointConicalGradient(x0:y0:r0:x1:y1:r1:colors:cs:positions:style:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoMatrix33")))
@interface TruoraSharedSkikoMatrix33 : TruoraSharedBase
- (instancetype)initWithMat:(TruoraSharedKotlinFloatArray *)mat __attribute__((swift_name("init(mat:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoMatrix33Companion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoMatrix44 *)asMatrix44 __attribute__((swift_name("asMatrix44()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (TruoraSharedSkikoMatrix33 *)makeConcatOther:(TruoraSharedSkikoMatrix33 *)other __attribute__((swift_name("makeConcat(other:)")));
- (TruoraSharedSkikoMatrix33 *)makePreScaleSx:(float)sx sy:(float)sy __attribute__((swift_name("makePreScale(sx:sy:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedKotlinFloatArray *mat __attribute__((swift_name("mat")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl.Companion")))
@interface TruoraSharedKtor_httpUrlCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_httpUrlCompanion *shared __attribute__((swift_name("shared")));
- (id<TruoraSharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * Represents HTTP parameters as a map from case-insensitive names to collection of [String] values
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.Parameters)
 */
__attribute__((swift_name("Ktor_httpParameters")))
@protocol TruoraSharedKtor_httpParameters <TruoraSharedKtor_utilsStringValues>
@required
@end


/**
 * Represents URL protocol
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol)
 *
 * @property name of protocol (schema)
 * @property defaultPort default port for protocol or `-1` if not known
 */
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface TruoraSharedKtor_httpURLProtocol : TruoraSharedBase <TruoraSharedKtor_ioJvmSerializable>
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKtor_httpURLProtocolCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));

/**
 * Represents URL protocol
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol)
 *
 * @property name of protocol (schema)
 * @property defaultPort default port for protocol or `-1` if not known
 */
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));

/**
 * Represents URL protocol
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol)
 *
 * @property name of protocol (schema)
 * @property defaultPort default port for protocol or `-1` if not known
 */
- (NSUInteger)hash __attribute__((swift_name("hash()")));

/**
 * Represents URL protocol
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol)
 *
 * @property name of protocol (schema)
 * @property defaultPort default port for protocol or `-1` if not known
 */
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod.Companion")))
@interface TruoraSharedKtor_httpHttpMethodCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_httpHttpMethodCompanion *shared __attribute__((swift_name("shared")));

/**
 * Parse HTTP method by [method] string
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMethod.Companion.parse)
 */
- (TruoraSharedKtor_httpHttpMethod *)parseMethod:(NSString *)method __attribute__((swift_name("parse(method:)")));

/**
 * A list of default HTTP methods
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.HttpMethod.Companion.DefaultMethods)
 */
@property (readonly) NSArray<TruoraSharedKtor_httpHttpMethod *> *DefaultMethods __attribute__((swift_name("DefaultMethods")));
@property (readonly) TruoraSharedKtor_httpHttpMethod *Delete __attribute__((swift_name("Delete")));
@property (readonly) TruoraSharedKtor_httpHttpMethod *Get __attribute__((swift_name("Get")));
@property (readonly) TruoraSharedKtor_httpHttpMethod *Head __attribute__((swift_name("Head")));
@property (readonly) TruoraSharedKtor_httpHttpMethod *Options __attribute__((swift_name("Options")));
@property (readonly) TruoraSharedKtor_httpHttpMethod *Patch __attribute__((swift_name("Patch")));
@property (readonly) TruoraSharedKtor_httpHttpMethod *Post __attribute__((swift_name("Post")));
@property (readonly) TruoraSharedKtor_httpHttpMethod *Put __attribute__((swift_name("Put")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol TruoraSharedKotlinx_coroutines_coreChildHandle <TruoraSharedKotlinx_coroutines_coreDisposableHandle>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (BOOL)childCancelledCause:(TruoraSharedKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
@property (readonly) id<TruoraSharedKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol TruoraSharedKotlinx_coroutines_coreChildJob <TruoraSharedKotlinx_coroutines_coreJob>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)parentCancelledParentJob:(id<TruoraSharedKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end

__attribute__((swift_name("KotlinSequence")))
@protocol TruoraSharedKotlinSequence
@required
- (id<TruoraSharedKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause")))
@protocol TruoraSharedKotlinx_coroutines_coreSelectClause
@required
@property (readonly) id clauseObject __attribute__((swift_name("clauseObject")));
@property (readonly) TruoraSharedKotlinUnit *(^(^ _Nullable onCancellationConstructor)(id<TruoraSharedKotlinx_coroutines_coreSelectInstance>, id _Nullable, id _Nullable))(TruoraSharedKotlinThrowable *, id _Nullable, id<TruoraSharedKotlinCoroutineContext>) __attribute__((swift_name("onCancellationConstructor")));
@property (readonly) id _Nullable (^processResFunc)(id, id _Nullable, id _Nullable) __attribute__((swift_name("processResFunc")));
@property (readonly) void (^regFunc)(id, id<TruoraSharedKotlinx_coroutines_coreSelectInstance>, id _Nullable) __attribute__((swift_name("regFunc")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol TruoraSharedKotlinx_coroutines_coreSelectClause0 <TruoraSharedKotlinx_coroutines_coreSelectClause>
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface TruoraSharedKotlinKTypeProjection : TruoraSharedBase
- (instancetype)initWithVariance:(TruoraSharedKotlinKVariance * _Nullable)variance type:(id<TruoraSharedKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKotlinKTypeProjectionCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedKotlinKTypeProjection *)doCopyVariance:(TruoraSharedKotlinKVariance * _Nullable)variance type:(id<TruoraSharedKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<TruoraSharedKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) TruoraSharedKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder.Companion")))
@interface TruoraSharedKtor_httpURLBuilderCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_httpURLBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_httpParametersBuilder")))
@protocol TruoraSharedKtor_httpParametersBuilder <TruoraSharedKtor_utilsStringValuesBuilder>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColor4f.Companion")))
@interface TruoraSharedSkikoColor4fCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoColor4fCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedKotlinFloatArray *)flattenArrayColors:(TruoraSharedKotlinArray<TruoraSharedSkikoColor4f *> *)colors __attribute__((swift_name("flattenArray(colors:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorSpace.Companion")))
@interface TruoraSharedSkikoColorSpaceCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoColorSpaceCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) TruoraSharedSkikoColorSpace *displayP3 __attribute__((swift_name("displayP3")));
@property (readonly) TruoraSharedSkikoColorSpace *sRGB __attribute__((swift_name("sRGB")));
@property (readonly) TruoraSharedSkikoColorSpace *sRGBLinear __attribute__((swift_name("sRGBLinear")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorFilter.Companion")))
@interface TruoraSharedSkikoColorFilterCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoColorFilterCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoColorFilter *)makeBlendColor:(int32_t)color mode:(TruoraSharedSkikoBlendMode *)mode __attribute__((swift_name("makeBlend(color:mode:)")));
- (TruoraSharedSkikoColorFilter *)makeComposedOuter:(TruoraSharedSkikoColorFilter * _Nullable)outer inner:(TruoraSharedSkikoColorFilter * _Nullable)inner __attribute__((swift_name("makeComposed(outer:inner:)")));
- (TruoraSharedSkikoColorFilter *)makeHSLAMatrixMatrix:(TruoraSharedSkikoColorMatrix *)matrix __attribute__((swift_name("makeHSLAMatrix(matrix:)")));
- (TruoraSharedSkikoColorFilter *)makeHighContrastGrayscale:(BOOL)grayscale mode:(TruoraSharedSkikoInversionMode *)mode contrast:(float)contrast __attribute__((swift_name("makeHighContrast(grayscale:mode:contrast:)")));
- (TruoraSharedSkikoColorFilter *)makeLerpDst:(TruoraSharedSkikoColorFilter * _Nullable)dst src:(TruoraSharedSkikoColorFilter * _Nullable)src t:(float)t __attribute__((swift_name("makeLerp(dst:src:t:)")));
- (TruoraSharedSkikoColorFilter *)makeLightingColorMul:(int32_t)colorMul colorAdd:(int32_t)colorAdd __attribute__((swift_name("makeLighting(colorMul:colorAdd:)")));
- (TruoraSharedSkikoColorFilter *)makeMatrixMatrix:(TruoraSharedSkikoColorMatrix *)matrix __attribute__((swift_name("makeMatrix(matrix:)")));
- (TruoraSharedSkikoColorFilter *)makeOverdrawColors:(TruoraSharedKotlinIntArray *)colors __attribute__((swift_name("makeOverdraw(colors:)")));
- (TruoraSharedSkikoColorFilter *)makeTableTable:(TruoraSharedKotlinByteArray *)table __attribute__((swift_name("makeTable(table:)")));
- (TruoraSharedSkikoColorFilter *)makeTableARGBA:(TruoraSharedKotlinByteArray * _Nullable)a r:(TruoraSharedKotlinByteArray * _Nullable)r g:(TruoraSharedKotlinByteArray * _Nullable)g b:(TruoraSharedKotlinByteArray * _Nullable)b __attribute__((swift_name("makeTableARGB(a:r:g:b:)")));
@property (readonly) TruoraSharedSkikoColorFilter *luma __attribute__((swift_name("luma")));
@property (readonly) TruoraSharedSkikoColorFilter *sRGBToLinearGamma __attribute__((swift_name("sRGBToLinearGamma")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoImageFilter.Companion")))
@interface TruoraSharedSkikoImageFilterCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoImageFilterCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoImageFilter *)makeArithmeticK1:(float)k1 k2:(float)k2 k3:(float)k3 k4:(float)k4 enforcePMColor:(BOOL)enforcePMColor bg:(TruoraSharedSkikoImageFilter * _Nullable)bg fg:(TruoraSharedSkikoImageFilter * _Nullable)fg crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeArithmetic(k1:k2:k3:k4:enforcePMColor:bg:fg:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeBlendBlendMode:(TruoraSharedSkikoBlendMode *)blendMode bg:(TruoraSharedSkikoImageFilter * _Nullable)bg fg:(TruoraSharedSkikoImageFilter * _Nullable)fg crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeBlend(blendMode:bg:fg:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeBlurSigmaX:(float)sigmaX sigmaY:(float)sigmaY mode:(TruoraSharedSkikoFilterTileMode *)mode input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeBlur(sigmaX:sigmaY:mode:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeColorFilterF:(TruoraSharedSkikoColorFilter * _Nullable)f input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeColorFilter(f:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeComposeOuter:(TruoraSharedSkikoImageFilter * _Nullable)outer inner:(TruoraSharedSkikoImageFilter * _Nullable)inner __attribute__((swift_name("makeCompose(outer:inner:)")));
- (TruoraSharedSkikoImageFilter *)makeDilateRx:(float)rx ry:(float)ry input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeDilate(rx:ry:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeDisplacementMapX:(TruoraSharedSkikoColorChannel *)x y:(TruoraSharedSkikoColorChannel *)y scale:(float)scale displacement:(TruoraSharedSkikoImageFilter * _Nullable)displacement color:(TruoraSharedSkikoImageFilter * _Nullable)color crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeDisplacementMap(x:y:scale:displacement:color:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeDistantLitDiffuseX:(float)x y:(float)y z:(float)z lightColor:(int32_t)lightColor surfaceScale:(float)surfaceScale kd:(float)kd input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeDistantLitDiffuse(x:y:z:lightColor:surfaceScale:kd:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeDistantLitSpecularX:(float)x y:(float)y z:(float)z lightColor:(int32_t)lightColor surfaceScale:(float)surfaceScale ks:(float)ks shininess:(float)shininess input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeDistantLitSpecular(x:y:z:lightColor:surfaceScale:ks:shininess:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeDropShadowDx:(float)dx dy:(float)dy sigmaX:(float)sigmaX sigmaY:(float)sigmaY color:(int32_t)color input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeDropShadow(dx:dy:sigmaX:sigmaY:color:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeDropShadowOnlyDx:(float)dx dy:(float)dy sigmaX:(float)sigmaX sigmaY:(float)sigmaY color:(int32_t)color input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeDropShadowOnly(dx:dy:sigmaX:sigmaY:color:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeErodeRx:(float)rx ry:(float)ry input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeErode(rx:ry:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeImageImage:(TruoraSharedSkikoImage *)image __attribute__((swift_name("makeImage(image:)")));
- (TruoraSharedSkikoImageFilter *)makeImageImage:(TruoraSharedSkikoImage * _Nullable)image src:(TruoraSharedSkikoRect *)src dst:(TruoraSharedSkikoRect *)dst mode:(id<TruoraSharedSkikoSamplingMode>)mode __attribute__((swift_name("makeImage(image:src:dst:mode:)")));
- (TruoraSharedSkikoImageFilter *)makeMagnifierR:(TruoraSharedSkikoRect *)r zoomAmount:(float)zoomAmount inset:(float)inset samplingMode:(id<TruoraSharedSkikoSamplingMode>)samplingMode input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeMagnifier(r:zoomAmount:inset:samplingMode:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeMatrixConvolutionKernelW:(int32_t)kernelW kernelH:(int32_t)kernelH kernel:(TruoraSharedKotlinFloatArray * _Nullable)kernel gain:(float)gain bias:(float)bias offsetX:(int32_t)offsetX offsetY:(int32_t)offsetY tileMode:(TruoraSharedSkikoFilterTileMode *)tileMode convolveAlpha:(BOOL)convolveAlpha input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeMatrixConvolution(kernelW:kernelH:kernel:gain:bias:offsetX:offsetY:tileMode:convolveAlpha:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeMatrixTransformMatrix:(TruoraSharedSkikoMatrix33 *)matrix mode:(id<TruoraSharedSkikoSamplingMode>)mode input:(TruoraSharedSkikoImageFilter * _Nullable)input __attribute__((swift_name("makeMatrixTransform(matrix:mode:input:)")));
- (TruoraSharedSkikoImageFilter *)makeMergeFilters:(TruoraSharedKotlinArray<TruoraSharedSkikoImageFilter *> *)filters crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeMerge(filters:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeOffsetDx:(float)dx dy:(float)dy input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeOffset(dx:dy:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makePointLitDiffuseX:(float)x y:(float)y z:(float)z lightColor:(int32_t)lightColor surfaceScale:(float)surfaceScale kd:(float)kd input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makePointLitDiffuse(x:y:z:lightColor:surfaceScale:kd:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makePointLitSpecularX:(float)x y:(float)y z:(float)z lightColor:(int32_t)lightColor surfaceScale:(float)surfaceScale ks:(float)ks shininess:(float)shininess input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makePointLitSpecular(x:y:z:lightColor:surfaceScale:ks:shininess:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeRuntimeShaderRuntimeShaderBuilder:(TruoraSharedSkikoRuntimeShaderBuilder *)runtimeShaderBuilder shaderNames:(TruoraSharedKotlinArray<NSString *> *)shaderNames inputs:(TruoraSharedKotlinArray<TruoraSharedSkikoImageFilter *> *)inputs __attribute__((swift_name("makeRuntimeShader(runtimeShaderBuilder:shaderNames:inputs:)")));
- (TruoraSharedSkikoImageFilter *)makeRuntimeShaderRuntimeShaderBuilder:(TruoraSharedSkikoRuntimeShaderBuilder *)runtimeShaderBuilder shaderName:(NSString *)shaderName input:(TruoraSharedSkikoImageFilter * _Nullable)input __attribute__((swift_name("makeRuntimeShader(runtimeShaderBuilder:shaderName:input:)")));
- (TruoraSharedSkikoImageFilter *)makeShaderShader:(TruoraSharedSkikoShader *)shader dither:(BOOL)dither crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeShader(shader:dither:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeSpotLitDiffuseX0:(float)x0 y0:(float)y0 z0:(float)z0 x1:(float)x1 y1:(float)y1 z1:(float)z1 falloffExponent:(float)falloffExponent cutoffAngle:(float)cutoffAngle lightColor:(int32_t)lightColor surfaceScale:(float)surfaceScale kd:(float)kd input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeSpotLitDiffuse(x0:y0:z0:x1:y1:z1:falloffExponent:cutoffAngle:lightColor:surfaceScale:kd:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeSpotLitSpecularX0:(float)x0 y0:(float)y0 z0:(float)z0 x1:(float)x1 y1:(float)y1 z1:(float)z1 falloffExponent:(float)falloffExponent cutoffAngle:(float)cutoffAngle lightColor:(int32_t)lightColor surfaceScale:(float)surfaceScale ks:(float)ks shininess:(float)shininess input:(TruoraSharedSkikoImageFilter * _Nullable)input crop:(TruoraSharedSkikoIRect * _Nullable)crop __attribute__((swift_name("makeSpotLitSpecular(x0:y0:z0:x1:y1:z1:falloffExponent:cutoffAngle:lightColor:surfaceScale:ks:shininess:input:crop:)")));
- (TruoraSharedSkikoImageFilter *)makeTileSrc:(TruoraSharedSkikoRect *)src dst:(TruoraSharedSkikoRect *)dst input:(TruoraSharedSkikoImageFilter * _Nullable)input __attribute__((swift_name("makeTile(src:dst:input:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoMaskFilter.Companion")))
@interface TruoraSharedSkikoMaskFilterCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoMaskFilterCompanion *shared __attribute__((swift_name("shared")));
- (float)convertRadiusToSigmaRadius:(float)radius __attribute__((swift_name("convertRadiusToSigma(radius:)")));
- (float)convertSigmaToRadiusSigma:(float)sigma __attribute__((swift_name("convertSigmaToRadius(sigma:)")));
- (TruoraSharedSkikoMaskFilter *)makeBlurMode:(TruoraSharedSkikoFilterBlurMode *)mode sigma:(float)sigma respectCTM:(BOOL)respectCTM __attribute__((swift_name("makeBlur(mode:sigma:respectCTM:)")));
- (TruoraSharedSkikoMaskFilter *)makeClipMin:(int32_t)min max:(int32_t)max __attribute__((swift_name("makeClip(min:max:)")));
- (TruoraSharedSkikoMaskFilter *)makeGammaGamma:(float)gamma __attribute__((swift_name("makeGamma(gamma:)")));
- (TruoraSharedSkikoMaskFilter *)makeShaderS:(TruoraSharedSkikoShader * _Nullable)s __attribute__((swift_name("makeShader(s:)")));
- (TruoraSharedSkikoMaskFilter *)makeTableTable:(TruoraSharedKotlinByteArray *)table __attribute__((swift_name("makeTable(table:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathEffect.Companion")))
@interface TruoraSharedSkikoPathEffectCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoPathEffectCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoPathEffect *)makeCornerRadius:(float)radius __attribute__((swift_name("makeCorner(radius:)")));
- (TruoraSharedSkikoPathEffect *)makeDashIntervals:(TruoraSharedKotlinFloatArray *)intervals phase:(float)phase __attribute__((swift_name("makeDash(intervals:phase:)")));
- (TruoraSharedSkikoPathEffect *)makeDiscreteSegLength:(float)segLength dev:(float)dev seed:(int32_t)seed __attribute__((swift_name("makeDiscrete(segLength:dev:seed:)")));
- (TruoraSharedSkikoPathEffect *)makeLine2DWidth:(float)width matrix:(TruoraSharedSkikoMatrix33 *)matrix __attribute__((swift_name("makeLine2D(width:matrix:)")));
- (TruoraSharedSkikoPathEffect *)makePath1DPath:(TruoraSharedSkikoPath *)path advance:(float)advance phase:(float)phase style:(TruoraSharedSkikoPathEffectStyle *)style __attribute__((swift_name("makePath1D(path:advance:phase:style:)")));
- (TruoraSharedSkikoPathEffect *)makePath2DMatrix:(TruoraSharedSkikoMatrix33 *)matrix path:(TruoraSharedSkikoPath *)path __attribute__((swift_name("makePath2D(matrix:path:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoISize")))
@interface TruoraSharedSkikoISize : TruoraSharedBase
@property (class, readonly, getter=companion) TruoraSharedSkikoISizeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)area __attribute__((swift_name("area()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (BOOL)isZero __attribute__((swift_name("isZero()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPoint")))
@interface TruoraSharedSkikoPoint : TruoraSharedBase
- (instancetype)initWithX:(float)x y:(float)y __attribute__((swift_name("init(x:y:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoPointCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (TruoraSharedSkikoPoint *)offsetVec:(TruoraSharedSkikoPoint *)vec __attribute__((swift_name("offset(vec:)")));
- (TruoraSharedSkikoPoint *)offsetDx:(float)dx dy:(float)dy __attribute__((swift_name("offset(dx:dy:)")));
- (TruoraSharedSkikoPoint *)scaleScale:(float)scale __attribute__((swift_name("scale(scale:)")));
- (TruoraSharedSkikoPoint *)scaleSx:(float)sx sy:(float)sy __attribute__((swift_name("scale(sx:sy:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) float x __attribute__((swift_name("x")));
@property (readonly) float y __attribute__((swift_name("y")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoGradientStyle")))
@interface TruoraSharedSkikoGradientStyle : TruoraSharedBase
- (instancetype)initWithTileMode:(TruoraSharedSkikoFilterTileMode *)tileMode isPremul:(BOOL)isPremul localMatrix:(TruoraSharedSkikoMatrix33 * _Nullable)localMatrix __attribute__((swift_name("init(tileMode:isPremul:localMatrix:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoGradientStyleCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (TruoraSharedSkikoGradientStyle *)withLocalMatrix_localMatrix:(TruoraSharedSkikoMatrix33 *)_localMatrix __attribute__((swift_name("withLocalMatrix(_localMatrix:)")));
- (TruoraSharedSkikoGradientStyle *)withPremul_premul:(BOOL)_premul __attribute__((swift_name("withPremul(_premul:)")));
- (TruoraSharedSkikoGradientStyle *)withTileMode_tileMode:(TruoraSharedSkikoFilterTileMode *)_tileMode __attribute__((swift_name("withTileMode(_tileMode:)")));
@property (readonly) BOOL isPremul __attribute__((swift_name("isPremul")));
@property (readonly) TruoraSharedSkikoMatrix33 * _Nullable localMatrix __attribute__((swift_name("localMatrix")));
@property (readonly) TruoraSharedSkikoFilterTileMode *tileMode __attribute__((swift_name("tileMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoMatrix33.Companion")))
@interface TruoraSharedSkikoMatrix33Companion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoMatrix33Companion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoMatrix33 *)makeRotateDeg:(float)deg __attribute__((swift_name("makeRotate(deg:)")));
- (TruoraSharedSkikoMatrix33 *)makeRotateDeg:(float)deg pivot:(TruoraSharedSkikoPoint *)pivot __attribute__((swift_name("makeRotate(deg:pivot:)")));
- (TruoraSharedSkikoMatrix33 *)makeRotateDeg:(float)deg pivotx:(float)pivotx pivoty:(float)pivoty __attribute__((swift_name("makeRotate(deg:pivotx:pivoty:)")));
- (TruoraSharedSkikoMatrix33 *)makeScaleS:(float)s __attribute__((swift_name("makeScale(s:)")));
- (TruoraSharedSkikoMatrix33 *)makeScaleSx:(float)sx sy:(float)sy __attribute__((swift_name("makeScale(sx:sy:)")));
- (TruoraSharedSkikoMatrix33 *)makeSkewSx:(float)sx sy:(float)sy __attribute__((swift_name("makeSkew(sx:sy:)")));
- (TruoraSharedSkikoMatrix33 *)makeTranslateDx:(float)dx dy:(float)dy __attribute__((swift_name("makeTranslate(dx:dy:)")));
@property (readonly) TruoraSharedSkikoMatrix33 *IDENTITY __attribute__((swift_name("IDENTITY")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoMatrix44")))
@interface TruoraSharedSkikoMatrix44 : TruoraSharedBase
- (instancetype)initWithMat:(TruoraSharedKotlinFloatArray *)mat __attribute__((swift_name("init(mat:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoMatrix44Companion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoMatrix33 *)asMatrix33 __attribute__((swift_name("asMatrix33()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedKotlinFloatArray *mat __attribute__((swift_name("mat")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol.Companion")))
@interface TruoraSharedKtor_httpURLProtocolCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKtor_httpURLProtocolCompanion *shared __attribute__((swift_name("shared")));

/**
 * Create an instance by [name] or use already existing instance
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.createOrDefault)
 */
- (TruoraSharedKtor_httpURLProtocol *)createOrDefaultName:(NSString *)name __attribute__((swift_name("createOrDefault(name:)")));

/**
 * HTTP with port 80
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.HTTP)
 */
@property (readonly) TruoraSharedKtor_httpURLProtocol *HTTP __attribute__((swift_name("HTTP")));

/**
 * secure HTTPS with port 443
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.HTTPS)
 */
@property (readonly) TruoraSharedKtor_httpURLProtocol *HTTPS __attribute__((swift_name("HTTPS")));

/**
 * Socks proxy url protocol.
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.SOCKS)
 */
@property (readonly) TruoraSharedKtor_httpURLProtocol *SOCKS __attribute__((swift_name("SOCKS")));

/**
 * Web socket over HTTP on port 80
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.WS)
 */
@property (readonly) TruoraSharedKtor_httpURLProtocol *WS __attribute__((swift_name("WS")));

/**
 * Web socket over secure HTTPS on port 443
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.WSS)
 */
@property (readonly) TruoraSharedKtor_httpURLProtocol *WSS __attribute__((swift_name("WSS")));

/**
 * Protocols by names map
 *
 * [Report a problem](https://ktor.io/feedback/?fqname=io.ktor.http.URLProtocol.Companion.byName)
 */
@property (readonly) NSDictionary<NSString *, TruoraSharedKtor_httpURLProtocol *> *byName __attribute__((swift_name("byName")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol TruoraSharedKotlinx_coroutines_coreParentJob <TruoraSharedKotlinx_coroutines_coreJob>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (TruoraSharedKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol TruoraSharedKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnCompletionDisposableHandle:(id<TruoraSharedKotlinx_coroutines_coreDisposableHandle>)disposableHandle __attribute__((swift_name("disposeOnCompletion(disposableHandle:)")));
- (void)selectInRegistrationPhaseInternalResult:(id _Nullable)internalResult __attribute__((swift_name("selectInRegistrationPhase(internalResult:)")));
- (BOOL)trySelectClauseObject:(id)clauseObject result:(id _Nullable)result __attribute__((swift_name("trySelect(clauseObject:result:)")));
@property (readonly) id<TruoraSharedKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface TruoraSharedKotlinKVariance : TruoraSharedKotlinEnum<TruoraSharedKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) TruoraSharedKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) TruoraSharedKotlinKVariance *out __attribute__((swift_name("out")));
+ (TruoraSharedKotlinArray<TruoraSharedKotlinKVariance *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedKotlinKVariance *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection.Companion")))
@interface TruoraSharedKotlinKTypeProjectionCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKotlinKTypeProjectionCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedKotlinKTypeProjection *)contravariantType:(id<TruoraSharedKotlinKType>)type __attribute__((swift_name("contravariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedKotlinKTypeProjection *)covariantType:(id<TruoraSharedKotlinKType>)type __attribute__((swift_name("covariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedKotlinKTypeProjection *)invariantType:(id<TruoraSharedKotlinKType>)type __attribute__((swift_name("invariant(type:)")));
@property (readonly) TruoraSharedKotlinKTypeProjection *STAR __attribute__((swift_name("STAR")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorMatrix")))
@interface TruoraSharedSkikoColorMatrix : TruoraSharedBase
- (instancetype)initWithMat:(TruoraSharedKotlinFloatArray *)mat __attribute__((swift_name("init(mat:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedKotlinFloatArray *mat __attribute__((swift_name("mat")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoInversionMode")))
@interface TruoraSharedSkikoInversionMode : TruoraSharedKotlinEnum<TruoraSharedSkikoInversionMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoInversionMode *no __attribute__((swift_name("no")));
@property (class, readonly) TruoraSharedSkikoInversionMode *brightness __attribute__((swift_name("brightness")));
@property (class, readonly) TruoraSharedSkikoInversionMode *lightness __attribute__((swift_name("lightness")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoInversionMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoInversionMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoIRect")))
@interface TruoraSharedSkikoIRect : TruoraSharedBase
@property (class, readonly, getter=companion) TruoraSharedSkikoIRectCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (TruoraSharedSkikoIRect * _Nullable)intersectOther:(TruoraSharedSkikoIRect *)other __attribute__((swift_name("intersect(other:)")));
- (TruoraSharedSkikoIRect *)offsetVec:(TruoraSharedSkikoIPoint *)vec __attribute__((swift_name("offset(vec:)")));
- (TruoraSharedSkikoIRect *)offsetDx:(int32_t)dx dy:(int32_t)dy __attribute__((swift_name("offset(dx:dy:)")));
- (TruoraSharedSkikoRect *)toRect __attribute__((swift_name("toRect()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t bottom __attribute__((swift_name("bottom")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) int32_t left __attribute__((swift_name("left")));
@property (readonly) int32_t right __attribute__((swift_name("right")));
@property (readonly) int32_t top __attribute__((swift_name("top")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFilterTileMode")))
@interface TruoraSharedSkikoFilterTileMode : TruoraSharedKotlinEnum<TruoraSharedSkikoFilterTileMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoFilterTileMode *clamp __attribute__((swift_name("clamp")));
@property (class, readonly) TruoraSharedSkikoFilterTileMode *repeat __attribute__((swift_name("repeat")));
@property (class, readonly) TruoraSharedSkikoFilterTileMode *mirror __attribute__((swift_name("mirror")));
@property (class, readonly) TruoraSharedSkikoFilterTileMode *decal __attribute__((swift_name("decal")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoFilterTileMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoFilterTileMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorChannel")))
@interface TruoraSharedSkikoColorChannel : TruoraSharedKotlinEnum<TruoraSharedSkikoColorChannel *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoColorChannel *r __attribute__((swift_name("r")));
@property (class, readonly) TruoraSharedSkikoColorChannel *g __attribute__((swift_name("g")));
@property (class, readonly) TruoraSharedSkikoColorChannel *b __attribute__((swift_name("b")));
@property (class, readonly) TruoraSharedSkikoColorChannel *a __attribute__((swift_name("a")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoColorChannel *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoColorChannel *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("SkikoIHasImageInfo")))
@protocol TruoraSharedSkikoIHasImageInfo
@required
@property (readonly) TruoraSharedSkikoColorAlphaType *alphaType __attribute__((swift_name("alphaType")));
@property (readonly) int32_t bytesPerPixel __attribute__((swift_name("bytesPerPixel")));
@property (readonly) TruoraSharedSkikoColorInfo *colorInfo __attribute__((swift_name("colorInfo")));
@property (readonly) TruoraSharedSkikoColorSpace * _Nullable colorSpace __attribute__((swift_name("colorSpace")));
@property (readonly) TruoraSharedSkikoColorType *colorType __attribute__((swift_name("colorType")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) TruoraSharedSkikoImageInfo *imageInfo __attribute__((swift_name("imageInfo")));
@property (readonly, getter=isEmpty_) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) BOOL isOpaque __attribute__((swift_name("isOpaque")));
@property (readonly) int32_t shiftPerPixel __attribute__((swift_name("shiftPerPixel")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoImage")))
@interface TruoraSharedSkikoImage : TruoraSharedSkikoRefCnt <TruoraSharedSkikoIHasImageInfo>

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoImageCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoData * _Nullable)encodeToDataFormat:(TruoraSharedSkikoEncodedImageFormat *)format quality:(int32_t)quality __attribute__((swift_name("encodeToData(format:quality:)")));
- (TruoraSharedSkikoShader *)makeShaderLocalMatrix:(TruoraSharedSkikoMatrix33 * _Nullable)localMatrix __attribute__((swift_name("makeShader(localMatrix:)")));
- (TruoraSharedSkikoShader *)makeShaderTmx:(TruoraSharedSkikoFilterTileMode *)tmx tmy:(TruoraSharedSkikoFilterTileMode *)tmy localMatrix:(TruoraSharedSkikoMatrix33 * _Nullable)localMatrix __attribute__((swift_name("makeShader(tmx:tmy:localMatrix:)")));
- (TruoraSharedSkikoShader *)makeShaderTmx:(TruoraSharedSkikoFilterTileMode *)tmx tmy:(TruoraSharedSkikoFilterTileMode *)tmy sampling:(id<TruoraSharedSkikoSamplingMode>)sampling localMatrix:(TruoraSharedSkikoMatrix33 * _Nullable)localMatrix __attribute__((swift_name("makeShader(tmx:tmy:sampling:localMatrix:)")));
- (TruoraSharedSkikoPixmap * _Nullable)peekPixels __attribute__((swift_name("peekPixels()")));
- (BOOL)peekPixelsPixmap:(TruoraSharedSkikoPixmap * _Nullable)pixmap __attribute__((swift_name("peekPixels(pixmap:)")));
- (BOOL)readPixelsDst:(TruoraSharedSkikoBitmap *)dst __attribute__((swift_name("readPixels(dst:)")));
- (BOOL)readPixelsContext:(TruoraSharedSkikoDirectContext *)context dst:(TruoraSharedSkikoBitmap *)dst __attribute__((swift_name("readPixels(context:dst:)")));
- (BOOL)readPixelsDst:(TruoraSharedSkikoBitmap *)dst srcX:(int32_t)srcX srcY:(int32_t)srcY __attribute__((swift_name("readPixels(dst:srcX:srcY:)")));
- (BOOL)readPixelsContext:(TruoraSharedSkikoDirectContext *)context dst:(TruoraSharedSkikoBitmap *)dst srcX:(int32_t)srcX srcY:(int32_t)srcY __attribute__((swift_name("readPixels(context:dst:srcX:srcY:)")));
- (BOOL)readPixelsDst:(TruoraSharedSkikoPixmap *)dst srcX:(int32_t)srcX srcY:(int32_t)srcY cache:(BOOL)cache __attribute__((swift_name("readPixels(dst:srcX:srcY:cache:)")));
- (BOOL)readPixelsContext:(TruoraSharedSkikoDirectContext * _Nullable)context dst:(TruoraSharedSkikoBitmap *)dst srcX:(int32_t)srcX srcY:(int32_t)srcY cache:(BOOL)cache __attribute__((swift_name("readPixels(context:dst:srcX:srcY:cache:)")));
- (BOOL)scalePixelsDst:(TruoraSharedSkikoPixmap *)dst samplingMode:(id<TruoraSharedSkikoSamplingMode>)samplingMode cache:(BOOL)cache __attribute__((swift_name("scalePixels(dst:samplingMode:cache:)")));
@property (readonly) TruoraSharedSkikoImageInfo *imageInfo __attribute__((swift_name("imageInfo")));
@end

__attribute__((swift_name("SkikoRect")))
@interface TruoraSharedSkikoRect : TruoraSharedBase
- (instancetype)initWithLeft:(float)left top:(float)top right:(float)right bottom:(float)bottom __attribute__((swift_name("init(left:top:right:bottom:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoRectCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (TruoraSharedSkikoRect *)inflateSpread:(float)spread __attribute__((swift_name("inflate(spread:)")));
- (TruoraSharedSkikoRect * _Nullable)intersectOther:(TruoraSharedSkikoRect *)other __attribute__((swift_name("intersect(other:)")));
- (TruoraSharedSkikoRect *)offsetVec:(TruoraSharedSkikoPoint *)vec __attribute__((swift_name("offset(vec:)")));
- (TruoraSharedSkikoRect *)offsetDx:(float)dx dy:(float)dy __attribute__((swift_name("offset(dx:dy:)")));
- (TruoraSharedSkikoRect *)scaleScale:(float)scale __attribute__((swift_name("scale(scale:)")));
- (TruoraSharedSkikoRect *)scaleSx:(float)sx sy:(float)sy __attribute__((swift_name("scale(sx:sy:)")));
- (TruoraSharedSkikoIRect *)toIRect __attribute__((swift_name("toIRect()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) float bottom __attribute__((swift_name("bottom")));
@property (readonly) float height_ __attribute__((swift_name("height_")));
@property (readonly, getter=isEmpty_) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) float left __attribute__((swift_name("left")));
@property (readonly) float right __attribute__((swift_name("right")));
@property (readonly) float top __attribute__((swift_name("top")));
@property (readonly) float width_ __attribute__((swift_name("width_")));
@end

__attribute__((swift_name("SkikoSamplingMode")))
@protocol TruoraSharedSkikoSamplingMode
@required
- (int64_t)_pack __attribute__((swift_name("_pack()"))) __attribute__((deprecated("Long can't be used because Long is an object in kotlin/js. Consider using _packedInt1 and _packedInt2")));
- (int32_t)_packedInt1 __attribute__((swift_name("_packedInt1()")));
- (int32_t)_packedInt2 __attribute__((swift_name("_packedInt2()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRuntimeShaderBuilder")))
@interface TruoraSharedSkikoRuntimeShaderBuilder : TruoraSharedSkikoManaged
- (instancetype)initWithEffect:(TruoraSharedSkikoRuntimeEffect *)effect __attribute__((swift_name("init(effect:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoRuntimeShaderBuilderCompanion *companion __attribute__((swift_name("companion")));
- (void)childName:(NSString *)name colorFilter:(TruoraSharedSkikoColorFilter *)colorFilter __attribute__((swift_name("child(name:colorFilter:)")));
- (void)childName:(NSString *)name shader:(TruoraSharedSkikoShader *)shader __attribute__((swift_name("child(name:shader:)")));
- (TruoraSharedSkikoShader *)makeShaderLocalMatrix:(TruoraSharedSkikoMatrix33 * _Nullable)localMatrix __attribute__((swift_name("makeShader(localMatrix:)")));
- (void)uniformName:(NSString *)name value:(float)value __attribute__((swift_name("uniform(name:value:)")));
- (void)uniformName:(NSString *)name value_:(TruoraSharedKotlinFloatArray *)value __attribute__((swift_name("uniform(name:value_:)")));
- (void)uniformName:(NSString *)name value__:(int32_t)value __attribute__((swift_name("uniform(name:value__:)")));
- (void)uniformName:(NSString *)name value___:(TruoraSharedSkikoMatrix22 *)value __attribute__((swift_name("uniform(name:value___:)")));
- (void)uniformName:(NSString *)name value____:(TruoraSharedSkikoMatrix33 *)value __attribute__((swift_name("uniform(name:value____:)")));
- (void)uniformName:(NSString *)name value_____:(TruoraSharedSkikoMatrix44 *)value __attribute__((swift_name("uniform(name:value_____:)")));
- (void)uniformName:(NSString *)name value1:(float)value1 value2:(float)value2 __attribute__((swift_name("uniform(name:value1:value2:)")));
- (void)uniformName:(NSString *)name value1:(int32_t)value1 value2_:(int32_t)value2 __attribute__((swift_name("uniform(name:value1:value2_:)")));
- (void)uniformName:(NSString *)name value1:(float)value1 value2:(float)value2 value3:(float)value3 __attribute__((swift_name("uniform(name:value1:value2:value3:)")));
- (void)uniformName:(NSString *)name value1:(int32_t)value1 value2:(int32_t)value2 value3_:(int32_t)value3 __attribute__((swift_name("uniform(name:value1:value2:value3_:)")));
- (void)uniformName:(NSString *)name value1:(float)value1 value2:(float)value2 value3:(float)value3 value4:(float)value4 __attribute__((swift_name("uniform(name:value1:value2:value3:value4:)")));
- (void)uniformName:(NSString *)name value1:(int32_t)value1 value2:(int32_t)value2 value3:(int32_t)value3 value4_:(int32_t)value4 __attribute__((swift_name("uniform(name:value1:value2:value3:value4_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFilterBlurMode")))
@interface TruoraSharedSkikoFilterBlurMode : TruoraSharedKotlinEnum<TruoraSharedSkikoFilterBlurMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoFilterBlurMode *normal __attribute__((swift_name("normal")));
@property (class, readonly) TruoraSharedSkikoFilterBlurMode *solid __attribute__((swift_name("solid")));
@property (class, readonly) TruoraSharedSkikoFilterBlurMode *outer __attribute__((swift_name("outer")));
@property (class, readonly) TruoraSharedSkikoFilterBlurMode *inner __attribute__((swift_name("inner")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoFilterBlurMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoFilterBlurMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("KotlinIterable")))
@protocol TruoraSharedKotlinIterable
@required
- (id<TruoraSharedKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPath")))
@interface TruoraSharedSkikoPath : TruoraSharedSkikoManaged <TruoraSharedKotlinIterable>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoPathCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoPath *)addArcOval:(TruoraSharedSkikoRect *)oval startAngle:(float)startAngle sweepAngle:(float)sweepAngle __attribute__((swift_name("addArc(oval:startAngle:sweepAngle:)")));
- (TruoraSharedSkikoPath *)addCircleX:(float)x y:(float)y radius:(float)radius dir:(TruoraSharedSkikoPathDirection *)dir __attribute__((swift_name("addCircle(x:y:radius:dir:)")));
- (TruoraSharedSkikoPath *)addOvalOval:(TruoraSharedSkikoRect *)oval dir:(TruoraSharedSkikoPathDirection *)dir start:(int32_t)start __attribute__((swift_name("addOval(oval:dir:start:)")));
- (TruoraSharedSkikoPath *)addPathSrc:(TruoraSharedSkikoPath * _Nullable)src extend:(BOOL)extend __attribute__((swift_name("addPath(src:extend:)")));
- (TruoraSharedSkikoPath *)addPathSrc:(TruoraSharedSkikoPath * _Nullable)src matrix:(TruoraSharedSkikoMatrix33 *)matrix extend:(BOOL)extend __attribute__((swift_name("addPath(src:matrix:extend:)")));
- (TruoraSharedSkikoPath *)addPathSrc:(TruoraSharedSkikoPath * _Nullable)src dx:(float)dx dy:(float)dy extend:(BOOL)extend __attribute__((swift_name("addPath(src:dx:dy:extend:)")));
- (TruoraSharedSkikoPath *)addPolyPts:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)pts close:(BOOL)close __attribute__((swift_name("addPoly(pts:close:)")));
- (TruoraSharedSkikoPath *)addPolyPts:(TruoraSharedKotlinFloatArray *)pts close_:(BOOL)close __attribute__((swift_name("addPoly(pts:close_:)")));
- (TruoraSharedSkikoPath *)addRRectRrect:(TruoraSharedSkikoRRect *)rrect dir:(TruoraSharedSkikoPathDirection *)dir start:(int32_t)start __attribute__((swift_name("addRRect(rrect:dir:start:)")));
- (TruoraSharedSkikoPath *)addRectRect:(TruoraSharedSkikoRect *)rect dir:(TruoraSharedSkikoPathDirection *)dir start:(int32_t)start __attribute__((swift_name("addRect(rect:dir:start:)")));
- (TruoraSharedSkikoPath *)arcToOval:(TruoraSharedSkikoRect *)oval startAngle:(float)startAngle sweepAngle:(float)sweepAngle forceMoveTo:(BOOL)forceMoveTo __attribute__((swift_name("arcTo(oval:startAngle:sweepAngle:forceMoveTo:)")));
- (TruoraSharedSkikoPath *)closePath __attribute__((swift_name("closePath()")));
- (TruoraSharedSkikoRect *)computeTightBounds __attribute__((swift_name("computeTightBounds()")));
- (TruoraSharedSkikoPath *)conicToP1:(TruoraSharedSkikoPoint *)p1 p2:(TruoraSharedSkikoPoint *)p2 w:(float)w __attribute__((swift_name("conicTo(p1:p2:w:)")));
- (TruoraSharedSkikoPath *)conicToX1:(float)x1 y1:(float)y1 x2:(float)x2 y2:(float)y2 w:(float)w __attribute__((swift_name("conicTo(x1:y1:x2:y2:w:)")));
- (BOOL)conservativelyContainsRectRect:(TruoraSharedSkikoRect *)rect __attribute__((swift_name("conservativelyContainsRect(rect:)")));
- (BOOL)containsP:(TruoraSharedSkikoPoint *)p __attribute__((swift_name("contains(p:)")));
- (BOOL)containsX:(float)x y:(float)y __attribute__((swift_name("contains(x:y:)")));
- (TruoraSharedSkikoPath *)cubicToP1:(TruoraSharedSkikoPoint *)p1 p2:(TruoraSharedSkikoPoint *)p2 p3:(TruoraSharedSkikoPoint *)p3 __attribute__((swift_name("cubicTo(p1:p2:p3:)")));
- (TruoraSharedSkikoPath *)cubicToX1:(float)x1 y1:(float)y1 x2:(float)x2 y2:(float)y2 x3:(float)x3 y3:(float)y3 __attribute__((swift_name("cubicTo(x1:y1:x2:y2:x3:y3:)")));
- (TruoraSharedSkikoPath *)dump __attribute__((swift_name("dump()")));
- (TruoraSharedSkikoPath *)dumpHex __attribute__((swift_name("dumpHex()")));
- (TruoraSharedSkikoPath *)ellipticalArcToR:(TruoraSharedSkikoPoint *)r xAxisRotate:(float)xAxisRotate arc:(TruoraSharedSkikoPathEllipseArc *)arc direction:(TruoraSharedSkikoPathDirection *)direction xy:(TruoraSharedSkikoPoint *)xy __attribute__((swift_name("ellipticalArcTo(r:xAxisRotate:arc:direction:xy:)")));
- (TruoraSharedSkikoPath *)ellipticalArcToRx:(float)rx ry:(float)ry xAxisRotate:(float)xAxisRotate arc:(TruoraSharedSkikoPathEllipseArc *)arc direction:(TruoraSharedSkikoPathDirection *)direction x:(float)x y:(float)y __attribute__((swift_name("ellipticalArcTo(rx:ry:xAxisRotate:arc:direction:x:y:)")));
- (TruoraSharedSkikoPoint *)getPointIndex:(int32_t)index __attribute__((swift_name("getPoint(index:)")));
- (int32_t)getPointsPoints:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> * _Nullable)points max:(int32_t)max __attribute__((swift_name("getPoints(points:max:)")));
- (int32_t)getVerbsVerbs:(TruoraSharedKotlinArray<TruoraSharedSkikoPathVerb *> * _Nullable)verbs max:(int32_t)max __attribute__((swift_name("getVerbs(verbs:max:)")));
- (TruoraSharedSkikoPath *)incReserveExtraPtCount:(int32_t)extraPtCount __attribute__((swift_name("incReserve(extraPtCount:)")));
- (BOOL)isInterpolatableCompare:(TruoraSharedSkikoPath * _Nullable)compare __attribute__((swift_name("isInterpolatable(compare:)")));
- (TruoraSharedSkikoPathSegmentIterator *)iterator __attribute__((swift_name("iterator()")));
- (TruoraSharedSkikoPathSegmentIterator *)iteratorForceClose:(BOOL)forceClose __attribute__((swift_name("iterator(forceClose:)")));
- (TruoraSharedSkikoPath *)lineToP:(TruoraSharedSkikoPoint *)p __attribute__((swift_name("lineTo(p:)")));
- (TruoraSharedSkikoPath *)lineToX:(float)x y:(float)y __attribute__((swift_name("lineTo(x:y:)")));
- (TruoraSharedSkikoPath *)makeLerpEnding:(TruoraSharedSkikoPath * _Nullable)ending weight:(float)weight __attribute__((swift_name("makeLerp(ending:weight:)")));
- (TruoraSharedSkikoPath *)moveToP:(TruoraSharedSkikoPoint *)p __attribute__((swift_name("moveTo(p:)")));
- (TruoraSharedSkikoPath *)moveToX:(float)x y:(float)y __attribute__((swift_name("moveTo(x:y:)")));
- (TruoraSharedSkikoPath *)offsetDx:(float)dx dy:(float)dy dst:(TruoraSharedSkikoPath * _Nullable)dst __attribute__((swift_name("offset(dx:dy:dst:)")));
- (TruoraSharedSkikoPath *)quadToP1:(TruoraSharedSkikoPoint *)p1 p2:(TruoraSharedSkikoPoint *)p2 __attribute__((swift_name("quadTo(p1:p2:)")));
- (TruoraSharedSkikoPath *)quadToX1:(float)x1 y1:(float)y1 x2:(float)x2 y2:(float)y2 __attribute__((swift_name("quadTo(x1:y1:x2:y2:)")));
- (TruoraSharedSkikoPath *)rConicToDx1:(float)dx1 dy1:(float)dy1 dx2:(float)dx2 dy2:(float)dy2 w:(float)w __attribute__((swift_name("rConicTo(dx1:dy1:dx2:dy2:w:)")));
- (TruoraSharedSkikoPath *)rCubicToDx1:(float)dx1 dy1:(float)dy1 dx2:(float)dx2 dy2:(float)dy2 dx3:(float)dx3 dy3:(float)dy3 __attribute__((swift_name("rCubicTo(dx1:dy1:dx2:dy2:dx3:dy3:)")));
- (TruoraSharedSkikoPath *)rEllipticalArcToRx:(float)rx ry:(float)ry xAxisRotate:(float)xAxisRotate arc:(TruoraSharedSkikoPathEllipseArc *)arc direction:(TruoraSharedSkikoPathDirection *)direction dx:(float)dx dy:(float)dy __attribute__((swift_name("rEllipticalArcTo(rx:ry:xAxisRotate:arc:direction:dx:dy:)")));
- (TruoraSharedSkikoPath *)rLineToDx:(float)dx dy:(float)dy __attribute__((swift_name("rLineTo(dx:dy:)")));
- (TruoraSharedSkikoPath *)rMoveToDx:(float)dx dy:(float)dy __attribute__((swift_name("rMoveTo(dx:dy:)")));
- (TruoraSharedSkikoPath *)rQuadToDx1:(float)dx1 dy1:(float)dy1 dx2:(float)dx2 dy2:(float)dy2 __attribute__((swift_name("rQuadTo(dx1:dy1:dx2:dy2:)")));
- (TruoraSharedSkikoPath *)reset __attribute__((swift_name("reset()")));
- (TruoraSharedSkikoPath *)reverseAddPathSrc:(TruoraSharedSkikoPath * _Nullable)src __attribute__((swift_name("reverseAddPath(src:)")));
- (TruoraSharedSkikoPath *)rewind __attribute__((swift_name("rewind()")));
- (TruoraSharedKotlinByteArray *)serializeToBytes __attribute__((swift_name("serializeToBytes()")));
- (TruoraSharedSkikoPath *)setLastPtX:(float)x y:(float)y __attribute__((swift_name("setLastPt(x:y:)")));
- (TruoraSharedSkikoPath *)setVolatileIsVolatile:(BOOL)isVolatile __attribute__((swift_name("setVolatile(isVolatile:)")));
- (TruoraSharedSkikoPath *)swapOther:(TruoraSharedSkikoPath * _Nullable)other __attribute__((swift_name("swap(other:)")));
- (TruoraSharedSkikoPath *)tangentArcToP1:(TruoraSharedSkikoPoint *)p1 p2:(TruoraSharedSkikoPoint *)p2 radius:(float)radius __attribute__((swift_name("tangentArcTo(p1:p2:radius:)")));
- (TruoraSharedSkikoPath *)tangentArcToX1:(float)x1 y1:(float)y1 x2:(float)x2 y2:(float)y2 radius:(float)radius __attribute__((swift_name("tangentArcTo(x1:y1:x2:y2:radius:)")));
- (TruoraSharedSkikoPath *)transformMatrix:(TruoraSharedSkikoMatrix33 *)matrix applyPerspectiveClip:(BOOL)applyPerspectiveClip __attribute__((swift_name("transform(matrix:applyPerspectiveClip:)")));
- (TruoraSharedSkikoPath *)transformMatrix:(TruoraSharedSkikoMatrix33 *)matrix dst:(TruoraSharedSkikoPath * _Nullable)dst applyPerspectiveClip:(BOOL)applyPerspectiveClip __attribute__((swift_name("transform(matrix:dst:applyPerspectiveClip:)")));
- (TruoraSharedSkikoPath *)updateBoundsCache __attribute__((swift_name("updateBoundsCache()")));
@property (readonly) void * _Nullable approximateBytesUsed __attribute__((swift_name("approximateBytesUsed")));
@property (readonly) TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> * _Nullable asLine __attribute__((swift_name("asLine")));
@property (readonly) TruoraSharedSkikoRect *bounds __attribute__((swift_name("bounds")));
@property TruoraSharedSkikoPathFillMode *fillMode __attribute__((swift_name("fillMode")));
@property (readonly) int32_t generationId __attribute__((swift_name("generationId")));
@property (readonly) BOOL isConvex __attribute__((swift_name("isConvex")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) BOOL isFinite __attribute__((swift_name("isFinite")));
@property (readonly) BOOL isLastContourClosed __attribute__((swift_name("isLastContourClosed")));
@property (readonly) TruoraSharedSkikoRect * _Nullable isOval __attribute__((swift_name("isOval")));
@property (readonly) TruoraSharedSkikoRRect * _Nullable isRRect __attribute__((swift_name("isRRect")));
@property (readonly) TruoraSharedSkikoRect * _Nullable isRect __attribute__((swift_name("isRect")));
@property (readonly) BOOL isValid __attribute__((swift_name("isValid")));
@property BOOL isVolatile __attribute__((swift_name("isVolatile")));
@property TruoraSharedSkikoPoint *lastPt __attribute__((swift_name("lastPt")));
@property (readonly) TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *points __attribute__((swift_name("points")));
@property (readonly) int32_t pointsCount __attribute__((swift_name("pointsCount")));
@property (readonly) int32_t segmentMasks __attribute__((swift_name("segmentMasks")));
@property (readonly) TruoraSharedKotlinArray<TruoraSharedSkikoPathVerb *> *verbs __attribute__((swift_name("verbs")));
@property (readonly) int32_t verbsCount __attribute__((swift_name("verbsCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathEffect.Style")))
@interface TruoraSharedSkikoPathEffectStyle : TruoraSharedKotlinEnum<TruoraSharedSkikoPathEffectStyle *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoPathEffectStyle *translate __attribute__((swift_name("translate")));
@property (class, readonly) TruoraSharedSkikoPathEffectStyle *rotate __attribute__((swift_name("rotate")));
@property (class, readonly) TruoraSharedSkikoPathEffectStyle *morph __attribute__((swift_name("morph")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoPathEffectStyle *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoPathEffectStyle *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoISize.Companion")))
@interface TruoraSharedSkikoISizeCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoISizeCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoISize *)makeW:(int32_t)w h:(int32_t)h __attribute__((swift_name("make(w:h:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoISize *)makeEmpty __attribute__((swift_name("makeEmpty()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPoint.Companion")))
@interface TruoraSharedSkikoPointCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoPointCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedKotlinFloatArray * _Nullable)flattenArrayPts:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> * _Nullable)pts __attribute__((swift_name("flattenArray(pts:)")));
- (TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> * _Nullable)fromArrayPts:(TruoraSharedKotlinFloatArray * _Nullable)pts __attribute__((swift_name("fromArray(pts:)")));
@property (readonly) TruoraSharedSkikoPoint *ZERO __attribute__((swift_name("ZERO")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoGradientStyle.Companion")))
@interface TruoraSharedSkikoGradientStyleCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoGradientStyleCompanion *shared __attribute__((swift_name("shared")));
@property TruoraSharedSkikoGradientStyle *DEFAULT __attribute__((swift_name("DEFAULT")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoMatrix44.Companion")))
@interface TruoraSharedSkikoMatrix44Companion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoMatrix44Companion *shared __attribute__((swift_name("shared")));
@property (readonly) TruoraSharedSkikoMatrix44 *IDENTITY __attribute__((swift_name("IDENTITY")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoIRect.Companion")))
@interface TruoraSharedSkikoIRectCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoIRectCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoIRect *)makeLTRBL:(int32_t)l t:(int32_t)t r:(int32_t)r b:(int32_t)b __attribute__((swift_name("makeLTRB(l:t:r:b:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoIRect *)makeWHW:(int32_t)w h:(int32_t)h __attribute__((swift_name("makeWH(w:h:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoIRect *)makeXYWHL:(int32_t)l t:(int32_t)t w:(int32_t)w h:(int32_t)h __attribute__((swift_name("makeXYWH(l:t:w:h:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoIPoint")))
@interface TruoraSharedSkikoIPoint : TruoraSharedBase
- (instancetype)initWithX:(int32_t)x y:(int32_t)y __attribute__((swift_name("init(x:y:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoIPointCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (TruoraSharedSkikoIPoint *)offsetVec:(TruoraSharedSkikoIPoint *)vec __attribute__((swift_name("offset(vec:)")));
- (TruoraSharedSkikoIPoint *)offsetDx:(int32_t)dx dy:(int32_t)dy __attribute__((swift_name("offset(dx:dy:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) int32_t x __attribute__((swift_name("x")));
@property (readonly) int32_t y __attribute__((swift_name("y")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorAlphaType")))
@interface TruoraSharedSkikoColorAlphaType : TruoraSharedKotlinEnum<TruoraSharedSkikoColorAlphaType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoColorAlphaType *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) TruoraSharedSkikoColorAlphaType *opaque __attribute__((swift_name("opaque")));
@property (class, readonly) TruoraSharedSkikoColorAlphaType *premul __attribute__((swift_name("premul")));
@property (class, readonly) TruoraSharedSkikoColorAlphaType *unpremul __attribute__((swift_name("unpremul")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoColorAlphaType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoColorAlphaType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorInfo")))
@interface TruoraSharedSkikoColorInfo : TruoraSharedBase
- (instancetype)initWithColorType:(TruoraSharedSkikoColorType *)colorType alphaType:(TruoraSharedSkikoColorAlphaType *)alphaType colorSpace:(TruoraSharedSkikoColorSpace * _Nullable)colorSpace __attribute__((swift_name("init(colorType:alphaType:colorSpace:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoColorInfoCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (TruoraSharedSkikoColorInfo *)withAlphaType_alphaType:(TruoraSharedSkikoColorAlphaType *)_alphaType __attribute__((swift_name("withAlphaType(_alphaType:)")));
- (TruoraSharedSkikoColorInfo *)withColorSpace_colorSpace:(TruoraSharedSkikoColorSpace * _Nullable)_colorSpace __attribute__((swift_name("withColorSpace(_colorSpace:)")));
- (TruoraSharedSkikoColorInfo *)withColorType_colorType:(TruoraSharedSkikoColorType *)_colorType __attribute__((swift_name("withColorType(_colorType:)")));
@property (readonly) TruoraSharedSkikoColorAlphaType *alphaType __attribute__((swift_name("alphaType")));
@property (readonly) int32_t bytesPerPixel __attribute__((swift_name("bytesPerPixel")));
@property (readonly) TruoraSharedSkikoColorSpace * _Nullable colorSpace __attribute__((swift_name("colorSpace")));
@property (readonly) TruoraSharedSkikoColorType *colorType __attribute__((swift_name("colorType")));
@property (readonly) BOOL isGammaCloseToSRGB __attribute__((swift_name("isGammaCloseToSRGB")));
@property (readonly) BOOL isOpaque __attribute__((swift_name("isOpaque")));
@property (readonly) int32_t shiftPerPixel __attribute__((swift_name("shiftPerPixel")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorType")))
@interface TruoraSharedSkikoColorType : TruoraSharedKotlinEnum<TruoraSharedSkikoColorType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoColorTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) TruoraSharedSkikoColorType *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) TruoraSharedSkikoColorType *alpha8 __attribute__((swift_name("alpha8")));
@property (class, readonly) TruoraSharedSkikoColorType *rgb565 __attribute__((swift_name("rgb565")));
@property (class, readonly) TruoraSharedSkikoColorType *argb4444 __attribute__((swift_name("argb4444")));
@property (class, readonly) TruoraSharedSkikoColorType *rgba8888 __attribute__((swift_name("rgba8888")));
@property (class, readonly) TruoraSharedSkikoColorType *rgb888x __attribute__((swift_name("rgb888x")));
@property (class, readonly) TruoraSharedSkikoColorType *bgra8888 __attribute__((swift_name("bgra8888")));
@property (class, readonly) TruoraSharedSkikoColorType *rgba1010102 __attribute__((swift_name("rgba1010102")));
@property (class, readonly) TruoraSharedSkikoColorType *bgra1010102 __attribute__((swift_name("bgra1010102")));
@property (class, readonly) TruoraSharedSkikoColorType *rgb101010x __attribute__((swift_name("rgb101010x")));
@property (class, readonly) TruoraSharedSkikoColorType *bgr101010x __attribute__((swift_name("bgr101010x")));
@property (class, readonly) TruoraSharedSkikoColorType *bgr101010xXr __attribute__((swift_name("bgr101010xXr")));
@property (class, readonly) TruoraSharedSkikoColorType *bgra10101010Xr __attribute__((swift_name("bgra10101010Xr")));
@property (class, readonly) TruoraSharedSkikoColorType *rgba10x6 __attribute__((swift_name("rgba10x6")));
@property (class, readonly) TruoraSharedSkikoColorType *gray8 __attribute__((swift_name("gray8")));
@property (class, readonly) TruoraSharedSkikoColorType *rgbaF16norm __attribute__((swift_name("rgbaF16norm")));
@property (class, readonly) TruoraSharedSkikoColorType *rgbaF16 __attribute__((swift_name("rgbaF16")));
@property (class, readonly) TruoraSharedSkikoColorType *rgbaF32 __attribute__((swift_name("rgbaF32")));
@property (class, readonly) TruoraSharedSkikoColorType *r8g8Unorm __attribute__((swift_name("r8g8Unorm")));
@property (class, readonly) TruoraSharedSkikoColorType *a16Float __attribute__((swift_name("a16Float")));
@property (class, readonly) TruoraSharedSkikoColorType *r16g16Float __attribute__((swift_name("r16g16Float")));
@property (class, readonly) TruoraSharedSkikoColorType *a16Unorm __attribute__((swift_name("a16Unorm")));
@property (class, readonly) TruoraSharedSkikoColorType *r16g16Unorm __attribute__((swift_name("r16g16Unorm")));
@property (class, readonly) TruoraSharedSkikoColorType *r16g16b16a16Unorm __attribute__((swift_name("r16g16b16a16Unorm")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoColorType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoColorType *> *entries __attribute__((swift_name("entries")));
- (int64_t)computeOffsetX:(int32_t)x y:(int32_t)y rowBytes:(int64_t)rowBytes __attribute__((swift_name("computeOffset(x:y:rowBytes:)")));
- (float)getAColor:(int8_t)color __attribute__((swift_name("getA(color:)")));
- (float)getAColor_:(int32_t)color __attribute__((swift_name("getA(color_:)")));
- (float)getAColor__:(int16_t)color __attribute__((swift_name("getA(color__:)")));
- (float)getBColor:(int8_t)color __attribute__((swift_name("getB(color:)")));
- (float)getBColor_:(int32_t)color __attribute__((swift_name("getB(color_:)")));
- (float)getBColor__:(int16_t)color __attribute__((swift_name("getB(color__:)")));
- (float)getGColor:(int8_t)color __attribute__((swift_name("getG(color:)")));
- (float)getGColor_:(int32_t)color __attribute__((swift_name("getG(color_:)")));
- (float)getGColor__:(int16_t)color __attribute__((swift_name("getG(color__:)")));
- (float)getRColor:(int8_t)color __attribute__((swift_name("getR(color:)")));
- (float)getRColor_:(int32_t)color __attribute__((swift_name("getR(color_:)")));
- (float)getRColor__:(int16_t)color __attribute__((swift_name("getR(color__:)")));
- (TruoraSharedSkikoColorAlphaType * _Nullable)validateAlphaTypeAlphaType:(TruoraSharedSkikoColorAlphaType *)alphaType __attribute__((swift_name("validateAlphaType(alphaType:)")));
@property (readonly) int32_t bytesPerPixel __attribute__((swift_name("bytesPerPixel")));
@property (readonly) BOOL isAlwaysOpaque __attribute__((swift_name("isAlwaysOpaque")));
@property (readonly) int32_t shiftPerPixel __attribute__((swift_name("shiftPerPixel")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoImageInfo")))
@interface TruoraSharedSkikoImageInfo : TruoraSharedBase
- (instancetype)initWithColorInfo:(TruoraSharedSkikoColorInfo *)colorInfo width:(int32_t)width height:(int32_t)height __attribute__((swift_name("init(colorInfo:width:height:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithWidth:(int32_t)width height:(int32_t)height colorType:(TruoraSharedSkikoColorType *)colorType alphaType:(TruoraSharedSkikoColorAlphaType *)alphaType __attribute__((swift_name("init(width:height:colorType:alphaType:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithWidth:(int32_t)width height:(int32_t)height colorType:(TruoraSharedSkikoColorType *)colorType alphaType:(TruoraSharedSkikoColorAlphaType *)alphaType colorSpace:(TruoraSharedSkikoColorSpace * _Nullable)colorSpace __attribute__((swift_name("init(width:height:colorType:alphaType:colorSpace:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoImageInfoCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)computeByteSizeRowBytes:(int32_t)rowBytes __attribute__((swift_name("computeByteSize(rowBytes:)")));
- (int32_t)computeMinByteSize __attribute__((swift_name("computeMinByteSize()")));
- (int64_t)computeOffsetX:(int32_t)x y:(int32_t)y rowBytes:(int64_t)rowBytes __attribute__((swift_name("computeOffset(x:y:rowBytes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isRowBytesValidRowBytes:(int64_t)rowBytes __attribute__((swift_name("isRowBytesValid(rowBytes:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (TruoraSharedSkikoImageInfo *)withColorAlphaTypeAlphaType:(TruoraSharedSkikoColorAlphaType *)alphaType __attribute__((swift_name("withColorAlphaType(alphaType:)")));
- (TruoraSharedSkikoImageInfo *)withColorInfo_colorInfo:(TruoraSharedSkikoColorInfo *)_colorInfo __attribute__((swift_name("withColorInfo(_colorInfo:)")));
- (TruoraSharedSkikoImageInfo *)withColorSpaceColorSpace:(TruoraSharedSkikoColorSpace *)colorSpace __attribute__((swift_name("withColorSpace(colorSpace:)")));
- (TruoraSharedSkikoImageInfo *)withColorTypeColorType:(TruoraSharedSkikoColorType *)colorType __attribute__((swift_name("withColorType(colorType:)")));
- (TruoraSharedSkikoImageInfo *)withHeight_height:(int32_t)_height __attribute__((swift_name("withHeight(_height:)")));
- (TruoraSharedSkikoImageInfo *)withWidth_width:(int32_t)_width __attribute__((swift_name("withWidth(_width:)")));
- (TruoraSharedSkikoImageInfo *)withWidthHeightWidth:(int32_t)width height:(int32_t)height __attribute__((swift_name("withWidthHeight(width:height:)")));
@property (readonly) TruoraSharedSkikoIRect *bounds __attribute__((swift_name("bounds")));
@property (readonly) int32_t bytesPerPixel __attribute__((swift_name("bytesPerPixel")));
@property (readonly) TruoraSharedSkikoColorAlphaType *colorAlphaType __attribute__((swift_name("colorAlphaType")));
@property (readonly) TruoraSharedSkikoColorInfo *colorInfo __attribute__((swift_name("colorInfo")));
@property (readonly) TruoraSharedSkikoColorSpace * _Nullable colorSpace __attribute__((swift_name("colorSpace")));
@property (readonly) TruoraSharedSkikoColorType *colorType __attribute__((swift_name("colorType")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) BOOL isGammaCloseToSRGB __attribute__((swift_name("isGammaCloseToSRGB")));
@property (readonly) BOOL isOpaque __attribute__((swift_name("isOpaque")));
@property (readonly) int32_t minRowBytes __attribute__((swift_name("minRowBytes")));
@property (readonly) int32_t shiftPerPixel __attribute__((swift_name("shiftPerPixel")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoImage.Companion")))
@interface TruoraSharedSkikoImageCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoImageCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoImage *)adoptTextureFromContext:(TruoraSharedSkikoDirectContext *)context backendTexture:(TruoraSharedSkikoBackendTexture *)backendTexture origin:(TruoraSharedSkikoSurfaceOrigin *)origin colorType:(TruoraSharedSkikoColorType *)colorType __attribute__((swift_name("adoptTextureFrom(context:backendTexture:origin:colorType:)")));
- (TruoraSharedSkikoImage *)makeFromBitmapBitmap:(TruoraSharedSkikoBitmap *)bitmap __attribute__((swift_name("makeFromBitmap(bitmap:)")));
- (TruoraSharedSkikoImage *)makeFromEncodedBytes:(TruoraSharedKotlinByteArray *)bytes __attribute__((swift_name("makeFromEncoded(bytes:)")));
- (TruoraSharedSkikoImage *)makeFromPixmapPixmap:(TruoraSharedSkikoPixmap *)pixmap __attribute__((swift_name("makeFromPixmap(pixmap:)")));
- (TruoraSharedSkikoImage *)makeRasterImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo bytes:(TruoraSharedKotlinByteArray *)bytes rowBytes:(int32_t)rowBytes __attribute__((swift_name("makeRaster(imageInfo:bytes:rowBytes:)")));
- (TruoraSharedSkikoImage *)makeRasterImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo data:(TruoraSharedSkikoData *)data rowBytes:(int32_t)rowBytes __attribute__((swift_name("makeRaster(imageInfo:data:rowBytes:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoData")))
@interface TruoraSharedSkikoData : TruoraSharedSkikoManaged
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoDataCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (TruoraSharedKotlinByteArray *)getBytesOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("getBytes(offset:length:)")));
- (TruoraSharedSkikoData *)makeCopy __attribute__((swift_name("makeCopy()")));
- (TruoraSharedSkikoData *)makeSubsetOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("makeSubset(offset:length:)")));
- (void * _Nullable)writableData __attribute__((swift_name("writableData()")));
@property (readonly) TruoraSharedKotlinByteArray *bytes __attribute__((swift_name("bytes")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoEncodedImageFormat")))
@interface TruoraSharedSkikoEncodedImageFormat : TruoraSharedKotlinEnum<TruoraSharedSkikoEncodedImageFormat *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *bmp __attribute__((swift_name("bmp")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *gif __attribute__((swift_name("gif")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *ico __attribute__((swift_name("ico")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *jpeg __attribute__((swift_name("jpeg")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *png __attribute__((swift_name("png")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *wbmp __attribute__((swift_name("wbmp")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *webp __attribute__((swift_name("webp")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *pkm __attribute__((swift_name("pkm")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *ktx __attribute__((swift_name("ktx")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *astc __attribute__((swift_name("astc")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *dng __attribute__((swift_name("dng")));
@property (class, readonly) TruoraSharedSkikoEncodedImageFormat *heif __attribute__((swift_name("heif")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoEncodedImageFormat *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoEncodedImageFormat *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPixmap")))
@interface TruoraSharedSkikoPixmap : TruoraSharedSkikoManaged
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoPixmapCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)computeByteSize __attribute__((swift_name("computeByteSize()")));
- (BOOL)computeIsOpaque __attribute__((swift_name("computeIsOpaque()")));
- (BOOL)eraseColor:(int32_t)color __attribute__((swift_name("erase(color:)")));
- (BOOL)eraseColor:(int32_t)color subset:(TruoraSharedSkikoIRect *)subset __attribute__((swift_name("erase(color:subset:)")));
- (BOOL)extractSubsetSubsetPtr:(void * _Nullable)subsetPtr area:(TruoraSharedSkikoIRect *)area __attribute__((swift_name("extractSubset(subsetPtr:area:)")));
- (BOOL)extractSubsetSubset:(TruoraSharedSkikoPixmap *)subset area:(TruoraSharedSkikoIRect *)area __attribute__((swift_name("extractSubset(subset:area:)")));
- (void * _Nullable)getAddrX:(int32_t)x y:(int32_t)y __attribute__((swift_name("getAddr(x:y:)")));
- (float)getAlphaFX:(int32_t)x y:(int32_t)y __attribute__((swift_name("getAlphaF(x:y:)")));
- (int32_t)getColorX:(int32_t)x y:(int32_t)y __attribute__((swift_name("getColor(x:y:)")));
- (BOOL)readPixelsPixmap:(TruoraSharedSkikoPixmap * _Nullable)pixmap __attribute__((swift_name("readPixels(pixmap:)")));
- (BOOL)readPixelsInfo:(TruoraSharedSkikoImageInfo *)info addr:(void * _Nullable)addr rowBytes:(int32_t)rowBytes __attribute__((swift_name("readPixels(info:addr:rowBytes:)")));
- (BOOL)readPixelsPixmap:(TruoraSharedSkikoPixmap *)pixmap srcX:(int32_t)srcX srcY:(int32_t)srcY __attribute__((swift_name("readPixels(pixmap:srcX:srcY:)")));
- (BOOL)readPixelsInfo:(TruoraSharedSkikoImageInfo *)info addr:(void * _Nullable)addr rowBytes:(int32_t)rowBytes srcX:(int32_t)srcX srcY:(int32_t)srcY __attribute__((swift_name("readPixels(info:addr:rowBytes:srcX:srcY:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)resetInfo:(TruoraSharedSkikoImageInfo *)info buffer:(TruoraSharedSkikoData *)buffer rowBytes:(int32_t)rowBytes __attribute__((swift_name("reset(info:buffer:rowBytes:)")));
- (void)resetInfo:(TruoraSharedSkikoImageInfo *)info addr:(void * _Nullable)addr rowBytes:(int32_t)rowBytes underlyingMemoryOwner:(TruoraSharedSkikoManaged * _Nullable)underlyingMemoryOwner __attribute__((swift_name("reset(info:addr:rowBytes:underlyingMemoryOwner:)")));
- (BOOL)scalePixelsDstPixmap:(TruoraSharedSkikoPixmap * _Nullable)dstPixmap samplingMode:(id<TruoraSharedSkikoSamplingMode>)samplingMode __attribute__((swift_name("scalePixels(dstPixmap:samplingMode:)")));
- (void)setColorSpaceColorSpace:(TruoraSharedSkikoColorSpace * _Nullable)colorSpace __attribute__((swift_name("setColorSpace(colorSpace:)")));
@property (readonly) void * _Nullable addr __attribute__((swift_name("addr")));
@property (readonly) TruoraSharedSkikoData *buffer __attribute__((swift_name("buffer")));
@property (readonly) TruoraSharedSkikoImageInfo *info __attribute__((swift_name("info")));
@property (readonly) int32_t rowBytes __attribute__((swift_name("rowBytes")));
@property (readonly) int32_t rowBytesAsPixels __attribute__((swift_name("rowBytesAsPixels")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoBitmap")))
@interface TruoraSharedSkikoBitmap : TruoraSharedSkikoManaged <TruoraSharedSkikoIHasImageInfo>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoBitmapCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)doAllocN32PixelsWidth:(int32_t)width height:(int32_t)height opaque:(BOOL)opaque __attribute__((swift_name("doAllocN32Pixels(width:height:opaque:)")));
- (BOOL)doAllocPixels __attribute__((swift_name("doAllocPixels()")));
- (BOOL)doAllocPixelsImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo __attribute__((swift_name("doAllocPixels(imageInfo:)")));
- (BOOL)doAllocPixelsInfo:(TruoraSharedSkikoImageInfo *)info rowBytes:(int32_t)rowBytes __attribute__((swift_name("doAllocPixels(info:rowBytes:)")));
- (BOOL)doAllocPixelsFlagsImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo zeroPixels:(BOOL)zeroPixels __attribute__((swift_name("doAllocPixelsFlags(imageInfo:zeroPixels:)")));
- (int32_t)computeByteSize __attribute__((swift_name("computeByteSize()")));
- (BOOL)computeIsOpaque __attribute__((swift_name("computeIsOpaque()")));
- (BOOL)drawsNothing __attribute__((swift_name("drawsNothing()")));
- (TruoraSharedSkikoBitmap *)eraseColor:(int32_t)color __attribute__((swift_name("erase(color:)")));
- (TruoraSharedSkikoBitmap *)eraseColor:(int32_t)color area:(TruoraSharedSkikoIRect *)area __attribute__((swift_name("erase(color:area:)")));
- (BOOL)extractAlphaDst:(TruoraSharedSkikoBitmap *)dst __attribute__((swift_name("extractAlpha(dst:)")));
- (TruoraSharedSkikoIPoint * _Nullable)extractAlphaDst:(TruoraSharedSkikoBitmap *)dst paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("extractAlpha(dst:paint:)")));
- (BOOL)extractSubsetDst:(TruoraSharedSkikoBitmap *)dst subset:(TruoraSharedSkikoIRect *)subset __attribute__((swift_name("extractSubset(dst:subset:)")));
- (float)getAlphafX:(int32_t)x y:(int32_t)y __attribute__((swift_name("getAlphaf(x:y:)")));
- (int32_t)getColorX:(int32_t)x y:(int32_t)y __attribute__((swift_name("getColor(x:y:)")));
- (BOOL)installPixelsPixels:(TruoraSharedKotlinByteArray * _Nullable)pixels __attribute__((swift_name("installPixels(pixels:)")));
- (BOOL)installPixelsInfo:(TruoraSharedSkikoImageInfo *)info pixels:(TruoraSharedKotlinByteArray * _Nullable)pixels rowBytes:(int32_t)rowBytes __attribute__((swift_name("installPixels(info:pixels:rowBytes:)")));
- (TruoraSharedSkikoBitmap *)makeClone __attribute__((swift_name("makeClone()")));
- (TruoraSharedSkikoShader *)makeShaderLocalMatrix:(TruoraSharedSkikoMatrix33 * _Nullable)localMatrix __attribute__((swift_name("makeShader(localMatrix:)")));
- (TruoraSharedSkikoShader *)makeShaderTmx:(TruoraSharedSkikoFilterTileMode *)tmx tmy:(TruoraSharedSkikoFilterTileMode *)tmy localMatrix:(TruoraSharedSkikoMatrix33 * _Nullable)localMatrix __attribute__((swift_name("makeShader(tmx:tmy:localMatrix:)")));
- (TruoraSharedSkikoShader *)makeShaderTmx:(TruoraSharedSkikoFilterTileMode *)tmx tmy:(TruoraSharedSkikoFilterTileMode *)tmy sampling:(id<TruoraSharedSkikoSamplingMode>)sampling localMatrix:(TruoraSharedSkikoMatrix33 * _Nullable)localMatrix __attribute__((swift_name("makeShader(tmx:tmy:sampling:localMatrix:)")));
- (TruoraSharedSkikoBitmap *)notifyPixelsChanged __attribute__((swift_name("notifyPixelsChanged()")));
- (TruoraSharedSkikoPixmap * _Nullable)peekPixels __attribute__((swift_name("peekPixels()")));
- (TruoraSharedKotlinByteArray * _Nullable)readPixelsDstInfo:(TruoraSharedSkikoImageInfo *)dstInfo dstRowBytes:(int32_t)dstRowBytes srcX:(int32_t)srcX srcY:(int32_t)srcY __attribute__((swift_name("readPixels(dstInfo:dstRowBytes:srcX:srcY:)")));
- (TruoraSharedSkikoBitmap *)reset __attribute__((swift_name("reset()")));
- (BOOL)setAlphaTypeAlphaType:(TruoraSharedSkikoColorAlphaType *)alphaType __attribute__((swift_name("setAlphaType(alphaType:)")));
- (BOOL)setImageInfoImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo __attribute__((swift_name("setImageInfo(imageInfo:)")));
- (BOOL)setImageInfoImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo rowBytes:(int32_t)rowBytes __attribute__((swift_name("setImageInfo(imageInfo:rowBytes:)")));
- (TruoraSharedSkikoBitmap *)setImmutable __attribute__((swift_name("setImmutable()")));
- (TruoraSharedSkikoBitmap *)setPixelRefPixelRef:(TruoraSharedSkikoPixelRef * _Nullable)pixelRef dx:(int32_t)dx dy:(int32_t)dy __attribute__((swift_name("setPixelRef(pixelRef:dx:dy:)")));
- (void)swapOther:(TruoraSharedSkikoBitmap *)other __attribute__((swift_name("swap(other:)")));
@property (readonly) TruoraSharedSkikoIRect *bounds __attribute__((swift_name("bounds")));
@property (readonly) int32_t generationId __attribute__((swift_name("generationId")));
@property (readonly) TruoraSharedSkikoImageInfo *imageInfo __attribute__((swift_name("imageInfo")));
@property (readonly) BOOL isImmutable __attribute__((swift_name("isImmutable")));
@property (readonly) BOOL isNull __attribute__((swift_name("isNull")));
@property (readonly) BOOL isReadyToDraw __attribute__((swift_name("isReadyToDraw")));
@property (readonly) TruoraSharedSkikoPixelRef * _Nullable pixelRef __attribute__((swift_name("pixelRef")));
@property (readonly) TruoraSharedSkikoIPoint *pixelRefOrigin __attribute__((swift_name("pixelRefOrigin")));
@property (readonly) int32_t rowBytes __attribute__((swift_name("rowBytes")));
@property (readonly) int32_t rowBytesAsPixels __attribute__((swift_name("rowBytesAsPixels")));
@property (readonly) TruoraSharedSkikoIRect *subset __attribute__((swift_name("subset")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoDirectContext")))
@interface TruoraSharedSkikoDirectContext : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoDirectContextCompanion *companion __attribute__((swift_name("companion")));
- (void)abandon __attribute__((swift_name("abandon()")));
- (TruoraSharedSkikoDirectContext *)flush __attribute__((swift_name("flush()")));
- (TruoraSharedSkikoDirectContext *)flushSurface:(TruoraSharedSkikoSurface *)surface __attribute__((swift_name("flush(surface:)")));
- (void)flushAndSubmitSurface:(TruoraSharedSkikoSurface *)surface syncCpu:(BOOL)syncCpu __attribute__((swift_name("flushAndSubmit(surface:syncCpu:)")));
- (TruoraSharedSkikoDirectContext *)resetAll __attribute__((swift_name("resetAll()")));
- (TruoraSharedSkikoDirectContext *)resetGLStates:(TruoraSharedKotlinArray<TruoraSharedSkikoGLBackendState *> *)states __attribute__((swift_name("resetGL(states:)")));
- (TruoraSharedSkikoDirectContext *)resetGLAll __attribute__((swift_name("resetGLAll()")));
- (void)submitSyncCpu:(BOOL)syncCpu __attribute__((swift_name("submit(syncCpu:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRect.Companion")))
@interface TruoraSharedSkikoRectCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoRectCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoRect *)makeLTRBL:(float)l t:(float)t r:(float)r b:(float)b __attribute__((swift_name("makeLTRB(l:t:r:b:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoRect *)makeWHSize:(TruoraSharedSkikoPoint *)size __attribute__((swift_name("makeWH(size:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoRect *)makeWHW:(float)w h:(float)h __attribute__((swift_name("makeWH(w:h:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoRect *)makeXYWHL:(float)l t:(float)t w:(float)w h:(float)h __attribute__((swift_name("makeXYWH(l:t:w:h:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRuntimeEffect")))
@interface TruoraSharedSkikoRuntimeEffect : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoRuntimeEffectCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoShader *)makeShaderUniforms:(TruoraSharedSkikoData * _Nullable)uniforms children:(TruoraSharedKotlinArray<TruoraSharedSkikoShader *> * _Nullable)children localMatrix:(TruoraSharedSkikoMatrix33 * _Nullable)localMatrix __attribute__((swift_name("makeShader(uniforms:children:localMatrix:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRuntimeShaderBuilder.Companion")))
@interface TruoraSharedSkikoRuntimeShaderBuilderCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoRuntimeShaderBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoMatrix22")))
@interface TruoraSharedSkikoMatrix22 : TruoraSharedBase
- (instancetype)initWithMat:(TruoraSharedKotlinFloatArray *)mat __attribute__((swift_name("init(mat:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoMatrix22Companion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedKotlinFloatArray *mat __attribute__((swift_name("mat")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPath.Companion")))
@interface TruoraSharedSkikoPathCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoPathCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)convertConicToQuadsP0:(TruoraSharedSkikoPoint *)p0 p1:(TruoraSharedSkikoPoint *)p1 p2:(TruoraSharedSkikoPoint *)p2 w:(float)w pow2:(int32_t)pow2 __attribute__((swift_name("convertConicToQuads(p0:p1:p2:w:pow2:)")));
- (BOOL)isCubicDegenerateP1:(TruoraSharedSkikoPoint *)p1 p2:(TruoraSharedSkikoPoint *)p2 p3:(TruoraSharedSkikoPoint *)p3 p4:(TruoraSharedSkikoPoint *)p4 exact:(BOOL)exact __attribute__((swift_name("isCubicDegenerate(p1:p2:p3:p4:exact:)")));
- (BOOL)isLineDegenerateP1:(TruoraSharedSkikoPoint *)p1 p2:(TruoraSharedSkikoPoint *)p2 exact:(BOOL)exact __attribute__((swift_name("isLineDegenerate(p1:p2:exact:)")));
- (BOOL)isQuadDegenerateP1:(TruoraSharedSkikoPoint *)p1 p2:(TruoraSharedSkikoPoint *)p2 p3:(TruoraSharedSkikoPoint *)p3 exact:(BOOL)exact __attribute__((swift_name("isQuadDegenerate(p1:p2:p3:exact:)")));
- (TruoraSharedSkikoPath * _Nullable)makeCombiningOne:(TruoraSharedSkikoPath *)one two:(TruoraSharedSkikoPath *)two op:(TruoraSharedSkikoPathOp *)op __attribute__((swift_name("makeCombining(one:two:op:)")));
- (TruoraSharedSkikoPath *)makeFromBytesData:(TruoraSharedKotlinByteArray *)data __attribute__((swift_name("makeFromBytes(data:)")));
- (TruoraSharedSkikoPath *)makeFromSVGStringSvg:(NSString *)svg __attribute__((swift_name("makeFromSVGString(svg:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathDirection")))
@interface TruoraSharedSkikoPathDirection : TruoraSharedKotlinEnum<TruoraSharedSkikoPathDirection *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoPathDirection *clockwise __attribute__((swift_name("clockwise")));
@property (class, readonly) TruoraSharedSkikoPathDirection *counterClockwise __attribute__((swift_name("counterClockwise")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoPathDirection *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoPathDirection *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRRect")))
@interface TruoraSharedSkikoRRect : TruoraSharedSkikoRect
- (instancetype)initWithLeft:(float)left top:(float)top right:(float)right bottom:(float)bottom __attribute__((swift_name("init(left:top:right:bottom:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoRRectCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (TruoraSharedSkikoRect *)inflateSpread:(float)spread __attribute__((swift_name("inflate(spread:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedKotlinFloatArray *radii __attribute__((swift_name("radii")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathEllipseArc")))
@interface TruoraSharedSkikoPathEllipseArc : TruoraSharedKotlinEnum<TruoraSharedSkikoPathEllipseArc *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoPathEllipseArc *smaller __attribute__((swift_name("smaller")));
@property (class, readonly) TruoraSharedSkikoPathEllipseArc *larger __attribute__((swift_name("larger")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoPathEllipseArc *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoPathEllipseArc *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathVerb")))
@interface TruoraSharedSkikoPathVerb : TruoraSharedKotlinEnum<TruoraSharedSkikoPathVerb *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoPathVerb *move __attribute__((swift_name("move")));
@property (class, readonly) TruoraSharedSkikoPathVerb *line __attribute__((swift_name("line")));
@property (class, readonly) TruoraSharedSkikoPathVerb *quad __attribute__((swift_name("quad")));
@property (class, readonly) TruoraSharedSkikoPathVerb *conic __attribute__((swift_name("conic")));
@property (class, readonly) TruoraSharedSkikoPathVerb *cubic __attribute__((swift_name("cubic")));
@property (class, readonly) TruoraSharedSkikoPathVerb *close __attribute__((swift_name("close")));
@property (class, readonly) TruoraSharedSkikoPathVerb *done __attribute__((swift_name("done")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoPathVerb *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoPathVerb *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("KotlinMutableIterator")))
@protocol TruoraSharedKotlinMutableIterator <TruoraSharedKotlinIterator>
@required
- (void)remove __attribute__((swift_name("remove()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathSegmentIterator")))
@interface TruoraSharedSkikoPathSegmentIterator : TruoraSharedSkikoManaged <TruoraSharedKotlinMutableIterator>
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoPathSegmentIteratorCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (TruoraSharedSkikoPathSegment * _Nullable)next __attribute__((swift_name("next()")));
- (void)remove __attribute__((swift_name("remove()")));
@property TruoraSharedSkikoPathSegment * _Nullable _nextSegment __attribute__((swift_name("_nextSegment")));
@property (readonly) TruoraSharedSkikoPath * _Nullable _path __attribute__((swift_name("_path")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathFillMode")))
@interface TruoraSharedSkikoPathFillMode : TruoraSharedKotlinEnum<TruoraSharedSkikoPathFillMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoPathFillMode *winding __attribute__((swift_name("winding")));
@property (class, readonly) TruoraSharedSkikoPathFillMode *evenOdd __attribute__((swift_name("evenOdd")));
@property (class, readonly) TruoraSharedSkikoPathFillMode *inverseWinding __attribute__((swift_name("inverseWinding")));
@property (class, readonly) TruoraSharedSkikoPathFillMode *inverseEvenOdd __attribute__((swift_name("inverseEvenOdd")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoPathFillMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoPathFillMode *> *entries __attribute__((swift_name("entries")));
- (TruoraSharedSkikoPathFillMode *)inverse __attribute__((swift_name("inverse()")));
@property (readonly) BOOL isInverse __attribute__((swift_name("isInverse")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoIPoint.Companion")))
@interface TruoraSharedSkikoIPointCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoIPointCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) TruoraSharedSkikoIPoint *ZERO __attribute__((swift_name("ZERO")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorInfo.Companion")))
@interface TruoraSharedSkikoColorInfoCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoColorInfoCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) TruoraSharedSkikoColorInfo *DEFAULT __attribute__((swift_name("DEFAULT")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoColorType.Companion")))
@interface TruoraSharedSkikoColorTypeCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoColorTypeCompanion *shared __attribute__((swift_name("shared")));
@property TruoraSharedSkikoColorType *N32 __attribute__((swift_name("N32")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoImageInfo.Companion")))
@interface TruoraSharedSkikoImageInfoCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoImageInfoCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoImageInfo *)createUsing_ptr:(void * _Nullable)_ptr _nGetImageInfo:(void (^)(id _Nullable, id _Nullable, id _Nullable))_nGetImageInfo __attribute__((swift_name("createUsing(_ptr:_nGetImageInfo:)")));
- (TruoraSharedSkikoImageInfo *)makeA8Width:(int32_t)width height:(int32_t)height __attribute__((swift_name("makeA8(width:height:)")));
- (TruoraSharedSkikoImageInfo *)makeN32Width:(int32_t)width height:(int32_t)height alphaType:(TruoraSharedSkikoColorAlphaType *)alphaType __attribute__((swift_name("makeN32(width:height:alphaType:)")));
- (TruoraSharedSkikoImageInfo *)makeN32Width:(int32_t)width height:(int32_t)height alphaType:(TruoraSharedSkikoColorAlphaType *)alphaType colorSpace:(TruoraSharedSkikoColorSpace * _Nullable)colorSpace __attribute__((swift_name("makeN32(width:height:alphaType:colorSpace:)")));
- (TruoraSharedSkikoImageInfo *)makeN32PremulWidth:(int32_t)width height:(int32_t)height __attribute__((swift_name("makeN32Premul(width:height:)")));
- (TruoraSharedSkikoImageInfo *)makeN32PremulWidth:(int32_t)width height:(int32_t)height colorSpace:(TruoraSharedSkikoColorSpace * _Nullable)colorSpace __attribute__((swift_name("makeN32Premul(width:height:colorSpace:)")));
- (TruoraSharedSkikoImageInfo *)makeS32Width:(int32_t)width height:(int32_t)height alphaType:(TruoraSharedSkikoColorAlphaType *)alphaType __attribute__((swift_name("makeS32(width:height:alphaType:)")));
- (TruoraSharedSkikoImageInfo *)makeUnknownWidth:(int32_t)width height:(int32_t)height __attribute__((swift_name("makeUnknown(width:height:)")));
@property (readonly) TruoraSharedSkikoImageInfo *DEFAULT __attribute__((swift_name("DEFAULT")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoBackendTexture")))
@interface TruoraSharedSkikoBackendTexture : TruoraSharedSkikoManaged
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoBackendTextureCompanion *companion __attribute__((swift_name("companion")));
- (void)glTextureParametersModified __attribute__((swift_name("glTextureParametersModified()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoSurfaceOrigin")))
@interface TruoraSharedSkikoSurfaceOrigin : TruoraSharedKotlinEnum<TruoraSharedSkikoSurfaceOrigin *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoSurfaceOrigin *topLeft __attribute__((swift_name("topLeft")));
@property (class, readonly) TruoraSharedSkikoSurfaceOrigin *bottomLeft __attribute__((swift_name("bottomLeft")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoSurfaceOrigin *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoSurfaceOrigin *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoData.Companion")))
@interface TruoraSharedSkikoDataCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoDataCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoData *)makeEmpty __attribute__((swift_name("makeEmpty()")));
- (TruoraSharedSkikoData *)makeFromBytesBytes:(TruoraSharedKotlinByteArray *)bytes offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("makeFromBytes(bytes:offset:length:)")));
- (TruoraSharedSkikoData *)makeUninitializedLength:(int32_t)length __attribute__((swift_name("makeUninitialized(length:)")));
- (TruoraSharedSkikoData *)makeWithoutCopyMemoryAddr:(void * _Nullable)memoryAddr length:(int32_t)length underlyingMemoryOwner:(TruoraSharedSkikoManaged *)underlyingMemoryOwner __attribute__((swift_name("makeWithoutCopy(memoryAddr:length:underlyingMemoryOwner:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPixmap.Companion")))
@interface TruoraSharedSkikoPixmapCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoPixmapCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoPixmap *)makeInfo:(TruoraSharedSkikoImageInfo *)info buffer:(TruoraSharedSkikoData *)buffer rowBytes:(int32_t)rowBytes __attribute__((swift_name("make(info:buffer:rowBytes:)")));
- (TruoraSharedSkikoPixmap *)makeInfo:(TruoraSharedSkikoImageInfo *)info addr:(void * _Nullable)addr rowBytes:(int32_t)rowBytes underlyingMemoryOwner:(TruoraSharedSkikoManaged * _Nullable)underlyingMemoryOwner __attribute__((swift_name("make(info:addr:rowBytes:underlyingMemoryOwner:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoBitmap.Companion")))
@interface TruoraSharedSkikoBitmapCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoBitmapCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoBitmap *)makeFromImageImage:(TruoraSharedSkikoImage *)image __attribute__((swift_name("makeFromImage(image:)")));
- (TruoraSharedSkikoBitmap *)makeFromImageImage:(TruoraSharedSkikoImage *)image context:(TruoraSharedSkikoDirectContext *)context __attribute__((swift_name("makeFromImage(image:context:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPixelRef")))
@interface TruoraSharedSkikoPixelRef : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoPixelRefCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoPixelRef *)notifyPixelsChanged __attribute__((swift_name("notifyPixelsChanged()")));
- (TruoraSharedSkikoPixelRef *)setImmutable __attribute__((swift_name("setImmutable()")));
@property (readonly) int32_t generationId __attribute__((swift_name("generationId")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) BOOL isImmutable __attribute__((swift_name("isImmutable")));
@property (readonly) void * _Nullable rowBytes __attribute__((swift_name("rowBytes")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoDirectContext.Companion")))
@interface TruoraSharedSkikoDirectContextCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoDirectContextCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoDirectContext *)makeDirect3DAdapterPtr:(void * _Nullable)adapterPtr devicePtr:(void * _Nullable)devicePtr queuePtr:(void * _Nullable)queuePtr __attribute__((swift_name("makeDirect3D(adapterPtr:devicePtr:queuePtr:)")));
- (TruoraSharedSkikoDirectContext *)makeGL __attribute__((swift_name("makeGL()")));
- (TruoraSharedSkikoDirectContext *)makeMetalDevicePtr:(void * _Nullable)devicePtr queuePtr:(void * _Nullable)queuePtr __attribute__((swift_name("makeMetal(devicePtr:queuePtr:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoSurface")))
@interface TruoraSharedSkikoSurface : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoSurfaceCompanion *companion __attribute__((swift_name("companion")));
- (void)drawCanvas:(TruoraSharedSkikoCanvas * _Nullable)canvas x:(int32_t)x y:(int32_t)y paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("draw(canvas:x:y:paint:)")));
- (void)drawCanvas:(TruoraSharedSkikoCanvas * _Nullable)canvas x:(int32_t)x y:(int32_t)y samplingMode:(id<TruoraSharedSkikoSamplingMode>)samplingMode paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("draw(canvas:x:y:samplingMode:paint:)")));
- (void)flush __attribute__((swift_name("flush()")));
- (void)flushAndSubmit __attribute__((swift_name("flushAndSubmit()")));
- (void)flushAndSubmitSyncCpu:(BOOL)syncCpu __attribute__((swift_name("flushAndSubmit(syncCpu:)")));
- (TruoraSharedSkikoImage *)makeImageSnapshot __attribute__((swift_name("makeImageSnapshot()")));
- (TruoraSharedSkikoImage * _Nullable)makeImageSnapshotArea:(TruoraSharedSkikoIRect *)area __attribute__((swift_name("makeImageSnapshot(area:)")));
- (TruoraSharedSkikoSurface * _Nullable)makeSurfaceImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo __attribute__((swift_name("makeSurface(imageInfo:)")));
- (TruoraSharedSkikoSurface * _Nullable)makeSurfaceWidth:(int32_t)width height:(int32_t)height __attribute__((swift_name("makeSurface(width:height:)")));
- (void)notifyContentWillChangeMode:(TruoraSharedSkikoContentChangeMode *)mode __attribute__((swift_name("notifyContentWillChange(mode:)")));
- (BOOL)peekPixelsPixmap:(TruoraSharedSkikoPixmap *)pixmap __attribute__((swift_name("peekPixels(pixmap:)")));
- (BOOL)readPixelsBitmap:(TruoraSharedSkikoBitmap * _Nullable)bitmap srcX:(int32_t)srcX srcY:(int32_t)srcY __attribute__((swift_name("readPixels(bitmap:srcX:srcY:)")));
- (BOOL)readPixelsPixmap:(TruoraSharedSkikoPixmap * _Nullable)pixmap srcX:(int32_t)srcX srcY:(int32_t)srcY __attribute__((swift_name("readPixels(pixmap:srcX:srcY:)")));
- (void)writePixelsBitmap:(TruoraSharedSkikoBitmap * _Nullable)bitmap x:(int32_t)x y:(int32_t)y __attribute__((swift_name("writePixels(bitmap:x:y:)")));
- (void)writePixelsPixmap:(TruoraSharedSkikoPixmap * _Nullable)pixmap x:(int32_t)x y:(int32_t)y __attribute__((swift_name("writePixels(pixmap:x:y:)")));
@property (readonly) TruoraSharedSkikoCanvas *canvas __attribute__((swift_name("canvas")));
@property (readonly) int32_t generationId __attribute__((swift_name("generationId")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) TruoraSharedSkikoImageInfo *imageInfo __attribute__((swift_name("imageInfo")));
@property (readonly) BOOL isUnique __attribute__((swift_name("isUnique")));
@property (readonly) TruoraSharedSkikoDirectContext * _Nullable recordingContext __attribute__((swift_name("recordingContext")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoGLBackendState")))
@interface TruoraSharedSkikoGLBackendState : TruoraSharedKotlinEnum<TruoraSharedSkikoGLBackendState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoGLBackendState *renderTarget __attribute__((swift_name("renderTarget")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *textureBinding __attribute__((swift_name("textureBinding")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *view __attribute__((swift_name("view")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *blend __attribute__((swift_name("blend")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *msaaEnable __attribute__((swift_name("msaaEnable")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *vertex __attribute__((swift_name("vertex")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *stencil __attribute__((swift_name("stencil")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *pixelStore __attribute__((swift_name("pixelStore")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *program __attribute__((swift_name("program")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *fixedFunction __attribute__((swift_name("fixedFunction")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *misc __attribute__((swift_name("misc")));
@property (class, readonly) TruoraSharedSkikoGLBackendState *pathRendering __attribute__((swift_name("pathRendering")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoGLBackendState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoGLBackendState *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRuntimeEffect.Companion")))
@interface TruoraSharedSkikoRuntimeEffectCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoRuntimeEffectCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoRuntimeEffect *)makeForColorFilterSksl:(NSString *)sksl __attribute__((swift_name("makeForColorFilter(sksl:)")));
- (TruoraSharedSkikoRuntimeEffect *)makeForShaderSksl:(NSString *)sksl __attribute__((swift_name("makeForShader(sksl:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoMatrix22.Companion")))
@interface TruoraSharedSkikoMatrix22Companion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoMatrix22Companion *shared __attribute__((swift_name("shared")));
@property (readonly) TruoraSharedSkikoMatrix22 *IDENTITY __attribute__((swift_name("IDENTITY")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathOp")))
@interface TruoraSharedSkikoPathOp : TruoraSharedKotlinEnum<TruoraSharedSkikoPathOp *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoPathOp *difference __attribute__((swift_name("difference")));
@property (class, readonly) TruoraSharedSkikoPathOp *intersect __attribute__((swift_name("intersect")));
@property (class, readonly) TruoraSharedSkikoPathOp *union_ __attribute__((swift_name("union_")));
@property (class, readonly) TruoraSharedSkikoPathOp *xor_ __attribute__((swift_name("xor_")));
@property (class, readonly) TruoraSharedSkikoPathOp *reverseDifference __attribute__((swift_name("reverseDifference")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoPathOp *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoPathOp *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRRect.Companion")))
@interface TruoraSharedSkikoRRectCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoRRectCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoRRect *)makeComplexLTRBL:(float)l t:(float)t r:(float)r b:(float)b radii:(TruoraSharedKotlinFloatArray *)radii __attribute__((swift_name("makeComplexLTRB(l:t:r:b:radii:)")));
- (TruoraSharedSkikoRRect *)makeComplexXYWHL:(float)l t:(float)t w:(float)w h:(float)h radii:(TruoraSharedKotlinFloatArray *)radii __attribute__((swift_name("makeComplexXYWH(l:t:w:h:radii:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoRRect *)makeLTRBL:(float)l t:(float)t r:(float)r b:(float)b radius:(float)radius __attribute__((swift_name("makeLTRB(l:t:r:b:radius:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoRRect *)makeLTRBL:(float)l t:(float)t r:(float)r b:(float)b xRad:(float)xRad yRad:(float)yRad __attribute__((swift_name("makeLTRB(l:t:r:b:xRad:yRad:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoRRect *)makeLTRBL:(float)l t:(float)t r:(float)r b:(float)b tlRad:(float)tlRad trRad:(float)trRad brRad:(float)brRad blRad:(float)blRad __attribute__((swift_name("makeLTRB(l:t:r:b:tlRad:trRad:brRad:blRad:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (TruoraSharedSkikoRRect *)makeNinePatchLTRBL:(float)l t:(float)t r:(float)r b:(float)b lRad:(float)lRad tRad:(float)tRad rRad:(float)rRad bRad:(float)bRad __attribute__((swift_name("makeNinePatchLTRB(l:t:r:b:lRad:tRad:rRad:bRad:)")));
- (TruoraSharedSkikoRRect *)makeNinePatchXYWHL:(float)l t:(float)t w:(float)w h:(float)h lRad:(float)lRad tRad:(float)tRad rRad:(float)rRad bRad:(float)bRad __attribute__((swift_name("makeNinePatchXYWH(l:t:w:h:lRad:tRad:rRad:bRad:)")));
- (TruoraSharedSkikoRRect *)makeOvalLTRBL:(float)l t:(float)t r:(float)r b:(float)b __attribute__((swift_name("makeOvalLTRB(l:t:r:b:)")));
- (TruoraSharedSkikoRRect *)makeOvalXYWHL:(float)l t:(float)t w:(float)w h:(float)h __attribute__((swift_name("makeOvalXYWH(l:t:w:h:)")));
- (TruoraSharedSkikoRRect *)makePillLTRBL:(float)l t:(float)t r:(float)r b:(float)b __attribute__((swift_name("makePillLTRB(l:t:r:b:)")));
- (TruoraSharedSkikoRRect *)makePillXYWHL:(float)l t:(float)t w:(float)w h:(float)h __attribute__((swift_name("makePillXYWH(l:t:w:h:)")));
- (TruoraSharedSkikoRRect *)makeXYWHL:(float)l t:(float)t w:(float)w h:(float)h radius:(float)radius __attribute__((swift_name("makeXYWH(l:t:w:h:radius:)")));
- (TruoraSharedSkikoRRect *)makeXYWHL:(float)l t:(float)t w:(float)w h:(float)h xRad:(float)xRad yRad:(float)yRad __attribute__((swift_name("makeXYWH(l:t:w:h:xRad:yRad:)")));
- (TruoraSharedSkikoRRect *)makeXYWHL:(float)l t:(float)t w:(float)w h:(float)h tlRad:(float)tlRad trRad:(float)trRad brRad:(float)brRad blRad:(float)blRad __attribute__((swift_name("makeXYWH(l:t:w:h:tlRad:trRad:brRad:blRad:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathSegmentIterator.Companion")))
@interface TruoraSharedSkikoPathSegmentIteratorCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoPathSegmentIteratorCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoPathSegmentIterator *)makePath:(TruoraSharedSkikoPath * _Nullable)path forceClose:(BOOL)forceClose __attribute__((swift_name("make(path:forceClose:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPathSegment")))
@interface TruoraSharedSkikoPathSegment : TruoraSharedBase
- (instancetype)initWithVerbOrdinal:(int32_t)verbOrdinal x0:(float)x0 y0:(float)y0 isClosedContour:(BOOL)isClosedContour __attribute__((swift_name("init(verbOrdinal:x0:y0:isClosedContour:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithX0:(float)x0 y0:(float)y0 x1:(float)x1 y1:(float)y1 isCloseLine:(BOOL)isCloseLine isClosedContour:(BOOL)isClosedContour __attribute__((swift_name("init(x0:y0:x1:y1:isCloseLine:isClosedContour:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithX0:(float)x0 y0:(float)y0 x1:(float)x1 y1:(float)y1 x2:(float)x2 y2:(float)y2 isClosedContour:(BOOL)isClosedContour __attribute__((swift_name("init(x0:y0:x1:y1:x2:y2:isClosedContour:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithX0:(float)x0 y0:(float)y0 x1:(float)x1 y1:(float)y1 x2:(float)x2 y2:(float)y2 conicWeight:(float)conicWeight isClosedContour:(BOOL)isClosedContour __attribute__((swift_name("init(x0:y0:x1:y1:x2:y2:conicWeight:isClosedContour:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithVerb:(TruoraSharedSkikoPathVerb *)verb p0:(TruoraSharedSkikoPoint * _Nullable)p0 p1:(TruoraSharedSkikoPoint * _Nullable)p1 p2:(TruoraSharedSkikoPoint * _Nullable)p2 p3:(TruoraSharedSkikoPoint * _Nullable)p3 conicWeight:(float)conicWeight isCloseLine:(BOOL)isCloseLine isClosedContour:(BOOL)isClosedContour __attribute__((swift_name("init(verb:p0:p1:p2:p3:conicWeight:isCloseLine:isClosedContour:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithX0:(float)x0 y0:(float)y0 x1:(float)x1 y1:(float)y1 x2:(float)x2 y2:(float)y2 x3:(float)x3 y3:(float)y3 isClosedContour:(BOOL)isClosedContour __attribute__((swift_name("init(x0:y0:x1:y1:x2:y2:x3:y3:isClosedContour:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) float conicWeight __attribute__((swift_name("conicWeight")));
@property (readonly) BOOL isCloseLine __attribute__((swift_name("isCloseLine")));
@property (readonly) BOOL isClosedContour __attribute__((swift_name("isClosedContour")));
@property (readonly) TruoraSharedSkikoPoint * _Nullable p0 __attribute__((swift_name("p0")));
@property (readonly) TruoraSharedSkikoPoint * _Nullable p1 __attribute__((swift_name("p1")));
@property (readonly) TruoraSharedSkikoPoint * _Nullable p2 __attribute__((swift_name("p2")));
@property (readonly) TruoraSharedSkikoPoint * _Nullable p3 __attribute__((swift_name("p3")));
@property (readonly) TruoraSharedSkikoPathVerb *verb __attribute__((swift_name("verb")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoBackendTexture.Companion")))
@interface TruoraSharedSkikoBackendTextureCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoBackendTextureCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoBackendTexture *)makeGLWidth:(int32_t)width height:(int32_t)height isMipmapped:(BOOL)isMipmapped textureId:(int32_t)textureId textureTarget:(int32_t)textureTarget textureFormat:(int32_t)textureFormat __attribute__((swift_name("makeGL(width:height:isMipmapped:textureId:textureTarget:textureFormat:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPixelRef.Companion")))
@interface TruoraSharedSkikoPixelRefCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoPixelRefCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoSurface.Companion")))
@interface TruoraSharedSkikoSurfaceCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoSurfaceCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoSurface * _Nullable)makeFromBackendRenderTargetContext:(TruoraSharedSkikoDirectContext *)context rt:(TruoraSharedSkikoBackendRenderTarget *)rt origin:(TruoraSharedSkikoSurfaceOrigin *)origin colorFormat:(TruoraSharedSkikoSurfaceColorFormat *)colorFormat colorSpace:(TruoraSharedSkikoColorSpace * _Nullable)colorSpace surfaceProps:(TruoraSharedSkikoSurfaceProps * _Nullable)surfaceProps __attribute__((swift_name("makeFromBackendRenderTarget(context:rt:origin:colorFormat:colorSpace:surfaceProps:)")));
- (TruoraSharedSkikoSurface *)makeFromMTKViewContext:(TruoraSharedSkikoDirectContext *)context mtkViewPtr:(void * _Nullable)mtkViewPtr origin:(TruoraSharedSkikoSurfaceOrigin *)origin sampleCount:(int32_t)sampleCount colorFormat:(TruoraSharedSkikoSurfaceColorFormat *)colorFormat colorSpace:(TruoraSharedSkikoColorSpace * _Nullable)colorSpace surfaceProps:(TruoraSharedSkikoSurfaceProps * _Nullable)surfaceProps __attribute__((swift_name("makeFromMTKView(context:mtkViewPtr:origin:sampleCount:colorFormat:colorSpace:surfaceProps:)")));
- (TruoraSharedSkikoSurface *)makeNullWidth:(int32_t)width height:(int32_t)height __attribute__((swift_name("makeNull(width:height:)")));
- (TruoraSharedSkikoSurface *)makeRasterImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo __attribute__((swift_name("makeRaster(imageInfo:)")));
- (TruoraSharedSkikoSurface *)makeRasterImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo rowBytes:(int32_t)rowBytes __attribute__((swift_name("makeRaster(imageInfo:rowBytes:)")));
- (TruoraSharedSkikoSurface *)makeRasterImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo rowBytes:(int32_t)rowBytes surfaceProps:(TruoraSharedSkikoSurfaceProps * _Nullable)surfaceProps __attribute__((swift_name("makeRaster(imageInfo:rowBytes:surfaceProps:)")));
- (TruoraSharedSkikoSurface *)makeRasterDirectPixmap:(TruoraSharedSkikoPixmap *)pixmap __attribute__((swift_name("makeRasterDirect(pixmap:)")));
- (TruoraSharedSkikoSurface *)makeRasterDirectPixmap:(TruoraSharedSkikoPixmap *)pixmap surfaceProps:(TruoraSharedSkikoSurfaceProps * _Nullable)surfaceProps __attribute__((swift_name("makeRasterDirect(pixmap:surfaceProps:)")));
- (TruoraSharedSkikoSurface *)makeRasterDirectImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo pixelsPtr:(void * _Nullable)pixelsPtr rowBytes:(int32_t)rowBytes __attribute__((swift_name("makeRasterDirect(imageInfo:pixelsPtr:rowBytes:)")));
- (TruoraSharedSkikoSurface *)makeRasterDirectImageInfo:(TruoraSharedSkikoImageInfo *)imageInfo pixelsPtr:(void * _Nullable)pixelsPtr rowBytes:(int32_t)rowBytes surfaceProps:(TruoraSharedSkikoSurfaceProps * _Nullable)surfaceProps __attribute__((swift_name("makeRasterDirect(imageInfo:pixelsPtr:rowBytes:surfaceProps:)")));
- (TruoraSharedSkikoSurface *)makeRasterN32PremulWidth:(int32_t)width height:(int32_t)height __attribute__((swift_name("makeRasterN32Premul(width:height:)")));
- (TruoraSharedSkikoSurface *)makeRenderTargetContext:(TruoraSharedSkikoDirectContext *)context budgeted:(BOOL)budgeted imageInfo:(TruoraSharedSkikoImageInfo *)imageInfo __attribute__((swift_name("makeRenderTarget(context:budgeted:imageInfo:)")));
- (TruoraSharedSkikoSurface *)makeRenderTargetContext:(TruoraSharedSkikoDirectContext *)context budgeted:(BOOL)budgeted imageInfo:(TruoraSharedSkikoImageInfo *)imageInfo sampleCount:(int32_t)sampleCount surfaceProps:(TruoraSharedSkikoSurfaceProps * _Nullable)surfaceProps __attribute__((swift_name("makeRenderTarget(context:budgeted:imageInfo:sampleCount:surfaceProps:)")));
- (TruoraSharedSkikoSurface *)makeRenderTargetContext:(TruoraSharedSkikoDirectContext *)context budgeted:(BOOL)budgeted imageInfo:(TruoraSharedSkikoImageInfo *)imageInfo sampleCount:(int32_t)sampleCount origin:(TruoraSharedSkikoSurfaceOrigin *)origin surfaceProps:(TruoraSharedSkikoSurfaceProps * _Nullable)surfaceProps __attribute__((swift_name("makeRenderTarget(context:budgeted:imageInfo:sampleCount:origin:surfaceProps:)")));
- (TruoraSharedSkikoSurface *)makeRenderTargetContext:(TruoraSharedSkikoDirectContext *)context budgeted:(BOOL)budgeted imageInfo:(TruoraSharedSkikoImageInfo *)imageInfo sampleCount:(int32_t)sampleCount origin:(TruoraSharedSkikoSurfaceOrigin *)origin surfaceProps:(TruoraSharedSkikoSurfaceProps * _Nullable)surfaceProps shouldCreateWithMips:(BOOL)shouldCreateWithMips __attribute__((swift_name("makeRenderTarget(context:budgeted:imageInfo:sampleCount:origin:surfaceProps:shouldCreateWithMips:)")));
@end

__attribute__((swift_name("SkikoCanvas")))
@interface TruoraSharedSkikoCanvas : TruoraSharedSkikoManaged
- (instancetype)initWithBitmap:(TruoraSharedSkikoBitmap *)bitmap surfaceProps:(TruoraSharedSkikoSurfaceProps *)surfaceProps __attribute__((swift_name("init(bitmap:surfaceProps:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoCanvasCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoCanvas *)clearColor:(int32_t)color __attribute__((swift_name("clear(color:)")));
- (TruoraSharedSkikoCanvas *)clipPathP:(TruoraSharedSkikoPath *)p __attribute__((swift_name("clipPath(p:)")));
- (TruoraSharedSkikoCanvas *)clipPathP:(TruoraSharedSkikoPath *)p antiAlias:(BOOL)antiAlias __attribute__((swift_name("clipPath(p:antiAlias:)")));
- (TruoraSharedSkikoCanvas *)clipPathP:(TruoraSharedSkikoPath *)p mode:(TruoraSharedSkikoClipMode *)mode __attribute__((swift_name("clipPath(p:mode:)")));
- (TruoraSharedSkikoCanvas *)clipPathP:(TruoraSharedSkikoPath *)p mode:(TruoraSharedSkikoClipMode *)mode antiAlias:(BOOL)antiAlias __attribute__((swift_name("clipPath(p:mode:antiAlias:)")));
- (TruoraSharedSkikoCanvas *)clipRRectR:(TruoraSharedSkikoRRect *)r __attribute__((swift_name("clipRRect(r:)")));
- (TruoraSharedSkikoCanvas *)clipRRectR:(TruoraSharedSkikoRRect *)r antiAlias:(BOOL)antiAlias __attribute__((swift_name("clipRRect(r:antiAlias:)")));
- (TruoraSharedSkikoCanvas *)clipRRectR:(TruoraSharedSkikoRRect *)r mode:(TruoraSharedSkikoClipMode *)mode __attribute__((swift_name("clipRRect(r:mode:)")));
- (TruoraSharedSkikoCanvas *)clipRRectR:(TruoraSharedSkikoRRect *)r mode:(TruoraSharedSkikoClipMode *)mode antiAlias:(BOOL)antiAlias __attribute__((swift_name("clipRRect(r:mode:antiAlias:)")));
- (TruoraSharedSkikoCanvas *)clipRectR:(TruoraSharedSkikoRect *)r __attribute__((swift_name("clipRect(r:)")));
- (TruoraSharedSkikoCanvas *)clipRectR:(TruoraSharedSkikoRect *)r antiAlias:(BOOL)antiAlias __attribute__((swift_name("clipRect(r:antiAlias:)")));
- (TruoraSharedSkikoCanvas *)clipRectR:(TruoraSharedSkikoRect *)r mode:(TruoraSharedSkikoClipMode *)mode __attribute__((swift_name("clipRect(r:mode:)")));
- (TruoraSharedSkikoCanvas *)clipRectR:(TruoraSharedSkikoRect *)r mode:(TruoraSharedSkikoClipMode *)mode antiAlias:(BOOL)antiAlias __attribute__((swift_name("clipRect(r:mode:antiAlias:)")));
- (TruoraSharedSkikoCanvas *)clipRegionR:(TruoraSharedSkikoRegion *)r __attribute__((swift_name("clipRegion(r:)")));
- (TruoraSharedSkikoCanvas *)clipRegionR:(TruoraSharedSkikoRegion *)r mode:(TruoraSharedSkikoClipMode *)mode __attribute__((swift_name("clipRegion(r:mode:)")));
- (TruoraSharedSkikoCanvas *)concatMatrix:(TruoraSharedSkikoMatrix33 *)matrix __attribute__((swift_name("concat(matrix:)")));
- (TruoraSharedSkikoCanvas *)concatMatrix_:(TruoraSharedSkikoMatrix44 *)matrix __attribute__((swift_name("concat(matrix_:)")));
- (TruoraSharedSkikoCanvas *)drawArcLeft:(float)left top:(float)top right:(float)right bottom:(float)bottom startAngle:(float)startAngle sweepAngle:(float)sweepAngle includeCenter:(BOOL)includeCenter paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawArc(left:top:right:bottom:startAngle:sweepAngle:includeCenter:paint:)")));
- (TruoraSharedSkikoCanvas *)drawCircleX:(float)x y:(float)y radius:(float)radius paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawCircle(x:y:radius:paint:)")));
- (TruoraSharedSkikoCanvas *)drawDRRectOuter:(TruoraSharedSkikoRRect *)outer inner:(TruoraSharedSkikoRRect *)inner paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawDRRect(outer:inner:paint:)")));
- (TruoraSharedSkikoCanvas *)drawDrawableDrawable:(TruoraSharedSkikoDrawable *)drawable __attribute__((swift_name("drawDrawable(drawable:)")));
- (TruoraSharedSkikoCanvas *)drawDrawableDrawable:(TruoraSharedSkikoDrawable *)drawable matrix:(TruoraSharedSkikoMatrix33 * _Nullable)matrix __attribute__((swift_name("drawDrawable(drawable:matrix:)")));
- (TruoraSharedSkikoCanvas *)drawDrawableDrawable:(TruoraSharedSkikoDrawable *)drawable x:(float)x y:(float)y __attribute__((swift_name("drawDrawable(drawable:x:y:)")));
- (TruoraSharedSkikoCanvas *)drawImageImage:(TruoraSharedSkikoImage *)image left:(float)left top:(float)top __attribute__((swift_name("drawImage(image:left:top:)")));
- (TruoraSharedSkikoCanvas *)drawImageImage:(TruoraSharedSkikoImage *)image left:(float)left top:(float)top paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("drawImage(image:left:top:paint:)")));
- (TruoraSharedSkikoCanvas *)drawImageNineImage:(TruoraSharedSkikoImage *)image center:(TruoraSharedSkikoIRect *)center dst:(TruoraSharedSkikoRect *)dst filterMode:(TruoraSharedSkikoFilterMode *)filterMode paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("drawImageNine(image:center:dst:filterMode:paint:)")));
- (TruoraSharedSkikoCanvas *)drawImageRectImage:(TruoraSharedSkikoImage *)image dst:(TruoraSharedSkikoRect *)dst __attribute__((swift_name("drawImageRect(image:dst:)")));
- (TruoraSharedSkikoCanvas *)drawImageRectImage:(TruoraSharedSkikoImage *)image dst:(TruoraSharedSkikoRect *)dst paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("drawImageRect(image:dst:paint:)")));
- (TruoraSharedSkikoCanvas *)drawImageRectImage:(TruoraSharedSkikoImage *)image src:(TruoraSharedSkikoRect *)src dst:(TruoraSharedSkikoRect *)dst __attribute__((swift_name("drawImageRect(image:src:dst:)")));
- (TruoraSharedSkikoCanvas *)drawImageRectImage:(TruoraSharedSkikoImage *)image src:(TruoraSharedSkikoRect *)src dst:(TruoraSharedSkikoRect *)dst paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("drawImageRect(image:src:dst:paint:)")));
- (TruoraSharedSkikoCanvas *)drawImageRectImage:(TruoraSharedSkikoImage *)image src:(TruoraSharedSkikoRect *)src dst:(TruoraSharedSkikoRect *)dst paint:(TruoraSharedSkikoPaint * _Nullable)paint strict:(BOOL)strict __attribute__((swift_name("drawImageRect(image:src:dst:paint:strict:)")));
- (TruoraSharedSkikoCanvas *)drawImageRectImage:(TruoraSharedSkikoImage *)image src:(TruoraSharedSkikoRect *)src dst:(TruoraSharedSkikoRect *)dst samplingMode:(id<TruoraSharedSkikoSamplingMode>)samplingMode paint:(TruoraSharedSkikoPaint * _Nullable)paint strict:(BOOL)strict __attribute__((swift_name("drawImageRect(image:src:dst:samplingMode:paint:strict:)")));
- (TruoraSharedSkikoCanvas *)drawLineX0:(float)x0 y0:(float)y0 x1:(float)x1 y1:(float)y1 paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawLine(x0:y0:x1:y1:paint:)")));
- (TruoraSharedSkikoCanvas *)drawLinesCoords:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)coords paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawLines(coords:paint:)")));
- (TruoraSharedSkikoCanvas *)drawLinesCoords:(TruoraSharedKotlinFloatArray *)coords paint_:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawLines(coords:paint_:)")));
- (TruoraSharedSkikoCanvas *)drawOvalR:(TruoraSharedSkikoRect *)r paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawOval(r:paint:)")));
- (TruoraSharedSkikoCanvas *)drawPaintPaint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawPaint(paint:)")));
- (TruoraSharedSkikoCanvas *)drawPatchCubics:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)cubics colors:(TruoraSharedKotlinIntArray *)colors texCoords:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> * _Nullable)texCoords blendMode:(TruoraSharedSkikoBlendMode *)blendMode paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawPatch(cubics:colors:texCoords:blendMode:paint:)")));
- (TruoraSharedSkikoCanvas *)drawPathPath:(TruoraSharedSkikoPath *)path paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawPath(path:paint:)")));
- (TruoraSharedSkikoCanvas *)drawPicturePicture:(TruoraSharedSkikoPicture *)picture matrix:(TruoraSharedSkikoMatrix33 * _Nullable)matrix paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("drawPicture(picture:matrix:paint:)")));
- (TruoraSharedSkikoCanvas *)drawPointX:(float)x y:(float)y paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawPoint(x:y:paint:)")));
- (TruoraSharedSkikoCanvas *)drawPointsCoords:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)coords paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawPoints(coords:paint:)")));
- (TruoraSharedSkikoCanvas *)drawPointsCoords:(TruoraSharedKotlinFloatArray *)coords paint_:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawPoints(coords:paint_:)")));
- (TruoraSharedSkikoCanvas *)drawPolygonCoords:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)coords paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawPolygon(coords:paint:)")));
- (TruoraSharedSkikoCanvas *)drawPolygonCoords:(TruoraSharedKotlinFloatArray *)coords paint_:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawPolygon(coords:paint_:)")));
- (TruoraSharedSkikoCanvas *)drawRRectR:(TruoraSharedSkikoRRect *)r paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawRRect(r:paint:)")));
- (TruoraSharedSkikoCanvas *)drawRectR:(TruoraSharedSkikoRect *)r paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawRect(r:paint:)")));
- (TruoraSharedSkikoCanvas *)drawRectShadowR:(TruoraSharedSkikoRect *)r dx:(float)dx dy:(float)dy blur:(float)blur color:(int32_t)color __attribute__((swift_name("drawRectShadow(r:dx:dy:blur:color:)")));
- (TruoraSharedSkikoCanvas *)drawRectShadowR:(TruoraSharedSkikoRect *)r dx:(float)dx dy:(float)dy blur:(float)blur spread:(float)spread color:(int32_t)color __attribute__((swift_name("drawRectShadow(r:dx:dy:blur:spread:color:)")));
- (TruoraSharedSkikoCanvas *)drawRectShadowNoclipR:(TruoraSharedSkikoRect *)r dx:(float)dx dy:(float)dy blur:(float)blur spread:(float)spread color:(int32_t)color __attribute__((swift_name("drawRectShadowNoclip(r:dx:dy:blur:spread:color:)")));
- (TruoraSharedSkikoCanvas *)drawRegionR:(TruoraSharedSkikoRegion *)r paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawRegion(r:paint:)")));
- (TruoraSharedSkikoCanvas *)drawStringS:(NSString *)s x:(float)x y:(float)y font:(TruoraSharedSkikoFont * _Nullable)font paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawString(s:x:y:font:paint:)")));
- (TruoraSharedSkikoCanvas *)drawTextBlobBlob:(TruoraSharedSkikoTextBlob *)blob x:(float)x y:(float)y paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawTextBlob(blob:x:y:paint:)")));
- (TruoraSharedSkikoCanvas *)drawTextLineLine:(TruoraSharedSkikoTextLine *)line x:(float)x y:(float)y paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawTextLine(line:x:y:paint:)")));
- (TruoraSharedSkikoCanvas *)drawTriangleFanPositions:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)positions colors:(TruoraSharedKotlinIntArray * _Nullable)colors texCoords:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> * _Nullable)texCoords indices:(TruoraSharedKotlinShortArray * _Nullable)indices blendMode:(TruoraSharedSkikoBlendMode *)blendMode paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawTriangleFan(positions:colors:texCoords:indices:blendMode:paint:)")));
- (TruoraSharedSkikoCanvas *)drawTriangleStripPositions:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)positions colors:(TruoraSharedKotlinIntArray * _Nullable)colors texCoords:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> * _Nullable)texCoords indices:(TruoraSharedKotlinShortArray * _Nullable)indices blendMode:(TruoraSharedSkikoBlendMode *)blendMode paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawTriangleStrip(positions:colors:texCoords:indices:blendMode:paint:)")));
- (TruoraSharedSkikoCanvas *)drawTrianglesPositions:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)positions colors:(TruoraSharedKotlinIntArray * _Nullable)colors texCoords:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> * _Nullable)texCoords indices:(TruoraSharedKotlinShortArray * _Nullable)indices blendMode:(TruoraSharedSkikoBlendMode *)blendMode paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawTriangles(positions:colors:texCoords:indices:blendMode:paint:)")));
- (TruoraSharedSkikoCanvas *)drawVerticesVertexMode:(TruoraSharedSkikoVertexMode *)vertexMode positions:(TruoraSharedKotlinFloatArray *)positions colors:(TruoraSharedKotlinIntArray * _Nullable)colors texCoords:(TruoraSharedKotlinFloatArray * _Nullable)texCoords indices:(TruoraSharedKotlinShortArray * _Nullable)indices blendMode:(TruoraSharedSkikoBlendMode *)blendMode paint:(TruoraSharedSkikoPaint *)paint __attribute__((swift_name("drawVertices(vertexMode:positions:colors:texCoords:indices:blendMode:paint:)")));
- (BOOL)readPixelsBitmap:(TruoraSharedSkikoBitmap *)bitmap srcX:(int32_t)srcX srcY:(int32_t)srcY __attribute__((swift_name("readPixels(bitmap:srcX:srcY:)")));
- (TruoraSharedSkikoCanvas *)resetMatrix __attribute__((swift_name("resetMatrix()")));
- (TruoraSharedSkikoCanvas *)restore __attribute__((swift_name("restore()")));
- (TruoraSharedSkikoCanvas *)restoreToCountSaveCount:(int32_t)saveCount __attribute__((swift_name("restoreToCount(saveCount:)")));
- (TruoraSharedSkikoCanvas *)rotateDeg:(float)deg __attribute__((swift_name("rotate(deg:)")));
- (TruoraSharedSkikoCanvas *)rotateDeg:(float)deg x:(float)x y:(float)y __attribute__((swift_name("rotate(deg:x:y:)")));
- (int32_t)save __attribute__((swift_name("save()")));
- (int32_t)saveLayerLayerRec:(TruoraSharedSkikoCanvasSaveLayerRec *)layerRec __attribute__((swift_name("saveLayer(layerRec:)")));
- (int32_t)saveLayerBounds:(TruoraSharedSkikoRect * _Nullable)bounds paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("saveLayer(bounds:paint:)")));
- (int32_t)saveLayerLeft:(float)left top:(float)top right:(float)right bottom:(float)bottom paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("saveLayer(left:top:right:bottom:paint:)")));
- (TruoraSharedSkikoCanvas *)scaleSx:(float)sx sy:(float)sy __attribute__((swift_name("scale(sx:sy:)")));
- (TruoraSharedSkikoCanvas *)setMatrixMatrix:(TruoraSharedSkikoMatrix33 *)matrix __attribute__((swift_name("setMatrix(matrix:)")));
- (TruoraSharedSkikoCanvas *)skewSx:(float)sx sy:(float)sy __attribute__((swift_name("skew(sx:sy:)")));
- (TruoraSharedSkikoCanvas *)translateDx:(float)dx dy:(float)dy __attribute__((swift_name("translate(dx:dy:)")));
- (BOOL)writePixelsBitmap:(TruoraSharedSkikoBitmap *)bitmap x:(int32_t)x y:(int32_t)y __attribute__((swift_name("writePixels(bitmap:x:y:)")));
@property (readonly) TruoraSharedSkikoMatrix44 *localToDevice __attribute__((swift_name("localToDevice")));
@property (readonly) TruoraSharedSkikoMatrix33 *localToDeviceAsMatrix33 __attribute__((swift_name("localToDeviceAsMatrix33")));
@property (readonly) int32_t saveCount __attribute__((swift_name("saveCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoContentChangeMode")))
@interface TruoraSharedSkikoContentChangeMode : TruoraSharedKotlinEnum<TruoraSharedSkikoContentChangeMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoContentChangeMode *discard __attribute__((swift_name("discard")));
@property (class, readonly) TruoraSharedSkikoContentChangeMode *retain_ __attribute__((swift_name("retain_")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoContentChangeMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoContentChangeMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoBackendRenderTarget")))
@interface TruoraSharedSkikoBackendRenderTarget : TruoraSharedSkikoManaged
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoBackendRenderTargetCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoSurfaceColorFormat")))
@interface TruoraSharedSkikoSurfaceColorFormat : TruoraSharedKotlinEnum<TruoraSharedSkikoSurfaceColorFormat *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *alpha8 __attribute__((swift_name("alpha8")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *rgb565 __attribute__((swift_name("rgb565")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *argb4444 __attribute__((swift_name("argb4444")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *rgba8888 __attribute__((swift_name("rgba8888")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *rgb888x __attribute__((swift_name("rgb888x")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *bgra8888 __attribute__((swift_name("bgra8888")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *rgba1010102 __attribute__((swift_name("rgba1010102")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *rgb101010x __attribute__((swift_name("rgb101010x")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *gray8 __attribute__((swift_name("gray8")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *rgbaF16Norm __attribute__((swift_name("rgbaF16Norm")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *rgbaF16 __attribute__((swift_name("rgbaF16")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *rgbaF32 __attribute__((swift_name("rgbaF32")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *r8g8Unorm __attribute__((swift_name("r8g8Unorm")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *a16Float __attribute__((swift_name("a16Float")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *r16g16Float __attribute__((swift_name("r16g16Float")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *a16Unorm __attribute__((swift_name("a16Unorm")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *r16g16Unorm __attribute__((swift_name("r16g16Unorm")));
@property (class, readonly) TruoraSharedSkikoSurfaceColorFormat *r16g16b16a16Unorm __attribute__((swift_name("r16g16b16a16Unorm")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoSurfaceColorFormat *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoSurfaceColorFormat *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoSurfaceProps")))
@interface TruoraSharedSkikoSurfaceProps : TruoraSharedBase
- (instancetype)initWithGeo:(TruoraSharedSkikoPixelGeometry *)geo __attribute__((swift_name("init(geo:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithIsDeviceIndependentFonts:(BOOL)isDeviceIndependentFonts pixelGeometry:(TruoraSharedSkikoPixelGeometry *)pixelGeometry __attribute__((swift_name("init(isDeviceIndependentFonts:pixelGeometry:)"))) __attribute__((objc_designated_initializer));
- (int32_t)_getFlags __attribute__((swift_name("_getFlags()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (TruoraSharedSkikoSurfaceProps *)withDeviceIndependentFonts_deviceIndependentFonts:(BOOL)_deviceIndependentFonts __attribute__((swift_name("withDeviceIndependentFonts(_deviceIndependentFonts:)")));
- (TruoraSharedSkikoSurfaceProps *)withPixelGeometry_pixelGeometry:(TruoraSharedSkikoPixelGeometry *)_pixelGeometry __attribute__((swift_name("withPixelGeometry(_pixelGeometry:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoCanvas.Companion")))
@interface TruoraSharedSkikoCanvasCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoCanvasCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoClipMode")))
@interface TruoraSharedSkikoClipMode : TruoraSharedKotlinEnum<TruoraSharedSkikoClipMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoClipMode *difference __attribute__((swift_name("difference")));
@property (class, readonly) TruoraSharedSkikoClipMode *intersect __attribute__((swift_name("intersect")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoClipMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoClipMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRegion")))
@interface TruoraSharedSkikoRegion : TruoraSharedSkikoManaged
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoRegionCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)computeRegionComplexity __attribute__((swift_name("computeRegionComplexity()")));
- (BOOL)containsRect:(TruoraSharedSkikoIRect *)rect __attribute__((swift_name("contains(rect:)")));
- (BOOL)containsR:(TruoraSharedSkikoRegion * _Nullable)r __attribute__((swift_name("contains(r:)")));
- (BOOL)containsX:(int32_t)x y:(int32_t)y __attribute__((swift_name("contains(x:y:)")));
- (BOOL)getBoundaryPathP:(TruoraSharedSkikoPath * _Nullable)p __attribute__((swift_name("getBoundaryPath(p:)")));
- (BOOL)intersectsRect:(TruoraSharedSkikoIRect *)rect __attribute__((swift_name("intersects(rect:)")));
- (BOOL)intersectsR:(TruoraSharedSkikoRegion * _Nullable)r __attribute__((swift_name("intersects(r:)")));
- (BOOL)opRect:(TruoraSharedSkikoIRect *)rect op:(TruoraSharedSkikoRegionOp *)op __attribute__((swift_name("op(rect:op:)")));
- (BOOL)opR:(TruoraSharedSkikoRegion * _Nullable)r op:(TruoraSharedSkikoRegionOp *)op __attribute__((swift_name("op(r:op:)")));
- (BOOL)opRect:(TruoraSharedSkikoIRect *)rect r:(TruoraSharedSkikoRegion * _Nullable)r op:(TruoraSharedSkikoRegionOp *)op __attribute__((swift_name("op(rect:r:op:)")));
- (BOOL)opR:(TruoraSharedSkikoRegion * _Nullable)r rect:(TruoraSharedSkikoIRect *)rect op:(TruoraSharedSkikoRegionOp *)op __attribute__((swift_name("op(r:rect:op:)")));
- (BOOL)opA:(TruoraSharedSkikoRegion * _Nullable)a b:(TruoraSharedSkikoRegion * _Nullable)b op:(TruoraSharedSkikoRegionOp *)op __attribute__((swift_name("op(a:b:op:)")));
- (BOOL)quickContainsRect:(TruoraSharedSkikoIRect *)rect __attribute__((swift_name("quickContains(rect:)")));
- (BOOL)quickRejectRect:(TruoraSharedSkikoIRect *)rect __attribute__((swift_name("quickReject(rect:)")));
- (BOOL)quickRejectR:(TruoraSharedSkikoRegion * _Nullable)r __attribute__((swift_name("quickReject(r:)")));
- (BOOL)setR:(TruoraSharedSkikoRegion * _Nullable)r __attribute__((swift_name("set(r:)")));
- (BOOL)setEmpty __attribute__((swift_name("setEmpty()")));
- (BOOL)setPathPath:(TruoraSharedSkikoPath * _Nullable)path clip:(TruoraSharedSkikoRegion * _Nullable)clip __attribute__((swift_name("setPath(path:clip:)")));
- (BOOL)setRectRect:(TruoraSharedSkikoIRect *)rect __attribute__((swift_name("setRect(rect:)")));
- (BOOL)setRectsRects:(TruoraSharedKotlinArray<TruoraSharedSkikoIRect *> *)rects __attribute__((swift_name("setRects(rects:)")));
- (BOOL)setRegionR:(TruoraSharedSkikoRegion * _Nullable)r __attribute__((swift_name("setRegion(r:)")));
- (void)translateDx:(int32_t)dx dy:(int32_t)dy __attribute__((swift_name("translate(dx:dy:)")));
@property (readonly) TruoraSharedSkikoIRect *bounds __attribute__((swift_name("bounds")));
@property (readonly) BOOL isComplex __attribute__((swift_name("isComplex")));
@property (readonly) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) BOOL isRect __attribute__((swift_name("isRect")));
@end

__attribute__((swift_name("SkikoDrawable")))
@interface TruoraSharedSkikoDrawable : TruoraSharedSkikoManaged
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoDrawableCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoDrawable *)drawCanvas:(TruoraSharedSkikoCanvas * _Nullable)canvas __attribute__((swift_name("draw(canvas:)")));
- (TruoraSharedSkikoDrawable *)drawCanvas:(TruoraSharedSkikoCanvas * _Nullable)canvas matrix:(TruoraSharedSkikoMatrix33 * _Nullable)matrix __attribute__((swift_name("draw(canvas:matrix:)")));
- (TruoraSharedSkikoDrawable *)drawCanvas:(TruoraSharedSkikoCanvas * _Nullable)canvas x:(float)x y:(float)y __attribute__((swift_name("draw(canvas:x:y:)")));
- (TruoraSharedSkikoPicture *)makePictureSnapshot __attribute__((swift_name("makePictureSnapshot()")));
- (TruoraSharedSkikoDrawable *)notifyDrawingChanged __attribute__((swift_name("notifyDrawingChanged()")));
- (void)onDrawCanvas:(TruoraSharedSkikoCanvas * _Nullable)canvas __attribute__((swift_name("onDraw(canvas:)")));
- (TruoraSharedSkikoRect *)onGetBounds __attribute__((swift_name("onGetBounds()")));
@property (readonly) TruoraSharedSkikoRect *bounds __attribute__((swift_name("bounds")));
@property (readonly) int32_t generationId __attribute__((swift_name("generationId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFilterMode")))
@interface TruoraSharedSkikoFilterMode : TruoraSharedKotlinEnum<TruoraSharedSkikoFilterMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoFilterMode *nearest __attribute__((swift_name("nearest")));
@property (class, readonly) TruoraSharedSkikoFilterMode *linear __attribute__((swift_name("linear")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoFilterMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoFilterMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPicture")))
@interface TruoraSharedSkikoPicture : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoPictureCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedSkikoShader *)makeShaderTmx:(TruoraSharedSkikoFilterTileMode *)tmx tmy:(TruoraSharedSkikoFilterTileMode *)tmy mode:(TruoraSharedSkikoFilterMode *)mode localMatrix:(TruoraSharedSkikoMatrix33 * _Nullable)localMatrix tileRect:(TruoraSharedSkikoRect * _Nullable)tileRect __attribute__((swift_name("makeShader(tmx:tmy:mode:localMatrix:tileRect:)")));
- (TruoraSharedSkikoPicture *)playbackCanvas:(TruoraSharedSkikoCanvas * _Nullable)canvas abort:(TruoraSharedBoolean *(^ _Nullable)(void))abort __attribute__((swift_name("playback(canvas:abort:)")));
- (TruoraSharedSkikoData *)serializeToData __attribute__((swift_name("serializeToData()")));
@property (readonly) void * _Nullable approximateBytesUsed __attribute__((swift_name("approximateBytesUsed")));
@property (readonly) int32_t approximateOpCount __attribute__((swift_name("approximateOpCount")));
@property (readonly) TruoraSharedSkikoRect *cullRect __attribute__((swift_name("cullRect")));
@property (readonly) int32_t uniqueId __attribute__((swift_name("uniqueId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFont")))
@interface TruoraSharedSkikoFont : TruoraSharedSkikoManaged
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithTypeface:(TruoraSharedSkikoTypeface * _Nullable)typeface __attribute__((swift_name("init(typeface:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithTypeface:(TruoraSharedSkikoTypeface * _Nullable)typeface size:(float)size __attribute__((swift_name("init(typeface:size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithTypeface:(TruoraSharedSkikoTypeface * _Nullable)typeface size:(float)size scaleX:(float)scaleX skewX:(float)skewX __attribute__((swift_name("init(typeface:size:scaleX:skewX:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoFontCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)areBitmapsEmbedded __attribute__((swift_name("areBitmapsEmbedded()")));
- (TruoraSharedKotlinArray<TruoraSharedSkikoRect *> *)getBoundsGlyphs:(TruoraSharedKotlinShortArray * _Nullable)glyphs __attribute__((swift_name("getBounds(glyphs:)")));
- (TruoraSharedKotlinArray<TruoraSharedSkikoRect *> *)getBoundsGlyphs:(TruoraSharedKotlinShortArray * _Nullable)glyphs p:(TruoraSharedSkikoPaint * _Nullable)p __attribute__((swift_name("getBounds(glyphs:p:)")));
- (TruoraSharedSkikoPath * _Nullable)getPathGlyph:(int16_t)glyph __attribute__((swift_name("getPath(glyph:)")));
- (TruoraSharedKotlinArray<TruoraSharedSkikoPath *> *)getPathsGlyphs:(TruoraSharedKotlinShortArray * _Nullable)glyphs __attribute__((swift_name("getPaths(glyphs:)")));
- (TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)getPositionsGlyphs:(TruoraSharedKotlinShortArray * _Nullable)glyphs __attribute__((swift_name("getPositions(glyphs:)")));
- (TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)getPositionsGlyphs:(TruoraSharedKotlinShortArray * _Nullable)glyphs offset:(TruoraSharedSkikoPoint *)offset __attribute__((swift_name("getPositions(glyphs:offset:)")));
- (TruoraSharedKotlinShortArray *)getStringGlyphsS:(NSString *)s __attribute__((swift_name("getStringGlyphs(s:)")));
- (int32_t)getStringGlyphsCountS:(NSString * _Nullable)s __attribute__((swift_name("getStringGlyphsCount(s:)")));
- (int16_t)getUTF32GlyphUnichar:(int32_t)unichar __attribute__((swift_name("getUTF32Glyph(unichar:)")));
- (TruoraSharedKotlinShortArray *)getUTF32GlyphsUni:(TruoraSharedKotlinIntArray * _Nullable)uni __attribute__((swift_name("getUTF32Glyphs(uni:)")));
- (TruoraSharedKotlinFloatArray *)getWidthsGlyphs:(TruoraSharedKotlinShortArray * _Nullable)glyphs __attribute__((swift_name("getWidths(glyphs:)")));
- (TruoraSharedKotlinFloatArray *)getXPositionsGlyphs:(TruoraSharedKotlinShortArray * _Nullable)glyphs __attribute__((swift_name("getXPositions(glyphs:)")));
- (TruoraSharedKotlinFloatArray *)getXPositionsGlyphs:(TruoraSharedKotlinShortArray * _Nullable)glyphs offset:(float)offset __attribute__((swift_name("getXPositions(glyphs:offset:)")));
- (TruoraSharedSkikoFont *)makeWithSizeSize:(float)size __attribute__((swift_name("makeWithSize(size:)")));
- (TruoraSharedSkikoRect *)measureTextS:(NSString * _Nullable)s p:(TruoraSharedSkikoPaint * _Nullable)p __attribute__((swift_name("measureText(s:p:)")));
- (float)measureTextWidthS:(NSString * _Nullable)s __attribute__((swift_name("measureTextWidth(s:)")));
- (float)measureTextWidthS:(NSString * _Nullable)s p:(TruoraSharedSkikoPaint * _Nullable)p __attribute__((swift_name("measureTextWidth(s:p:)")));
- (void)setBitmapsEmbeddedValue:(BOOL)value __attribute__((swift_name("setBitmapsEmbedded(value:)")));
- (TruoraSharedSkikoFont *)setTypefaceTypeface:(TruoraSharedSkikoTypeface * _Nullable)typeface __attribute__((swift_name("setTypeface(typeface:)")));
@property TruoraSharedSkikoFontEdging *edging __attribute__((swift_name("edging")));
@property TruoraSharedSkikoFontHinting *hinting __attribute__((swift_name("hinting")));
@property BOOL isAutoHintingForced __attribute__((swift_name("isAutoHintingForced")));
@property BOOL isBaselineSnapped __attribute__((swift_name("isBaselineSnapped")));
@property BOOL isEmboldened __attribute__((swift_name("isEmboldened")));
@property BOOL isLinearMetrics __attribute__((swift_name("isLinearMetrics")));
@property BOOL isSubpixel __attribute__((swift_name("isSubpixel")));
@property (readonly) TruoraSharedSkikoFontMetrics *metrics __attribute__((swift_name("metrics")));
@property float scaleX __attribute__((swift_name("scaleX")));
@property float size __attribute__((swift_name("size")));
@property float skewX __attribute__((swift_name("skewX")));
@property (readonly) float spacing __attribute__((swift_name("spacing")));
@property (readonly) TruoraSharedSkikoTypeface * _Nullable typeface __attribute__((swift_name("typeface")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoTextBlob")))
@interface TruoraSharedSkikoTextBlob : TruoraSharedSkikoManaged <TruoraSharedKotlinIterable>
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoTextBlobCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedKotlinFloatArray * _Nullable)getInterceptsLowerBound:(float)lowerBound upperBound:(float)upperBound __attribute__((swift_name("getIntercepts(lowerBound:upperBound:)")));
- (TruoraSharedKotlinFloatArray * _Nullable)getInterceptsLowerBound:(float)lowerBound upperBound:(float)upperBound paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("getIntercepts(lowerBound:upperBound:paint:)")));
- (id<TruoraSharedKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (TruoraSharedSkikoData *)serializeToData __attribute__((swift_name("serializeToData()")));
@property (readonly) TruoraSharedSkikoRect *blockBounds __attribute__((swift_name("blockBounds")));
@property (readonly) TruoraSharedSkikoRect *bounds __attribute__((swift_name("bounds")));
@property (readonly) TruoraSharedKotlinIntArray *clusters __attribute__((swift_name("clusters")));
@property (readonly) float firstBaseline __attribute__((swift_name("firstBaseline")));
@property (readonly) TruoraSharedKotlinShortArray *glyphs __attribute__((swift_name("glyphs")));
@property (readonly) float lastBaseline __attribute__((swift_name("lastBaseline")));
@property (readonly) TruoraSharedKotlinFloatArray *positions __attribute__((swift_name("positions")));
@property (readonly) TruoraSharedSkikoRect *tightBounds __attribute__((swift_name("tightBounds")));
@property (readonly) int32_t uniqueId __attribute__((swift_name("uniqueId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoTextLine")))
@interface TruoraSharedSkikoTextLine : TruoraSharedSkikoManaged
- (instancetype)initWithPtr:(void * _Nullable)ptr finalizer:(void * _Nullable)finalizer managed:(BOOL)managed __attribute__((swift_name("init(ptr:finalizer:managed:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoTextLineCompanion *companion __attribute__((swift_name("companion")));
- (float)getCoordAtOffsetOffset:(int32_t)offset __attribute__((swift_name("getCoordAtOffset(offset:)")));
- (TruoraSharedKotlinFloatArray * _Nullable)getInterceptsLowerBound:(float)lowerBound upperBound:(float)upperBound __attribute__((swift_name("getIntercepts(lowerBound:upperBound:)")));
- (TruoraSharedKotlinFloatArray * _Nullable)getInterceptsLowerBound:(float)lowerBound upperBound:(float)upperBound paint:(TruoraSharedSkikoPaint * _Nullable)paint __attribute__((swift_name("getIntercepts(lowerBound:upperBound:paint:)")));
- (int32_t)getLeftOffsetAtCoordX:(float)x __attribute__((swift_name("getLeftOffsetAtCoord(x:)")));
- (int32_t)getOffsetAtCoordX:(float)x __attribute__((swift_name("getOffsetAtCoord(x:)")));
@property (readonly) float ascent __attribute__((swift_name("ascent")));
@property (readonly) float capHeight __attribute__((swift_name("capHeight")));
@property (readonly) float descent __attribute__((swift_name("descent")));
@property (readonly) TruoraSharedKotlinShortArray *glyphs __attribute__((swift_name("glyphs")));
@property (readonly) float height __attribute__((swift_name("height")));
@property (readonly) float leading __attribute__((swift_name("leading")));
@property (readonly) TruoraSharedKotlinFloatArray *positions __attribute__((swift_name("positions")));
@property (readonly) TruoraSharedSkikoTextBlob * _Nullable textBlob __attribute__((swift_name("textBlob")));
@property (readonly) float width __attribute__((swift_name("width")));
@property (readonly) float xHeight __attribute__((swift_name("xHeight")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinShortArray")))
@interface TruoraSharedKotlinShortArray : TruoraSharedBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(TruoraSharedShort *(^)(TruoraSharedInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int16_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (TruoraSharedKotlinShortIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int16_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoVertexMode")))
@interface TruoraSharedSkikoVertexMode : TruoraSharedKotlinEnum<TruoraSharedSkikoVertexMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoVertexMode *triangles __attribute__((swift_name("triangles")));
@property (class, readonly) TruoraSharedSkikoVertexMode *triangleStrip __attribute__((swift_name("triangleStrip")));
@property (class, readonly) TruoraSharedSkikoVertexMode *triangleFan __attribute__((swift_name("triangleFan")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoVertexMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoVertexMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoCanvas.SaveLayerRec")))
@interface TruoraSharedSkikoCanvasSaveLayerRec : TruoraSharedBase
- (instancetype)initWithBounds:(TruoraSharedSkikoRect * _Nullable)bounds paint:(TruoraSharedSkikoPaint * _Nullable)paint backdrop:(TruoraSharedSkikoImageFilter * _Nullable)backdrop colorSpace:(TruoraSharedSkikoColorSpace * _Nullable)colorSpace saveLayerFlags:(TruoraSharedSkikoCanvasSaveLayerFlags *)saveLayerFlags __attribute__((swift_name("init(bounds:paint:backdrop:colorSpace:saveLayerFlags:)"))) __attribute__((objc_designated_initializer));
@property (readonly) TruoraSharedSkikoImageFilter * _Nullable backdrop __attribute__((swift_name("backdrop")));
@property (readonly) TruoraSharedSkikoRect * _Nullable bounds __attribute__((swift_name("bounds")));
@property (readonly) TruoraSharedSkikoColorSpace * _Nullable colorSpace __attribute__((swift_name("colorSpace")));
@property (readonly) TruoraSharedSkikoPaint * _Nullable paint __attribute__((swift_name("paint")));
@property (readonly) TruoraSharedSkikoCanvasSaveLayerFlags *saveLayerFlags __attribute__((swift_name("saveLayerFlags")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoBackendRenderTarget.Companion")))
@interface TruoraSharedSkikoBackendRenderTargetCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoBackendRenderTargetCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoBackendRenderTarget *)makeDirect3DWidth:(int32_t)width height:(int32_t)height texturePtr:(void * _Nullable)texturePtr format:(int32_t)format sampleCnt:(int32_t)sampleCnt levelCnt:(int32_t)levelCnt __attribute__((swift_name("makeDirect3D(width:height:texturePtr:format:sampleCnt:levelCnt:)")));
- (TruoraSharedSkikoBackendRenderTarget *)makeGLWidth:(int32_t)width height:(int32_t)height sampleCnt:(int32_t)sampleCnt stencilBits:(int32_t)stencilBits fbId:(int32_t)fbId fbFormat:(int32_t)fbFormat __attribute__((swift_name("makeGL(width:height:sampleCnt:stencilBits:fbId:fbFormat:)")));
- (TruoraSharedSkikoBackendRenderTarget *)makeMetalWidth:(int32_t)width height:(int32_t)height texturePtr:(void * _Nullable)texturePtr __attribute__((swift_name("makeMetal(width:height:texturePtr:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPixelGeometry")))
@interface TruoraSharedSkikoPixelGeometry : TruoraSharedKotlinEnum<TruoraSharedSkikoPixelGeometry *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoPixelGeometry *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) TruoraSharedSkikoPixelGeometry *rgbH __attribute__((swift_name("rgbH")));
@property (class, readonly) TruoraSharedSkikoPixelGeometry *bgrH __attribute__((swift_name("bgrH")));
@property (class, readonly) TruoraSharedSkikoPixelGeometry *rgbV __attribute__((swift_name("rgbV")));
@property (class, readonly) TruoraSharedSkikoPixelGeometry *bgrV __attribute__((swift_name("bgrV")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoPixelGeometry *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoPixelGeometry *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRegion.Companion")))
@interface TruoraSharedSkikoRegionCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoRegionCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRegion.Op")))
@interface TruoraSharedSkikoRegionOp : TruoraSharedKotlinEnum<TruoraSharedSkikoRegionOp *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoRegionOpCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) TruoraSharedSkikoRegionOp *difference __attribute__((swift_name("difference")));
@property (class, readonly) TruoraSharedSkikoRegionOp *intersect __attribute__((swift_name("intersect")));
@property (class, readonly) TruoraSharedSkikoRegionOp *union_ __attribute__((swift_name("union_")));
@property (class, readonly) TruoraSharedSkikoRegionOp *xor_ __attribute__((swift_name("xor_")));
@property (class, readonly) TruoraSharedSkikoRegionOp *reverseDifference __attribute__((swift_name("reverseDifference")));
@property (class, readonly) TruoraSharedSkikoRegionOp *replace __attribute__((swift_name("replace")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoRegionOp *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoRegionOp *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoDrawable.Companion")))
@interface TruoraSharedSkikoDrawableCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoDrawableCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPicture.Companion")))
@interface TruoraSharedSkikoPictureCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoPictureCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoPicture * _Nullable)makeFromDataData:(TruoraSharedSkikoData * _Nullable)data __attribute__((swift_name("makeFromData(data:)")));
- (TruoraSharedSkikoPicture *)makePlaceholderCull:(TruoraSharedSkikoRect *)cull __attribute__((swift_name("makePlaceholder(cull:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoTypeface")))
@interface TruoraSharedSkikoTypeface : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoTypefaceCompanion *companion __attribute__((swift_name("companion")));
- (TruoraSharedKotlinIntArray * _Nullable)getKerningPairAdjustmentsGlyphs:(TruoraSharedKotlinShortArray * _Nullable)glyphs __attribute__((swift_name("getKerningPairAdjustments(glyphs:)")));
- (TruoraSharedKotlinShortArray *)getStringGlyphsS:(NSString *)s __attribute__((swift_name("getStringGlyphs(s:)")));
- (TruoraSharedSkikoData * _Nullable)getTableDataTag:(NSString *)tag __attribute__((swift_name("getTableData(tag:)")));
- (void * _Nullable)getTableSizeTag:(NSString *)tag __attribute__((swift_name("getTableSize(tag:)")));
- (int16_t)getUTF32GlyphUnichar:(int32_t)unichar __attribute__((swift_name("getUTF32Glyph(unichar:)")));
- (TruoraSharedKotlinShortArray *)getUTF32GlyphsUni:(TruoraSharedKotlinIntArray * _Nullable)uni __attribute__((swift_name("getUTF32Glyphs(uni:)")));
- (TruoraSharedSkikoTypeface *)makeCloneVariation:(TruoraSharedSkikoFontVariation *)variation __attribute__((swift_name("makeClone(variation:)")));
- (TruoraSharedSkikoTypeface *)makeCloneVariations:(TruoraSharedKotlinArray<TruoraSharedSkikoFontVariation *> *)variations collectionIndex:(int32_t)collectionIndex __attribute__((swift_name("makeClone(variations:collectionIndex:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedSkikoRect *bounds __attribute__((swift_name("bounds")));
@property (readonly) NSString *familyName __attribute__((swift_name("familyName")));
@property (readonly) TruoraSharedKotlinArray<TruoraSharedSkikoFontFamilyName *> *familyNames __attribute__((swift_name("familyNames")));
@property (readonly) TruoraSharedSkikoFontStyle *fontStyle __attribute__((swift_name("fontStyle")));
@property (readonly) int32_t glyphsCount __attribute__((swift_name("glyphsCount")));
@property (readonly) BOOL isBold __attribute__((swift_name("isBold")));
@property (readonly) BOOL isFixedPitch __attribute__((swift_name("isFixedPitch")));
@property (readonly) BOOL isItalic __attribute__((swift_name("isItalic")));
@property (readonly) TruoraSharedKotlinArray<NSString *> *tableTags __attribute__((swift_name("tableTags")));
@property (readonly) int32_t tablesCount __attribute__((swift_name("tablesCount")));
@property (readonly) int32_t uniqueId __attribute__((swift_name("uniqueId")));
@property (readonly) int32_t unitsPerEm __attribute__((swift_name("unitsPerEm")));
@property (readonly) TruoraSharedKotlinArray<TruoraSharedSkikoFontVariationAxis *> * _Nullable variationAxes __attribute__((swift_name("variationAxes")));
@property (readonly) TruoraSharedKotlinArray<TruoraSharedSkikoFontVariation *> * _Nullable variations __attribute__((swift_name("variations")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFont.Companion")))
@interface TruoraSharedSkikoFontCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoFontCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontEdging")))
@interface TruoraSharedSkikoFontEdging : TruoraSharedKotlinEnum<TruoraSharedSkikoFontEdging *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoFontEdging *alias __attribute__((swift_name("alias")));
@property (class, readonly) TruoraSharedSkikoFontEdging *antiAlias __attribute__((swift_name("antiAlias")));
@property (class, readonly) TruoraSharedSkikoFontEdging *subpixelAntiAlias __attribute__((swift_name("subpixelAntiAlias")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoFontEdging *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoFontEdging *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontHinting")))
@interface TruoraSharedSkikoFontHinting : TruoraSharedKotlinEnum<TruoraSharedSkikoFontHinting *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoFontHinting *none __attribute__((swift_name("none")));
@property (class, readonly) TruoraSharedSkikoFontHinting *slight __attribute__((swift_name("slight")));
@property (class, readonly) TruoraSharedSkikoFontHinting *normal __attribute__((swift_name("normal")));
@property (class, readonly) TruoraSharedSkikoFontHinting *full __attribute__((swift_name("full")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoFontHinting *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoFontHinting *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontMetrics")))
@interface TruoraSharedSkikoFontMetrics : TruoraSharedBase
- (instancetype)initWithTop:(float)top ascent:(float)ascent descent:(float)descent bottom:(float)bottom leading:(float)leading avgCharWidth:(float)avgCharWidth maxCharWidth:(float)maxCharWidth xMin:(float)xMin xMax:(float)xMax xHeight:(float)xHeight capHeight:(float)capHeight underlineThickness:(TruoraSharedFloat * _Nullable)underlineThickness underlinePosition:(TruoraSharedFloat * _Nullable)underlinePosition strikeoutThickness:(TruoraSharedFloat * _Nullable)strikeoutThickness strikeoutPosition:(TruoraSharedFloat * _Nullable)strikeoutPosition __attribute__((swift_name("init(top:ascent:descent:bottom:leading:avgCharWidth:maxCharWidth:xMin:xMax:xHeight:capHeight:underlineThickness:underlinePosition:strikeoutThickness:strikeoutPosition:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoFontMetricsCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) float ascent __attribute__((swift_name("ascent")));
@property (readonly) float avgCharWidth __attribute__((swift_name("avgCharWidth")));
@property (readonly) float bottom __attribute__((swift_name("bottom")));
@property (readonly) float capHeight __attribute__((swift_name("capHeight")));
@property (readonly) float descent __attribute__((swift_name("descent")));
@property (readonly) float height __attribute__((swift_name("height")));
@property (readonly) float leading __attribute__((swift_name("leading")));
@property (readonly) float maxCharWidth __attribute__((swift_name("maxCharWidth")));
@property (readonly) TruoraSharedFloat * _Nullable strikeoutPosition __attribute__((swift_name("strikeoutPosition")));
@property (readonly) TruoraSharedFloat * _Nullable strikeoutThickness __attribute__((swift_name("strikeoutThickness")));
@property (readonly) float top __attribute__((swift_name("top")));
@property (readonly) TruoraSharedFloat * _Nullable underlinePosition __attribute__((swift_name("underlinePosition")));
@property (readonly) TruoraSharedFloat * _Nullable underlineThickness __attribute__((swift_name("underlineThickness")));
@property (readonly) float xHeight __attribute__((swift_name("xHeight")));
@property (readonly) float xMax __attribute__((swift_name("xMax")));
@property (readonly) float xMin __attribute__((swift_name("xMin")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoTextBlob.Companion")))
@interface TruoraSharedSkikoTextBlobCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoTextBlobCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoTextBlob * _Nullable)makeFromDataData:(TruoraSharedSkikoData * _Nullable)data __attribute__((swift_name("makeFromData(data:)")));
- (TruoraSharedSkikoTextBlob * _Nullable)makeFromPosGlyphs:(TruoraSharedKotlinShortArray *)glyphs pos:(TruoraSharedKotlinArray<TruoraSharedSkikoPoint *> *)pos font:(TruoraSharedSkikoFont * _Nullable)font __attribute__((swift_name("makeFromPos(glyphs:pos:font:)")));
- (TruoraSharedSkikoTextBlob * _Nullable)makeFromPosHGlyphs:(TruoraSharedKotlinShortArray *)glyphs xpos:(TruoraSharedKotlinFloatArray *)xpos ypos:(float)ypos font:(TruoraSharedSkikoFont * _Nullable)font __attribute__((swift_name("makeFromPosH(glyphs:xpos:ypos:font:)")));
- (TruoraSharedSkikoTextBlob * _Nullable)makeFromRSXformGlyphs:(TruoraSharedKotlinShortArray *)glyphs xform:(TruoraSharedKotlinArray<TruoraSharedSkikoRSXform *> *)xform font:(TruoraSharedSkikoFont * _Nullable)font __attribute__((swift_name("makeFromRSXform(glyphs:xform:font:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoTextLine.Companion")))
@interface TruoraSharedSkikoTextLineCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoTextLineCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoTextLine *)makeText:(NSString * _Nullable)text font:(TruoraSharedSkikoFont * _Nullable)font __attribute__((swift_name("make(text:font:)")));
- (TruoraSharedSkikoTextLine *)makeText:(NSString * _Nullable)text font:(TruoraSharedSkikoFont * _Nullable)font opts:(TruoraSharedSkikoShapingOptions * _Nullable)opts __attribute__((swift_name("make(text:font:opts:)")));
@end

__attribute__((swift_name("KotlinShortIterator")))
@interface TruoraSharedKotlinShortIterator : TruoraSharedBase <TruoraSharedKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (TruoraSharedShort *)next __attribute__((swift_name("next()")));
- (int16_t)nextShort __attribute__((swift_name("nextShort()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoCanvas.SaveLayerFlags")))
@interface TruoraSharedSkikoCanvasSaveLayerFlags : TruoraSharedBase
- (instancetype)initWithFlagsSet:(TruoraSharedKotlinArray<TruoraSharedSkikoCanvasSaveLayerFlagsSet *> *)flagsSet __attribute__((swift_name("init(flagsSet:)"))) __attribute__((objc_designated_initializer));
- (BOOL)containsFlag:(TruoraSharedSkikoCanvasSaveLayerFlagsSet *)flag __attribute__((swift_name("contains(flag:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRegion.OpCompanion")))
@interface TruoraSharedSkikoRegionOpCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoRegionOpCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoTypeface.Companion")))
@interface TruoraSharedSkikoTypefaceCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoTypefaceCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoTypeface *)makeEmpty __attribute__((swift_name("makeEmpty()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontVariation")))
@interface TruoraSharedSkikoFontVariation : TruoraSharedBase
- (instancetype)initWith_tag:(int32_t)_tag value:(float)value __attribute__((swift_name("init(_tag:value:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithFeature:(NSString *)feature value:(float)value __attribute__((swift_name("init(feature:value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoFontVariationCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t _tag __attribute__((swift_name("_tag")));
@property (readonly) NSString *tag __attribute__((swift_name("tag")));
@property (readonly) float value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontFamilyName")))
@interface TruoraSharedSkikoFontFamilyName : TruoraSharedBase
- (instancetype)initWithName:(NSString *)name language:(NSString *)language __attribute__((swift_name("init(name:language:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *language __attribute__((swift_name("language")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontStyle")))
@interface TruoraSharedSkikoFontStyle : TruoraSharedBase
- (instancetype)initWithWeight:(int32_t)weight width:(int32_t)width slant:(TruoraSharedSkikoFontSlant *)slant __attribute__((swift_name("init(weight:width:slant:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoFontStyleCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (TruoraSharedSkikoFontStyle *)withSlantSlant:(TruoraSharedSkikoFontSlant *)slant __attribute__((swift_name("withSlant(slant:)")));
- (TruoraSharedSkikoFontStyle *)withWeightWeight:(int32_t)weight __attribute__((swift_name("withWeight(weight:)")));
- (TruoraSharedSkikoFontStyle *)withWidthWidth:(int32_t)width __attribute__((swift_name("withWidth(width:)")));
@property (readonly) int32_t _value __attribute__((swift_name("_value")));
@property (readonly) TruoraSharedSkikoFontSlant *slant __attribute__((swift_name("slant")));
@property (readonly) int32_t weight __attribute__((swift_name("weight")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontVariationAxis")))
@interface TruoraSharedSkikoFontVariationAxis : TruoraSharedBase
- (instancetype)initWithTag:(NSString *)tag min:(float)min def:(float)def max:(float)max __attribute__((swift_name("init(tag:min:def:max:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWith_tag:(int32_t)_tag minValue:(float)minValue defaultValue:(float)defaultValue maxValue:(float)maxValue isHidden:(BOOL)isHidden __attribute__((swift_name("init(_tag:minValue:defaultValue:maxValue:isHidden:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithTag:(NSString *)tag min:(float)min def:(float)def max:(float)max hidden:(BOOL)hidden __attribute__((swift_name("init(tag:min:def:max:hidden:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t _tag __attribute__((swift_name("_tag")));
@property (readonly) float defaultValue __attribute__((swift_name("defaultValue")));
@property (readonly) BOOL isHidden __attribute__((swift_name("isHidden")));
@property (readonly) float maxValue __attribute__((swift_name("maxValue")));
@property (readonly) float minValue __attribute__((swift_name("minValue")));
@property (readonly) NSString *tag __attribute__((swift_name("tag")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontMetrics.Companion")))
@interface TruoraSharedSkikoFontMetricsCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoFontMetricsCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRSXform")))
@interface TruoraSharedSkikoRSXform : TruoraSharedBase
- (instancetype)initWithScos:(float)scos ssin:(float)ssin tx:(float)tx ty:(float)ty __attribute__((swift_name("init(scos:ssin:tx:ty:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoRSXformCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoShapingOptions")))
@interface TruoraSharedSkikoShapingOptions : TruoraSharedBase
- (instancetype)initWithFontMgr:(TruoraSharedSkikoFontMgr * _Nullable)fontMgr features:(TruoraSharedKotlinArray<TruoraSharedSkikoFontFeature *> * _Nullable)features isLeftToRight:(BOOL)isLeftToRight isApproximateSpaces:(BOOL)isApproximateSpaces isApproximatePunctuation:(BOOL)isApproximatePunctuation __attribute__((swift_name("init(fontMgr:features:isLeftToRight:isApproximateSpaces:isApproximatePunctuation:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoShapingOptionsCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (TruoraSharedSkikoShapingOptions *)withApproximatePunctuation_approximatePunctuation:(BOOL)_approximatePunctuation __attribute__((swift_name("withApproximatePunctuation(_approximatePunctuation:)")));
- (TruoraSharedSkikoShapingOptions *)withApproximateSpaces_approximateSpaces:(BOOL)_approximateSpaces __attribute__((swift_name("withApproximateSpaces(_approximateSpaces:)")));
- (TruoraSharedSkikoShapingOptions *)withFeaturesFeatures:(TruoraSharedKotlinArray<TruoraSharedSkikoFontFeature *> * _Nullable)features __attribute__((swift_name("withFeatures(features:)")));
- (TruoraSharedSkikoShapingOptions *)withFeaturesFeaturesString:(NSString * _Nullable)featuresString __attribute__((swift_name("withFeatures(featuresString:)")));
- (TruoraSharedSkikoShapingOptions *)withFontMgr_fontMgr:(TruoraSharedSkikoFontMgr * _Nullable)_fontMgr __attribute__((swift_name("withFontMgr(_fontMgr:)")));
- (TruoraSharedSkikoShapingOptions *)withLeftToRight_leftToRight:(BOOL)_leftToRight __attribute__((swift_name("withLeftToRight(_leftToRight:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoCanvas.SaveLayerFlagsSet")))
@interface TruoraSharedSkikoCanvasSaveLayerFlagsSet : TruoraSharedKotlinEnum<TruoraSharedSkikoCanvasSaveLayerFlagsSet *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoCanvasSaveLayerFlagsSet *preservelcdtext __attribute__((swift_name("preservelcdtext")));
@property (class, readonly) TruoraSharedSkikoCanvasSaveLayerFlagsSet *initwithprevious __attribute__((swift_name("initwithprevious")));
@property (class, readonly) TruoraSharedSkikoCanvasSaveLayerFlagsSet *f16colortype __attribute__((swift_name("f16colortype")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoCanvasSaveLayerFlagsSet *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoCanvasSaveLayerFlagsSet *> *entries __attribute__((swift_name("entries")));
@property (readonly) int32_t mask __attribute__((swift_name("mask")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontVariation.Companion")))
@interface TruoraSharedSkikoFontVariationCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoFontVariationCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedKotlinArray<TruoraSharedSkikoFontVariation *> *)parseStr:(NSString *)str __attribute__((swift_name("parse(str:)")));
- (TruoraSharedSkikoFontVariation *)parseOneS:(NSString *)s __attribute__((swift_name("parseOne(s:)")));
@property (readonly) TruoraSharedKotlinArray<TruoraSharedSkikoFontVariation *> *EMPTY __attribute__((swift_name("EMPTY")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontSlant")))
@interface TruoraSharedSkikoFontSlant : TruoraSharedKotlinEnum<TruoraSharedSkikoFontSlant *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedSkikoFontSlant *upright __attribute__((swift_name("upright")));
@property (class, readonly) TruoraSharedSkikoFontSlant *italic __attribute__((swift_name("italic")));
@property (class, readonly) TruoraSharedSkikoFontSlant *oblique __attribute__((swift_name("oblique")));
+ (TruoraSharedKotlinArray<TruoraSharedSkikoFontSlant *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedSkikoFontSlant *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontStyle.Companion")))
@interface TruoraSharedSkikoFontStyleCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoFontStyleCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) TruoraSharedSkikoFontStyle *BOLD __attribute__((swift_name("BOLD")));
@property (readonly) TruoraSharedSkikoFontStyle *BOLD_ITALIC __attribute__((swift_name("BOLD_ITALIC")));
@property (readonly) TruoraSharedSkikoFontStyle *ITALIC __attribute__((swift_name("ITALIC")));
@property (readonly) TruoraSharedSkikoFontStyle *NORMAL __attribute__((swift_name("NORMAL")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoRSXform.Companion")))
@interface TruoraSharedSkikoRSXformCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoRSXformCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoRSXform *)makeFromRadiansScale:(float)scale radians:(float)radians tx:(float)tx ty:(float)ty ax:(float)ax ay:(float)ay __attribute__((swift_name("makeFromRadians(scale:radians:tx:ty:ax:ay:)")));
@end

__attribute__((swift_name("SkikoFontMgr")))
@interface TruoraSharedSkikoFontMgr : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoFontMgrCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)getFamilyNameIndex:(int32_t)index __attribute__((swift_name("getFamilyName(index:)")));
- (TruoraSharedSkikoTypeface * _Nullable)legacyMakeTypefaceName:(NSString *)name style:(TruoraSharedSkikoFontStyle *)style __attribute__((swift_name("legacyMakeTypeface(name:style:)")));
- (TruoraSharedSkikoTypeface * _Nullable)makeFromDataData:(TruoraSharedSkikoData * _Nullable)data ttcIndex:(int32_t)ttcIndex __attribute__((swift_name("makeFromData(data:ttcIndex:)")));
- (TruoraSharedSkikoTypeface * _Nullable)makeFromFilePath:(NSString *)path ttcIndex:(int32_t)ttcIndex __attribute__((swift_name("makeFromFile(path:ttcIndex:)")));
- (TruoraSharedSkikoFontStyleSet * _Nullable)makeStyleSetIndex:(int32_t)index __attribute__((swift_name("makeStyleSet(index:)")));
- (TruoraSharedSkikoTypeface * _Nullable)matchFamiliesStyleFamilies:(TruoraSharedKotlinArray<NSString *> *)families style:(TruoraSharedSkikoFontStyle *)style __attribute__((swift_name("matchFamiliesStyle(families:style:)")));
- (TruoraSharedSkikoTypeface * _Nullable)matchFamiliesStyleCharacterFamilies:(TruoraSharedKotlinArray<NSString *> *)families style:(TruoraSharedSkikoFontStyle *)style bcp47:(TruoraSharedKotlinArray<NSString *> * _Nullable)bcp47 character:(int32_t)character __attribute__((swift_name("matchFamiliesStyleCharacter(families:style:bcp47:character:)")));
- (TruoraSharedSkikoFontStyleSet *)matchFamilyFamilyName:(NSString * _Nullable)familyName __attribute__((swift_name("matchFamily(familyName:)")));
- (TruoraSharedSkikoTypeface * _Nullable)matchFamilyStyleFamilyName:(NSString * _Nullable)familyName style:(TruoraSharedSkikoFontStyle *)style __attribute__((swift_name("matchFamilyStyle(familyName:style:)")));
- (TruoraSharedSkikoTypeface * _Nullable)matchFamilyStyleCharacterFamilyName:(NSString * _Nullable)familyName style:(TruoraSharedSkikoFontStyle *)style bcp47:(TruoraSharedKotlinArray<NSString *> * _Nullable)bcp47 character:(int32_t)character __attribute__((swift_name("matchFamilyStyleCharacter(familyName:style:bcp47:character:)")));
@property (readonly) int32_t familiesCount __attribute__((swift_name("familiesCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontFeature")))
@interface TruoraSharedSkikoFontFeature : TruoraSharedBase
- (instancetype)initWithFeature:(NSString *)feature __attribute__((swift_name("init(feature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithFeature:(NSString *)feature value:(BOOL)value __attribute__((swift_name("init(feature:value:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithFeature:(NSString *)feature value_:(int32_t)value __attribute__((swift_name("init(feature:value_:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWith_tag:(int32_t)_tag value:(int32_t)value start:(uint32_t)start end:(uint32_t)end __attribute__((swift_name("init(_tag:value:start:end:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithFeature:(NSString *)feature value:(int32_t)value start:(uint32_t)start end:(uint32_t)end __attribute__((swift_name("init(feature:value:start:end:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedSkikoFontFeatureCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t _tag __attribute__((swift_name("_tag")));
@property (readonly) uint32_t end __attribute__((swift_name("end")));
@property (readonly) uint32_t start __attribute__((swift_name("start")));
@property (readonly) NSString *tag __attribute__((swift_name("tag")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoShapingOptions.Companion")))
@interface TruoraSharedSkikoShapingOptionsCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoShapingOptionsCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) TruoraSharedSkikoShapingOptions *DEFAULT __attribute__((swift_name("DEFAULT")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontMgr.Companion")))
@interface TruoraSharedSkikoFontMgrCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoFontMgrCompanion *shared __attribute__((swift_name("shared")));
@property (readonly, getter=default) TruoraSharedSkikoFontMgr *default_ __attribute__((swift_name("default_")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontStyleSet")))
@interface TruoraSharedSkikoFontStyleSet : TruoraSharedSkikoRefCnt

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr __attribute__((swift_name("init(ptr:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (instancetype)initWithPtr:(void * _Nullable)ptr allowClose:(BOOL)allowClose __attribute__((swift_name("init(ptr:allowClose:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) TruoraSharedSkikoFontStyleSetCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)count __attribute__((swift_name("count()")));
- (TruoraSharedSkikoFontStyle *)getStyleIndex:(int32_t)index __attribute__((swift_name("getStyle(index:)")));
- (NSString *)getStyleNameIndex:(int32_t)index __attribute__((swift_name("getStyleName(index:)")));
- (TruoraSharedSkikoTypeface * _Nullable)getTypefaceIndex:(int32_t)index __attribute__((swift_name("getTypeface(index:)")));
- (TruoraSharedSkikoTypeface * _Nullable)matchStyleStyle:(TruoraSharedSkikoFontStyle *)style __attribute__((swift_name("matchStyle(style:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontFeature.Companion")))
@interface TruoraSharedSkikoFontFeatureCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoFontFeatureCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedKotlinArray<TruoraSharedSkikoFontFeature *> *)parseStr:(NSString *)str __attribute__((swift_name("parse(str:)")));
- (TruoraSharedSkikoFontFeature *)parseOneS:(NSString *)s __attribute__((swift_name("parseOne(s:)")));
- (TruoraSharedKotlinArray<TruoraSharedSkikoFontFeature *> *)parseW3Str:(NSString *)str __attribute__((swift_name("parseW3(str:)")));
@property (readonly) TruoraSharedKotlinArray<TruoraSharedSkikoFontFeature *> *EMPTY __attribute__((swift_name("EMPTY")));
@property (readonly) uint32_t GLOBAL_END __attribute__((swift_name("GLOBAL_END")));
@property (readonly) uint32_t GLOBAL_START __attribute__((swift_name("GLOBAL_START")));
@property (readonly) TruoraSharedSkikoPattern *_featurePattern __attribute__((swift_name("_featurePattern")));
@property (readonly) TruoraSharedSkikoPattern *_splitPattern __attribute__((swift_name("_splitPattern")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoFontStyleSet.Companion")))
@interface TruoraSharedSkikoFontStyleSetCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedSkikoFontStyleSetCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedSkikoFontStyleSet *)makeEmpty __attribute__((swift_name("makeEmpty()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoPattern")))
@interface TruoraSharedSkikoPattern : TruoraSharedBase
- (instancetype)initWithRegex:(NSString *)regex __attribute__((swift_name("init(regex:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedSkikoMatcher *)matcherInput:(id)input __attribute__((swift_name("matcher(input:)")));
- (TruoraSharedKotlinArray<NSString *> *)splitInput:(id)input __attribute__((swift_name("split(input:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SkikoMatcher")))
@interface TruoraSharedSkikoMatcher : TruoraSharedBase
- (instancetype)initWithRegex:(TruoraSharedKotlinRegex *)regex input:(id)input __attribute__((swift_name("init(regex:input:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)groupIx:(int32_t)ix __attribute__((swift_name("group(ix:)")));
- (BOOL)matches __attribute__((swift_name("matches()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinRegex")))
@interface TruoraSharedKotlinRegex : TruoraSharedBase
- (instancetype)initWithPattern:(NSString *)pattern __attribute__((swift_name("init(pattern:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPattern:(NSString *)pattern options:(NSSet<TruoraSharedKotlinRegexOption *> *)options __attribute__((swift_name("init(pattern:options:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPattern:(NSString *)pattern option:(TruoraSharedKotlinRegexOption *)option __attribute__((swift_name("init(pattern:option:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKotlinRegexCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)containsMatchInInput:(id)input __attribute__((swift_name("containsMatchIn(input:)")));
- (id<TruoraSharedKotlinMatchResult> _Nullable)findInput:(id)input startIndex:(int32_t)startIndex __attribute__((swift_name("find(input:startIndex:)")));
- (id<TruoraSharedKotlinSequence>)findAllInput:(id)input startIndex:(int32_t)startIndex __attribute__((swift_name("findAll(input:startIndex:)")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.7")
*/
- (id<TruoraSharedKotlinMatchResult> _Nullable)matchAtInput:(id)input index:(int32_t)index __attribute__((swift_name("matchAt(input:index:)")));
- (id<TruoraSharedKotlinMatchResult> _Nullable)matchEntireInput:(id)input __attribute__((swift_name("matchEntire(input:)")));
- (BOOL)matchesInput:(id)input __attribute__((swift_name("matches(input:)")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.7")
*/
- (BOOL)matchesAtInput:(id)input index:(int32_t)index __attribute__((swift_name("matchesAt(input:index:)")));
- (NSString *)replaceInput:(id)input transform:(id (^)(id<TruoraSharedKotlinMatchResult>))transform __attribute__((swift_name("replace(input:transform:)")));
- (NSString *)replaceInput:(id)input replacement:(NSString *)replacement __attribute__((swift_name("replace(input:replacement:)")));
- (NSString *)replaceFirstInput:(id)input replacement:(NSString *)replacement __attribute__((swift_name("replaceFirst(input:replacement:)")));
- (NSArray<NSString *> *)splitInput:(id)input limit:(int32_t)limit __attribute__((swift_name("split(input:limit:)")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.6")
*/
- (id<TruoraSharedKotlinSequence>)splitToSequenceInput:(id)input limit:(int32_t)limit __attribute__((swift_name("splitToSequence(input:limit:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSSet<TruoraSharedKotlinRegexOption *> *options __attribute__((swift_name("options")));
@property (readonly) NSString *pattern __attribute__((swift_name("pattern")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinRegexOption")))
@interface TruoraSharedKotlinRegexOption : TruoraSharedKotlinEnum<TruoraSharedKotlinRegexOption *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) TruoraSharedKotlinRegexOption *ignoreCase __attribute__((swift_name("ignoreCase")));
@property (class, readonly) TruoraSharedKotlinRegexOption *multiline __attribute__((swift_name("multiline")));
@property (class, readonly) TruoraSharedKotlinRegexOption *literal __attribute__((swift_name("literal")));
@property (class, readonly) TruoraSharedKotlinRegexOption *unixLines __attribute__((swift_name("unixLines")));
@property (class, readonly) TruoraSharedKotlinRegexOption *comments __attribute__((swift_name("comments")));
@property (class, readonly) TruoraSharedKotlinRegexOption *dotMatchesAll __attribute__((swift_name("dotMatchesAll")));
@property (class, readonly) TruoraSharedKotlinRegexOption *canonEq __attribute__((swift_name("canonEq")));
+ (TruoraSharedKotlinArray<TruoraSharedKotlinRegexOption *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<TruoraSharedKotlinRegexOption *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinRegex.Companion")))
@interface TruoraSharedKotlinRegexCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKotlinRegexCompanion *shared __attribute__((swift_name("shared")));
- (NSString *)escapeLiteral:(NSString *)literal __attribute__((swift_name("escape(literal:)")));
- (NSString *)escapeReplacementLiteral:(NSString *)literal __attribute__((swift_name("escapeReplacement(literal:)")));
- (TruoraSharedKotlinRegex *)fromLiteralLiteral:(NSString *)literal __attribute__((swift_name("fromLiteral(literal:)")));
@end

__attribute__((swift_name("KotlinMatchResult")))
@protocol TruoraSharedKotlinMatchResult
@required
- (id<TruoraSharedKotlinMatchResult> _Nullable)next __attribute__((swift_name("next()")));
@property (readonly) TruoraSharedKotlinMatchResultDestructured *destructured __attribute__((swift_name("destructured")));
@property (readonly) NSArray<NSString *> *groupValues __attribute__((swift_name("groupValues")));
@property (readonly) id<TruoraSharedKotlinMatchGroupCollection> groups __attribute__((swift_name("groups")));
@property (readonly) TruoraSharedKotlinIntRange *range __attribute__((swift_name("range")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinMatchResultDestructured")))
@interface TruoraSharedKotlinMatchResultDestructured : TruoraSharedBase
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component10 __attribute__((swift_name("component10()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString *)component7 __attribute__((swift_name("component7()")));
- (NSString *)component8 __attribute__((swift_name("component8()")));
- (NSString *)component9 __attribute__((swift_name("component9()")));
- (NSArray<NSString *> *)toList __attribute__((swift_name("toList()")));
@property (readonly) id<TruoraSharedKotlinMatchResult> match __attribute__((swift_name("match")));
@end

__attribute__((swift_name("KotlinCollection")))
@protocol TruoraSharedKotlinCollection <TruoraSharedKotlinIterable>
@required
- (BOOL)containsElement:(id _Nullable)element __attribute__((swift_name("contains(element:)")));
- (BOOL)containsAllElements:(id)elements __attribute__((swift_name("containsAll(elements:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinMatchGroupCollection")))
@protocol TruoraSharedKotlinMatchGroupCollection <TruoraSharedKotlinCollection>
@required
- (TruoraSharedKotlinMatchGroup * _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
@end

__attribute__((swift_name("KotlinIntProgression")))
@interface TruoraSharedKotlinIntProgression : TruoraSharedBase <TruoraSharedKotlinIterable>
@property (class, readonly, getter=companion) TruoraSharedKotlinIntProgressionCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (TruoraSharedKotlinIntIterator *)iterator __attribute__((swift_name("iterator()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t first __attribute__((swift_name("first")));
@property (readonly) int32_t last __attribute__((swift_name("last")));
@property (readonly) int32_t step __attribute__((swift_name("step")));
@end

__attribute__((swift_name("KotlinClosedRange")))
@protocol TruoraSharedKotlinClosedRange
@required
- (BOOL)containsValue:(id)value __attribute__((swift_name("contains(value:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
@property (readonly) id endInclusive __attribute__((swift_name("endInclusive")));
@property (readonly, getter=start_) id start __attribute__((swift_name("start")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.9")
*/
__attribute__((swift_name("KotlinOpenEndRange")))
@protocol TruoraSharedKotlinOpenEndRange
@required
- (BOOL)containsValue_:(id)value __attribute__((swift_name("contains(value_:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
@property (readonly) id endExclusive __attribute__((swift_name("endExclusive")));
@property (readonly, getter=start_) id start __attribute__((swift_name("start")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinIntRange")))
@interface TruoraSharedKotlinIntRange : TruoraSharedKotlinIntProgression <TruoraSharedKotlinClosedRange, TruoraSharedKotlinOpenEndRange>
- (instancetype)initWithStart:(int32_t)start endInclusive:(int32_t)endInclusive __attribute__((swift_name("init(start:endInclusive:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) TruoraSharedKotlinIntRangeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)containsValue:(TruoraSharedInt *)value __attribute__((swift_name("contains(value:)")));
- (BOOL)containsValue_:(TruoraSharedInt *)value __attribute__((swift_name("contains(value_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.9")
*/
@property (readonly) TruoraSharedInt *endExclusive __attribute__((swift_name("endExclusive"))) __attribute__((deprecated("Can throw an exception when it's impossible to represent the value with Int type, for example, when the range includes MAX_VALUE. It's recommended to use 'endInclusive' property that doesn't throw.")));
@property (readonly) TruoraSharedInt *endInclusive __attribute__((swift_name("endInclusive")));
@property (readonly, getter=start_) TruoraSharedInt *start __attribute__((swift_name("start")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinMatchGroup")))
@interface TruoraSharedKotlinMatchGroup : TruoraSharedBase
- (instancetype)initWithValue:(NSString *)value range:(TruoraSharedKotlinIntRange *)range __attribute__((swift_name("init(value:range:)"))) __attribute__((objc_designated_initializer));
- (TruoraSharedKotlinMatchGroup *)doCopyValue:(NSString *)value range:(TruoraSharedKotlinIntRange *)range __attribute__((swift_name("doCopy(value:range:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) TruoraSharedKotlinIntRange *range __attribute__((swift_name("range")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinIntProgression.Companion")))
@interface TruoraSharedKotlinIntProgressionCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKotlinIntProgressionCompanion *shared __attribute__((swift_name("shared")));
- (TruoraSharedKotlinIntProgression *)fromClosedRangeRangeStart:(int32_t)rangeStart rangeEnd:(int32_t)rangeEnd step:(int32_t)step __attribute__((swift_name("fromClosedRange(rangeStart:rangeEnd:step:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinIntRange.Companion")))
@interface TruoraSharedKotlinIntRangeCompanion : TruoraSharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) TruoraSharedKotlinIntRangeCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) TruoraSharedKotlinIntRange *EMPTY __attribute__((swift_name("EMPTY")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
